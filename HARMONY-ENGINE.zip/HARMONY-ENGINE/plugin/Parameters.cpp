#include "Parameters.h"
#include <algorithm>
#include <cmath>
#include <cstdio>

namespace harmonyplugin {
namespace {

constexpr const char* kKeys[] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
constexpr const char* kScales[] = {"Major", "Natural Minor", "Harmonic Minor", "Melodic Minor", "Dorian", "Phrygian", "Lydian", "Mixolydian", "Locrian"};
constexpr const char* kModes[] = {"Key / Scale", "Manual Chord", "MIDI Chord", "Auto Key"};
constexpr const char* kChordTypes[] = {"Major", "Minor", "Diminished", "Augmented", "Sus2", "Sus4", "Major 7", "Minor 7", "Dominant 7", "Half-Dim 7", "Dim 7", "Add 9", "Minor Add 9", "Major 6", "Minor 6"};
constexpr const char* kMidiChannels[] = {"Omni", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16"};
constexpr const char* kVoiceModes[] = {"Scale Degree", "Chromatic", "Chord Tone"};
constexpr const char* kChoirSizes[] = {"1", "2", "4", "8"};
constexpr const char* kHarmonyPresets[] = {
    "Custom",
    "Scale 3rd Up", "Scale 3rd Down",
    "Minor 3rd Up", "Minor 3rd Down",
    "Major 3rd Up", "Major 3rd Down",
    "Scale 4th Up", "Scale 4th Down",
    "Perfect 4th Up", "Perfect 4th Down",
    "Scale 5th Up", "Scale 5th Down",
    "Perfect 5th Up", "Perfect 5th Down",
    "Octave Up", "Octave Down"
};

void add(std::vector<ParamSpec>& s, std::uint32_t id, const char* name, const char* unit,
         ParamKind kind, double mn, double mx, double def,
         const char* const* choices = nullptr, int choiceCount = 0,
         bool bypass = false, bool readOnly = false) {
    s.push_back({id, name, unit, kind, mn, mx, def, choices, choiceCount, bypass, readOnly});
}

std::vector<ParamSpec> makeSpecs() {
    std::vector<ParamSpec> s;
    s.reserve(120);
    add(s, kBypass, "Bypass", "", ParamKind::Toggle, 0, 1, 0, nullptr, 0, true);
    add(s, kInputDb, "Input", "dB", ParamKind::Continuous, -24, 24, 0);
    add(s, kOutputDb, "Output", "dB", ParamKind::Continuous, -24, 24, 0);
    add(s, kDryDb, "Dry", "dB", ParamKind::Continuous, -60, 6, -3);
    add(s, kWetDb, "Harmony", "dB", ParamKind::Continuous, -60, 6, -3);
    add(s, kHarmonyWidth, "Harmony Width", "%", ParamKind::Continuous, 0, 200, 100);
    add(s, kTuningHz, "Reference A4", "Hz", ParamKind::Continuous, 400, 480, 440);
    add(s, kMode, "Harmony Mode", "", ParamKind::Choice, 0, 3, 0, kModes, 4);
    add(s, kKey, "Key", "", ParamKind::Choice, 0, 11, 0, kKeys, 12);
    add(s, kScale, "Scale", "", ParamKind::Choice, 0, 8, 0, kScales, 9);
    add(s, kChordRoot, "Chord Root", "", ParamKind::Choice, 0, 11, 0, kKeys, 12);
    add(s, kChordType, "Chord Type", "", ParamKind::Choice, 0, 14, 0, kChordTypes, 15);
    add(s, kMidiChannel, "MIDI Channel", "", ParamKind::Choice, 0, 16, 0, kMidiChannels, 17);
    add(s, kMidiHold, "MIDI Hold", "", ParamKind::Toggle, 0, 1, 0);
    add(s, kAutoKeyThreshold, "Auto Key Threshold", "%", ParamKind::Continuous, 0, 100, 12);
    add(s, kTightness, "Tightness", "%", ParamKind::Continuous, 0, 100, 18);
    add(s, kSmoothingMs, "Pitch Glide", "ms", ParamKind::Continuous, 1, 120, 9);
    add(s, kHumanize, "Humanize", "%", ParamKind::Continuous, 0, 100, 35);
    add(s, kFormantPreserve, "Formant Preserve", "%", ParamKind::Continuous, 0, 100, 100);
    add(s, kTransientProtect, "Transient Protect", "%", ParamKind::Continuous, 0, 100, 85);
    add(s, kUnvoicedPreserve, "Consonant Protect", "%", ParamKind::Continuous, 0, 100, 92);

    constexpr int defaultIntervals[4] = {2, -2, 4, 0};
    constexpr int defaultOctaves[4] = {0, 0, 0, 1};
    constexpr double defaultLevels[4] = {-8, -9, -12, -14};
    constexpr double defaultPans[4] = {-28, 28, -58, 58};
    constexpr int defaultEnabled[4] = {1, 1, 0, 0};
    constexpr double defaultDelay[4] = {5, 9, 13, 17};
    constexpr int defaultPresets[4] = {1, 2, 0, 15};

    for (int v = 0; v < 4; ++v) {
        static const char* voiceNames[4] = {"Voice 1", "Voice 2", "Voice 3", "Voice 4"};
        const auto id = [v](VoiceParamOffset o) { return voiceParamId(v, o); };
        add(s, id(kVoiceEnable), voiceNames[v], "On", ParamKind::Toggle, 0, 1, defaultEnabled[v]);
        add(s, id(kVoiceMute), "Mute", "", ParamKind::Toggle, 0, 1, 0);
        add(s, id(kVoiceSolo), "Solo", "", ParamKind::Toggle, 0, 1, 0);
        add(s, id(kVoiceMode), "Voice Mode", "", ParamKind::Choice, 0, 2, 0, kVoiceModes, 3);
        add(s, id(kVoiceInterval), "Interval", "", ParamKind::Integer, -12, 12, defaultIntervals[v]);
        add(s, id(kVoiceOctave), "Octave", "oct", ParamKind::Integer, -2, 2, defaultOctaves[v]);
        add(s, id(kVoiceLevel), "Level", "dB", ParamKind::Continuous, -60, 6, defaultLevels[v]);
        add(s, id(kVoicePan), "Pan", "%", ParamKind::Continuous, -100, 100, defaultPans[v]);
        add(s, id(kVoiceFormant), "Formant", "st", ParamKind::Continuous, -12, 12, 0);
        add(s, id(kVoiceDetune), "Detune", "ct", ParamKind::Continuous, -50, 50, 0);
        add(s, id(kVoiceHumanizeCents), "Pitch Human", "ct", ParamKind::Continuous, 0, 18, 3);
        add(s, id(kVoiceDelayMs), "Timing", "ms", ParamKind::Continuous, 0, 80, defaultDelay[v]);
        add(s, id(kVoiceVibratoCents), "Vibrato Depth", "ct", ParamKind::Continuous, 0, 100, 0);
        add(s, id(kVoiceVibratoRate), "Vibrato Rate", "Hz", ParamKind::Continuous, 0.1, 12, 5.2);
        add(s, id(kVoiceChoirVoices), "Choir Voices", "", ParamKind::Choice, 0, 3, 0, kChoirSizes, 4);
        add(s, id(kVoiceChoirSpread), "Choir Spread", "%", ParamKind::Continuous, 0, 100, 0);
        add(s, id(kVoiceChoirDepth), "Choir Depth", "%", ParamKind::Continuous, 0, 100, 0);
        add(s, id(kVoiceMinMidi), "Low Range", "MIDI", ParamKind::Integer, 24, 84, 36);
        add(s, id(kVoiceMaxMidi), "High Range", "MIDI", ParamKind::Integer, 48, 120, 96);
        add(s, id(kVoiceHarmonyPreset), "Harmony Interval", "", ParamKind::Choice, 0, 16, defaultPresets[v], kHarmonyPresets, 17);
    }

    add(s, kMeterInput, "Input Meter", "", ParamKind::Meter, 0, 1, 0, nullptr, 0, false, true);
    add(s, kMeterOutputL, "Output L Meter", "", ParamKind::Meter, 0, 1, 0, nullptr, 0, false, true);
    add(s, kMeterOutputR, "Output R Meter", "", ParamKind::Meter, 0, 1, 0, nullptr, 0, false, true);
    add(s, kMeterVoice1, "Voice 1 Meter", "", ParamKind::Meter, 0, 1, 0, nullptr, 0, false, true);
    add(s, kMeterVoice2, "Voice 2 Meter", "", ParamKind::Meter, 0, 1, 0, nullptr, 0, false, true);
    add(s, kMeterVoice3, "Voice 3 Meter", "", ParamKind::Meter, 0, 1, 0, nullptr, 0, false, true);
    add(s, kMeterVoice4, "Voice 4 Meter", "", ParamKind::Meter, 0, 1, 0, nullptr, 0, false, true);
    add(s, kMeterPitchMidi, "Detected Pitch", "MIDI", ParamKind::Meter, 0, 127, 0, nullptr, 0, false, true);
    add(s, kMeterPitchConfidence, "Pitch Confidence", "%", ParamKind::Meter, 0, 100, 0, nullptr, 0, false, true);
    add(s, kMeterDetectedKey, "Detected Key", "", ParamKind::Choice, 0, 11, 0, kKeys, 12, false, true);
    add(s, kMeterDetectedScale, "Detected Scale", "", ParamKind::Choice, 0, 8, 0, kScales, 9, false, true);
    add(s, kMeterKeyConfidence, "Key Confidence", "%", ParamKind::Meter, 0, 100, 0, nullptr, 0, false, true);
    add(s, kMeterTarget1, "Voice 1 Target", "MIDI", ParamKind::Meter, -1, 127, -1, nullptr, 0, false, true);
    add(s, kMeterTarget2, "Voice 2 Target", "MIDI", ParamKind::Meter, -1, 127, -1, nullptr, 0, false, true);
    add(s, kMeterTarget3, "Voice 3 Target", "MIDI", ParamKind::Meter, -1, 127, -1, nullptr, 0, false, true);
    add(s, kMeterTarget4, "Voice 4 Target", "MIDI", ParamKind::Meter, -1, 127, -1, nullptr, 0, false, true);
    return s;
}

} // namespace

const std::vector<ParamSpec>& parameterSpecs() {
    static const std::vector<ParamSpec> specs = makeSpecs();
    return specs;
}

const ParamSpec* findSpec(std::uint32_t id) noexcept {
    static const std::array<const ParamSpec*, kParamStorageSize> map = [] {
        std::array<const ParamSpec*, kParamStorageSize> m{};
        for (const auto& spec : parameterSpecs()) if (spec.id < m.size()) m[spec.id] = &spec;
        return m;
    }();
    return id < map.size() ? map[id] : nullptr;
}

std::vector<const ParamSpec*> editableSpecs() {
    std::vector<const ParamSpec*> out;
    for (const auto& spec : parameterSpecs()) if (!spec.readOnly) out.push_back(&spec);
    return out;
}

std::vector<const ParamSpec*> meterSpecs() {
    std::vector<const ParamSpec*> out;
    for (const auto& spec : parameterSpecs()) if (spec.readOnly) out.push_back(&spec);
    return out;
}

double clamp01(double v) noexcept { return std::max(0.0, std::min(1.0, v)); }

double normalizePlain(const ParamSpec& spec, double plain) noexcept {
    if (spec.maxPlain <= spec.minPlain) return 0.0;
    plain = std::max(spec.minPlain, std::min(spec.maxPlain, plain));
    if (spec.kind == ParamKind::Integer || spec.kind == ParamKind::Toggle || spec.kind == ParamKind::Choice)
        plain = std::round(plain);
    return clamp01((plain - spec.minPlain) / (spec.maxPlain - spec.minPlain));
}

double denormalize(const ParamSpec& spec, double normalized) noexcept {
    double plain = spec.minPlain + clamp01(normalized) * (spec.maxPlain - spec.minPlain);
    if (spec.kind == ParamKind::Integer || spec.kind == ParamKind::Toggle || spec.kind == ParamKind::Choice)
        plain = std::round(plain);
    return std::max(spec.minPlain, std::min(spec.maxPlain, plain));
}

double defaultNormalized(const ParamSpec& spec) noexcept { return normalizePlain(spec, spec.defaultPlain); }

std::string valueText(const ParamSpec& spec, double normalized) {
    const double plain = denormalize(spec, normalized);
    if (spec.kind == ParamKind::Choice && spec.choices && spec.choiceCount > 0) {
        const int idx = std::max(0, std::min(spec.choiceCount - 1, static_cast<int>(std::lround(plain))));
        return spec.choices[idx];
    }
    if (spec.kind == ParamKind::Toggle) return plain >= 0.5 ? "On" : "Off";
    char buf[64]{};
    if (spec.kind == ParamKind::Integer || (std::abs(spec.maxPlain - spec.minPlain) > 100.0 && std::string(spec.unit) == "MIDI"))
        std::snprintf(buf, sizeof(buf), "%.0f%s%s", plain, *spec.unit ? " " : "", spec.unit);
    else if (std::abs(plain) >= 100.0)
        std::snprintf(buf, sizeof(buf), "%.1f%s%s", plain, *spec.unit ? " " : "", spec.unit);
    else
        std::snprintf(buf, sizeof(buf), "%.2f%s%s", plain, *spec.unit ? " " : "", spec.unit);
    return buf;
}

} // namespace harmonyplugin
