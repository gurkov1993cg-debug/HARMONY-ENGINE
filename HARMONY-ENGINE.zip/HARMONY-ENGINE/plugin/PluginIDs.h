#pragma once

#include "pluginterfaces/base/funknown.h"
#include "pluginterfaces/vst/vsttypes.h"

namespace harmonyplugin
{
static DECLARE_UID(kProcessorUID, 0x6E7F2E81, 0xA74A4D2C, 0x9C7A912D, 0x114AE503);
static DECLARE_UID(kControllerUID, 0xD87A2C59, 0x73FE4A68, 0xA5E641B4, 0xF30C92DE);

constexpr const char* kPluginName = "Harmony Engine";
constexpr const char* kVendorName = "Tercior Audio";
constexpr const char* kVendorURL = "https://github.com/gurkov1993cg-debug/HARMONY-ENGINE";
constexpr const char* kVendorEmail = "";
constexpr const char* kPluginVersion = "0.8.0";
constexpr const char* kVst3Category = "Fx";
}
