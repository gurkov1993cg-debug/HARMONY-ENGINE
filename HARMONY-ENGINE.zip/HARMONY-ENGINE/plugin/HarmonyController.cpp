#include "HarmonyController.h"
#include "HarmonyEditor.h"
#include "Parameters.h"

#include "base/source/fstreamer.h"
#include "base/source/fstring.h"
#include "pluginterfaces/base/ustring.h"
#include "public.sdk/source/vst/vstparameters.h"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>

namespace harmonyplugin {
using namespace Steinberg;
using namespace Steinberg::Vst;

namespace {
constexpr std::uint32_t kStateMagic = 0x48454E47U;
constexpr std::uint32_t kStateVersion = 2U;

void asciiToString128(const char* text, String128 dst) {
    std::memset(dst, 0, sizeof(String128));
    UString(dst, 128).fromAscii(text ? text : "");
}
}

tresult PLUGIN_API HarmonyController::initialize(FUnknown* context) {
    const auto result = EditControllerEx1::initialize(context);
    if (result != kResultOk) return result;

    for (const auto& spec : parameterSpecs()) {
        String128 title{};
        String128 units{};
        asciiToString128(spec.name, title);
        asciiToString128(spec.unit, units);
        const TChar* unitPtr = (spec.unit && *spec.unit) ? units : nullptr;

        int32 flags = spec.readOnly ? ParameterInfo::kIsReadOnly : ParameterInfo::kCanAutomate;
        if (spec.bypass) flags |= ParameterInfo::kIsBypass;

        if (spec.kind == ParamKind::Choice) {
            auto* p = new StringListParameter(title, spec.id, unitPtr,
                                              flags | ParameterInfo::kIsList,
                                              kRootUnitId);
            for (int i = 0; i < spec.choiceCount; ++i) {
                String128 choice{};
                asciiToString128(spec.choices[i], choice);
                p->appendString(choice);
            }
            p->setNormalized(defaultNormalized(spec));
            parameters.addParameter(p);
        } else if (spec.kind == ParamKind::Toggle) {
            parameters.addParameter(title, unitPtr, 1, defaultNormalized(spec), flags,
                                    static_cast<int32>(spec.id));
        } else {
            // VST3 has no kStepCountContinuous constant: stepCount 0 IS continuous.
            int32 steps = 0;
            if (spec.kind == ParamKind::Integer)
                steps = std::max<int32>(1, static_cast<int32>(std::lround(spec.maxPlain - spec.minPlain)));
            auto* p = new RangeParameter(title, spec.id, unitPtr,
                                         spec.minPlain, spec.maxPlain, spec.defaultPlain,
                                         steps, flags, kRootUnitId);
            p->setNormalized(defaultNormalized(spec));
            parameters.addParameter(p);
        }
    }
    return kResultOk;
}

tresult PLUGIN_API HarmonyController::terminate() {
    return EditControllerEx1::terminate();
}

tresult PLUGIN_API HarmonyController::setComponentState(IBStream* state) {
    if (!state) return kInvalidArgument;
    IBStreamer stream(state, kLittleEndian);
    int32 magic = 0, version = 0, count = 0;
    if (!stream.readInt32(magic) || static_cast<std::uint32_t>(magic) != kStateMagic) return kResultFalse;
    if (!stream.readInt32(version) || version < 1 || version > static_cast<int32>(kStateVersion)) return kResultFalse;
    if (!stream.readInt32(count) || count < 0 || count > 512) return kResultFalse;

    for (int32 i = 0; i < count; ++i) {
        int32 id = 0;
        float value = 0.0f;
        if (!stream.readInt32(id) || !stream.readFloat(value)) return kResultFalse;
        if (id < 0) continue;
        const auto pid = static_cast<ParamID>(id);
        const auto* spec = findSpec(static_cast<std::uint32_t>(id));
        if (spec && !spec->readOnly && getParameterObject(pid))
            EditControllerEx1::setParamNormalized(pid, clamp01(value));
    }
    return kResultOk;
}

IPlugView* PLUGIN_API HarmonyController::createView(const char* name) {
    if (name && std::strcmp(name, ViewType::kEditor) == 0) return createHarmonyEditor(this);
    return nullptr;
}

tresult PLUGIN_API HarmonyController::setState(IBStream*) {
    return kResultOk;
}

tresult PLUGIN_API HarmonyController::getState(IBStream*) {
    return kResultOk;
}

bool HarmonyController::setFromUI(ParamID id, double normalized, bool begin, bool end) {
    const auto* spec = findSpec(static_cast<std::uint32_t>(id));
    if (!spec || spec->readOnly) return false;
    normalized = clamp01(normalized);
    if (begin) beginEdit(id);
    EditControllerEx1::setParamNormalized(id, normalized);
    performEdit(id, normalized);
    if (end) endEdit(id);
    return true;
}

} // namespace harmonyplugin
