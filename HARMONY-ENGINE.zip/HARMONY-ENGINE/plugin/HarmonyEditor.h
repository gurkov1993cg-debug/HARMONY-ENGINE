#pragma once
#include "pluginterfaces/gui/iplugview.h"

namespace harmonyplugin {
class HarmonyController;
Steinberg::IPlugView* createHarmonyEditor(HarmonyController* controller);
}
