#include "HarmonyProcessorVST3.h"
#include "PluginIDs.h"

#include "base/source/fstreamer.h"
#include "pluginterfaces/vst/ivstevents.h"
#include "pluginterfaces/vst/ivstparameterchanges.h"
#include "pluginterfaces/vst/vstspeaker.h"

#include <algorithm>
#include <cmath>
#include <cstring>

namespace harmonyplugin {
using namespace Steinberg;
using namespace Steinberg::Vst;

HarmonyProcessorVST3::HarmonyProcessorVST3() {
    setControllerClass(kControllerUID);
    resetDefaults();
    lastPublishedMeters_.fill(-1.0f);
}

void HarmonyProcessorVST3::resetDefaults() noexcept {
    values_.fill(0.0f);
    for (const auto& spec : parameterSpecs()) {
        if (!spec.readOnly && spec.id < values_.size())
            values_[spec.id] = static_cast<float>(defaultNormalized(spec));
    }
}

tresult PLUGIN_API HarmonyProcessorVST3::initialize(FUnknown* context) {
    const auto result = AudioEffect::initialize(context);
    if (result != kResultOk) return result;

    addAudioInput(STR16("Input"), SpeakerArr::kStereo);
    addAudioOutput(STR16("Output"), SpeakerArr::kStereo);
    addEventInput(STR16("MIDI In"), 16);
    return kResultOk;
}

tresult PLUGIN_API HarmonyProcessorVST3::terminate() {
    monoInput_.clear();
    outputL_.clear();
    outputR_.clear();
    bypassDelayL_.clear();
    bypassDelayR_.clear();
    return AudioEffect::terminate();
}

tresult PLUGIN_API HarmonyProcessorVST3::setupProcessing(ProcessSetup& setup) {
    const auto result = AudioEffect::setupProcessing(setup);
    if (result != kResultOk) return result;
    if (setup.symbolicSampleSize != kSample32 || setup.sampleRate < 8000.0) return kResultFalse;

    sampleRate_ = setup.sampleRate;
    engine_.prepare(sampleRate_);
    engine_.setParams(readProcessorParams());

    const auto requested = static_cast<std::size_t>(std::max<int32>(1, setup.maxSamplesPerBlock));
    const auto capacity = std::max(kScratchCapacity, requested);
    monoInput_.assign(capacity, 0.0f);
    outputL_.assign(capacity, 0.0f);
    outputR_.assign(capacity, 0.0f);

    const auto delaySize = static_cast<std::size_t>(std::max(1, engine_.latencySamples()));
    bypassDelayL_.assign(delaySize, 0.0f);
    bypassDelayR_.assign(delaySize, 0.0f);
    bypassWrite_ = 0;

    activeMidiNotes_.fill(false);
    physicalMidiNotes_.fill(false);
    lastMidiHold_ = false;
    lastPublishedMeters_.fill(-1.0f);
    return kResultOk;
}

tresult PLUGIN_API HarmonyProcessorVST3::setActive(TBool state) {
    if (state) {
        engine_.reset();
        std::fill(bypassDelayL_.begin(), bypassDelayL_.end(), 0.0f);
        std::fill(bypassDelayR_.begin(), bypassDelayR_.end(), 0.0f);
        bypassWrite_ = 0;
    } else {
        activeMidiNotes_.fill(false);
        physicalMidiNotes_.fill(false);
    }
    return AudioEffect::setActive(state);
}

tresult PLUGIN_API HarmonyProcessorVST3::setBusArrangements(SpeakerArrangement* inputs,
                                                              int32 numIns,
                                                              SpeakerArrangement* outputs,
                                                              int32 numOuts) {
    if (numIns != 1 || numOuts != 1 || inputs == nullptr || outputs == nullptr) return kResultFalse;
    const int inCh = SpeakerArr::getChannelCount(inputs[0]);
    const int outCh = SpeakerArr::getChannelCount(outputs[0]);
    const bool supported = (inCh == 1 || inCh == 2) && (outCh == 1 || outCh == 2);
    if (!supported) return kResultFalse;

    if (auto* in = getAudioInput(0)) {
        in->setArrangement(inputs[0]);
        in->setName(inCh == 1 ? STR16("Mono In") : STR16("Stereo In"));
    }
    if (auto* out = getAudioOutput(0)) {
        out->setArrangement(outputs[0]);
        out->setName(outCh == 1 ? STR16("Mono Out") : STR16("Stereo Out"));
    }
    return kResultOk;
}

tresult PLUGIN_API HarmonyProcessorVST3::canProcessSampleSize(int32 symbolicSampleSize) {
    return symbolicSampleSize == kSample32 ? kResultTrue : kResultFalse;
}

double HarmonyProcessorVST3::paramNorm(std::uint32_t id) const noexcept {
    return id < values_.size() ? static_cast<double>(values_[id]) : 0.0;
}

double HarmonyProcessorVST3::paramPlain(std::uint32_t id) const noexcept {
    if (const auto* spec = findSpec(id)) return denormalize(*spec, paramNorm(id));
    return 0.0;
}

void HarmonyProcessorVST3::applyParameterChanges(IParameterChanges* changes) noexcept {
    if (!changes) return;
    const int32 count = changes->getParameterCount();
    for (int32 i = 0; i < count; ++i) {
        auto* queue = changes->getParameterData(i);
        if (!queue) continue;
        const auto id = static_cast<std::uint32_t>(queue->getParameterId());
        const auto* spec = findSpec(id);
        if (!spec || spec->readOnly || id >= values_.size()) continue;
        const int32 points = queue->getPointCount();
        if (points <= 0) continue;
        int32 offset = 0;
        ParamValue value = 0.0;
        if (queue->getPoint(points - 1, offset, value) == kResultTrue)
            values_[id] = static_cast<float>(clamp01(value));
    }
}

void HarmonyProcessorVST3::applyMidi(IEventList* events) noexcept {
    const bool hold = paramPlain(kMidiHold) >= 0.5;
    const int channelChoice = std::clamp(static_cast<int>(std::lround(paramPlain(kMidiChannel))), 0, 16);

    if (!hold && lastMidiHold_) activeMidiNotes_ = physicalMidiNotes_;

    if (events) {
        const int32 count = events->getEventCount();
        for (int32 i = 0; i < count; ++i) {
            Event e{};
            if (events->getEvent(i, e) != kResultOk) continue;
            if (e.type == Event::kNoteOnEvent) {
                if (channelChoice != 0 && e.noteOn.channel != channelChoice - 1) continue;
                const int note = std::clamp<int>(e.noteOn.pitch, 0, 127);
                const bool hadPhysical = std::any_of(physicalMidiNotes_.begin(), physicalMidiNotes_.end(), [](bool x) { return x; });
                if (hold && !hadPhysical) activeMidiNotes_.fill(false);
                physicalMidiNotes_[static_cast<std::size_t>(note)] = true;
                activeMidiNotes_[static_cast<std::size_t>(note)] = true;
            } else if (e.type == Event::kNoteOffEvent) {
                if (channelChoice != 0 && e.noteOff.channel != channelChoice - 1) continue;
                const int note = std::clamp<int>(e.noteOff.pitch, 0, 127);
                physicalMidiNotes_[static_cast<std::size_t>(note)] = false;
                if (!hold) activeMidiNotes_[static_cast<std::size_t>(note)] = false;
            }
        }
    }

    lastMidiHold_ = hold;
    std::array<int, 16> notes{};
    std::size_t noteCount = 0;
    for (int n = 0; n < 128 && noteCount < notes.size(); ++n) {
        if (activeMidiNotes_[static_cast<std::size_t>(n)]) notes[noteCount++] = n;
    }
    engine_.setChordNotes(notes.data(), noteCount);
}

harmony::ProcessorParams HarmonyProcessorVST3::readProcessorParams() const noexcept {
    harmony::ProcessorParams p;
    p.inputDb = static_cast<float>(paramPlain(kInputDb));
    p.outputDb = static_cast<float>(paramPlain(kOutputDb));
    p.dryDb = static_cast<float>(paramPlain(kDryDb));
    p.wetDb = static_cast<float>(paramPlain(kWetDb));
    p.harmonyWidth = static_cast<float>(paramPlain(kHarmonyWidth) * 0.01);
    p.tuningHz = static_cast<float>(paramPlain(kTuningHz));
    p.tightness = static_cast<float>(paramPlain(kTightness) * 0.01);
    p.pitchSmoothingMs = static_cast<float>(paramPlain(kSmoothingMs));
    p.humanize = static_cast<float>(paramPlain(kHumanize) * 0.01);
    p.formantPreserve = static_cast<float>(paramPlain(kFormantPreserve) * 0.01);
    p.transientProtection = static_cast<float>(paramPlain(kTransientProtect) * 0.01);
    p.unvoicedPreserve = static_cast<float>(paramPlain(kUnvoicedPreserve) * 0.01);
    p.autoKeyThreshold = static_cast<float>(paramPlain(kAutoKeyThreshold) * 0.01);
    p.mode = static_cast<harmony::HarmonyMode>(std::clamp(static_cast<int>(std::lround(paramPlain(kMode))), 0, 3));
    p.keyRoot = std::clamp(static_cast<int>(std::lround(paramPlain(kKey))), 0, 11);
    p.scale = static_cast<harmony::ScaleType>(std::clamp(static_cast<int>(std::lround(paramPlain(kScale))), 0, 8));
    p.chordRoot = std::clamp(static_cast<int>(std::lround(paramPlain(kChordRoot))), 0, 11);
    p.chordType = static_cast<harmony::ChordType>(std::clamp(static_cast<int>(std::lround(paramPlain(kChordType))), 0, 14));

    static constexpr int choirCounts[4] = {1, 2, 4, 8};
    for (int v = 0; v < 4; ++v) {
        auto& vp = p.voices[static_cast<std::size_t>(v)];
        const auto get = [this, v](VoiceParamOffset o) { return paramPlain(voiceParamId(v, o)); };
        vp.rule.enabled = get(kVoiceEnable) >= 0.5;
        vp.mute = get(kVoiceMute) >= 0.5;
        vp.solo = get(kVoiceSolo) >= 0.5;
        vp.rule.mode = static_cast<harmony::VoiceMode>(std::clamp(static_cast<int>(std::lround(get(kVoiceMode))), 0, 2));
        vp.rule.interval = std::clamp(static_cast<int>(std::lround(get(kVoiceInterval))), -12, 12);
        vp.rule.octave = std::clamp(static_cast<int>(std::lround(get(kVoiceOctave))), -2, 2);
        vp.levelDb = static_cast<float>(get(kVoiceLevel));
        vp.pan = static_cast<float>(get(kVoicePan) * 0.01);
        vp.formantSemitones = static_cast<float>(get(kVoiceFormant));
        vp.detuneCents = static_cast<float>(get(kVoiceDetune));
        vp.humanizeCents = static_cast<float>(get(kVoiceHumanizeCents));
        vp.delayMs = static_cast<float>(get(kVoiceDelayMs));
        vp.vibratoCents = static_cast<float>(get(kVoiceVibratoCents));
        vp.vibratoRateHz = static_cast<float>(get(kVoiceVibratoRate));
        const int choirIdx = std::clamp(static_cast<int>(std::lround(get(kVoiceChoirVoices))), 0, 3);
        vp.choirVoices = choirCounts[choirIdx];
        vp.choirSpread = static_cast<float>(get(kVoiceChoirSpread) * 0.01);
        vp.choirDepth = static_cast<float>(get(kVoiceChoirDepth) * 0.01);
        vp.minMidi = std::clamp(static_cast<int>(std::lround(get(kVoiceMinMidi))), 0, 127);
        vp.maxMidi = std::clamp(static_cast<int>(std::lround(get(kVoiceMaxMidi))), 0, 127);
        if (vp.minMidi > vp.maxMidi) std::swap(vp.minMidi, vp.maxMidi);
    }
    return p;
}

tresult PLUGIN_API HarmonyProcessorVST3::process(ProcessData& data) {
    if (data.symbolicSampleSize != kSample32) return kResultFalse;
    applyParameterChanges(data.inputParameterChanges);
    applyMidi(data.inputEvents);
    engine_.setParams(readProcessorParams());

    if (data.numSamples <= 0 || data.numInputs <= 0 || data.numOutputs <= 0 || !data.inputs || !data.outputs) {
        publishMeters(data);
        return kResultOk;
    }

    auto& inBus = data.inputs[0];
    auto& outBus = data.outputs[0];
    if (inBus.numChannels <= 0 || outBus.numChannels <= 0 || !inBus.channelBuffers32 || !outBus.channelBuffers32)
        return kResultFalse;

    const float* in0 = inBus.channelBuffers32[0];
    const float* in1 = inBus.numChannels > 1 ? inBus.channelBuffers32[1] : nullptr;
    float* out0 = outBus.channelBuffers32[0];
    float* out1 = outBus.numChannels > 1 ? outBus.channelBuffers32[1] : nullptr;
    if (!in0 || !out0) return kResultFalse;

    const bool bypass = paramPlain(kBypass) >= 0.5;
    bypassMeters_ = bypass;
    bypassInputPeak_ = bypassOutputLPeak_ = bypassOutputRPeak_ = 0.0f;
    const auto scratchCapacity = std::min({monoInput_.size(), outputL_.size(), outputR_.size()});
    if (scratchCapacity == 0U) return kResultFalse;
    const auto delaySize = bypassDelayL_.size();

    int32 offset = 0;
    while (offset < data.numSamples) {
        const int32 chunk = std::min<int32>(data.numSamples - offset, static_cast<int32>(scratchCapacity));
        for (int32 i = 0; i < chunk; ++i) {
            const int32 s = offset + i;
            const float l = in0[s];
            const float r = in1 ? in1[s] : l;
            monoInput_[static_cast<std::size_t>(i)] = in1 ? 0.5f * (l + r) : l;
        }

        if (!bypass)
            engine_.processBlock(monoInput_.data(), outputL_.data(), outputR_.data(), static_cast<std::size_t>(chunk));

        for (int32 i = 0; i < chunk; ++i) {
            const int32 s = offset + i;
            const float srcL = in0[s];
            const float srcR = in1 ? in1[s] : srcL;
            float delayedL = srcL;
            float delayedR = srcR;
            if (delaySize > 0U) {
                delayedL = bypassDelayL_[bypassWrite_];
                delayedR = bypassDelayR_[bypassWrite_];
                bypassDelayL_[bypassWrite_] = srcL;
                bypassDelayR_[bypassWrite_] = srcR;
                bypassWrite_ = (bypassWrite_ + 1U) % delaySize;
            }

            if (bypass) {
                const float monoOut = 0.5f * (delayedL + delayedR);
                out0[s] = out1 ? delayedL : monoOut;
                if (out1) out1[s] = delayedR;
                bypassInputPeak_ = std::max(bypassInputPeak_, std::max(std::abs(srcL), std::abs(srcR)));
                bypassOutputLPeak_ = std::max(bypassOutputLPeak_, std::abs(out0[s]));
                bypassOutputRPeak_ = std::max(bypassOutputRPeak_, std::abs(out1 ? out1[s] : out0[s]));
            } else {
                out0[s] = out1 ? outputL_[static_cast<std::size_t>(i)]
                               : 0.5f * (outputL_[static_cast<std::size_t>(i)] + outputR_[static_cast<std::size_t>(i)]);
                if (out1) out1[s] = outputR_[static_cast<std::size_t>(i)];
            }
        }
        offset += chunk;
    }

    outBus.silenceFlags = 0;
    publishMeters(data);
    return kResultOk;
}

void HarmonyProcessorVST3::writeMeter(IParameterChanges* changes, ParamID id, double normalized, int32 sampleOffset) noexcept {
    if (!changes || id >= lastPublishedMeters_.size()) return;
    const float v = static_cast<float>(clamp01(normalized));
    const float old = lastPublishedMeters_[id];
    if (old >= 0.0f && std::abs(old - v) < 0.0005f) return;
    int32 queueIndex = 0;
    if (auto* q = changes->addParameterData(id, queueIndex)) {
        int32 pointIndex = 0;
        if (q->addPoint(sampleOffset, v, pointIndex) == kResultTrue) lastPublishedMeters_[id] = v;
    }
}

void HarmonyProcessorVST3::publishMeters(ProcessData& data) noexcept {
    auto* changes = data.outputParameterChanges;
    if (!changes) return;
    const int32 sampleOffset = std::max<int32>(0, data.numSamples - 1);
    if (bypassMeters_) {
        writeMeter(changes, kMeterInput, std::clamp<double>(bypassInputPeak_, 0.0, 1.0), sampleOffset);
        writeMeter(changes, kMeterOutputL, std::clamp<double>(bypassOutputLPeak_, 0.0, 1.0), sampleOffset);
        writeMeter(changes, kMeterOutputR, std::clamp<double>(bypassOutputRPeak_, 0.0, 1.0), sampleOffset);
        writeMeter(changes, kMeterVoice1, 0.0, sampleOffset);
        writeMeter(changes, kMeterVoice2, 0.0, sampleOffset);
        writeMeter(changes, kMeterVoice3, 0.0, sampleOffset);
        writeMeter(changes, kMeterVoice4, 0.0, sampleOffset);
        if (const auto* s = findSpec(kMeterPitchMidi)) writeMeter(changes, kMeterPitchMidi, normalizePlain(*s, 0.0), sampleOffset);
        if (findSpec(kMeterPitchConfidence)) writeMeter(changes, kMeterPitchConfidence, 0.0, sampleOffset);
        if (findSpec(kMeterKeyConfidence)) writeMeter(changes, kMeterKeyConfidence, 0.0, sampleOffset);
        const std::uint32_t tids[4] = {kMeterTarget1,kMeterTarget2,kMeterTarget3,kMeterTarget4};
        for (auto id : tids) if (const auto* s = findSpec(id)) writeMeter(changes, id, normalizePlain(*s, -1.0), sampleOffset);
        return;
    }

    const auto m = engine_.meters();
    writeMeter(changes, kMeterInput, std::clamp<double>(m.inputPeak, 0.0, 1.0), sampleOffset);
    writeMeter(changes, kMeterOutputL, std::clamp<double>(m.outputPeakL, 0.0, 1.0), sampleOffset);
    writeMeter(changes, kMeterOutputR, std::clamp<double>(m.outputPeakR, 0.0, 1.0), sampleOffset);
    writeMeter(changes, kMeterVoice1, std::clamp<double>(m.voicePeak[0], 0.0, 1.0), sampleOffset);
    writeMeter(changes, kMeterVoice2, std::clamp<double>(m.voicePeak[1], 0.0, 1.0), sampleOffset);
    writeMeter(changes, kMeterVoice3, std::clamp<double>(m.voicePeak[2], 0.0, 1.0), sampleOffset);
    writeMeter(changes, kMeterVoice4, std::clamp<double>(m.voicePeak[3], 0.0, 1.0), sampleOffset);
    if (const auto* s = findSpec(kMeterPitchMidi)) writeMeter(changes, kMeterPitchMidi, normalizePlain(*s, m.pitchMidi), sampleOffset);
    if (const auto* s = findSpec(kMeterPitchConfidence)) writeMeter(changes, kMeterPitchConfidence, normalizePlain(*s, m.pitchConfidence * 100.0), sampleOffset);
    if (const auto* s = findSpec(kMeterDetectedKey)) writeMeter(changes, kMeterDetectedKey, normalizePlain(*s, m.detectedKeyRoot), sampleOffset);
    if (const auto* s = findSpec(kMeterDetectedScale)) writeMeter(changes, kMeterDetectedScale, normalizePlain(*s, static_cast<int>(m.detectedScale)), sampleOffset);
    if (const auto* s = findSpec(kMeterKeyConfidence)) writeMeter(changes, kMeterKeyConfidence, normalizePlain(*s, m.keyConfidence * 100.0), sampleOffset);
    const auto target = engine_.targetNotes();
    const std::uint32_t targetIds[4] = {kMeterTarget1, kMeterTarget2, kMeterTarget3, kMeterTarget4};
    for (int i = 0; i < 4; ++i) if (const auto* s = findSpec(targetIds[i])) writeMeter(changes, targetIds[i], normalizePlain(*s, target[static_cast<std::size_t>(i)]), sampleOffset);
}

tresult PLUGIN_API HarmonyProcessorVST3::getState(IBStream* state) {
    if (!state) return kInvalidArgument;
    IBStreamer stream(state, kLittleEndian);
    const auto edit = editableSpecs();
    if (!stream.writeInt32(static_cast<int32>(kStateMagic))) return kResultFalse;
    if (!stream.writeInt32(static_cast<int32>(kStateVersion))) return kResultFalse;
    if (!stream.writeInt32(static_cast<int32>(edit.size()))) return kResultFalse;
    for (const auto* spec : edit) {
        if (!stream.writeInt32(static_cast<int32>(spec->id))) return kResultFalse;
        if (!stream.writeFloat(values_[spec->id])) return kResultFalse;
    }
    return kResultOk;
}

tresult PLUGIN_API HarmonyProcessorVST3::setState(IBStream* state) {
    if (!state) return kInvalidArgument;
    IBStreamer stream(state, kLittleEndian);
    int32 magic = 0, version = 0, count = 0;
    if (!stream.readInt32(magic) || static_cast<std::uint32_t>(magic) != kStateMagic) return kResultFalse;
    if (!stream.readInt32(version) || version < 1 || version > static_cast<int32>(kStateVersion)) return kResultFalse;
    if (!stream.readInt32(count) || count < 0 || count > 512) return kResultFalse;
    for (int32 i = 0; i < count; ++i) {
        int32 id = 0;
        float value = 0.0f;
        if (!stream.readInt32(id) || !stream.readFloat(value)) return kResultFalse;
        if (id >= 0 && static_cast<std::size_t>(id) < values_.size()) {
            const auto* spec = findSpec(static_cast<std::uint32_t>(id));
            if (spec && !spec->readOnly) values_[static_cast<std::size_t>(id)] = static_cast<float>(clamp01(value));
        }
    }
    engine_.setParams(readProcessorParams());
    return kResultOk;
}

uint32 PLUGIN_API HarmonyProcessorVST3::getLatencySamples() {
    return static_cast<uint32>(std::max(0, engine_.latencySamples()));
}

uint32 PLUGIN_API HarmonyProcessorVST3::getTailSamples() {
    return static_cast<uint32>(std::max(0.0, sampleRate_ * 0.25));
}

} // namespace harmonyplugin
