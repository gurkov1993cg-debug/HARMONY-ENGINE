#include "HarmonyProcessorVST3.h"
#include "AuditionLogic.h"
#include "PluginIDs.h"
#include "harmony/AudioMath.h"

#include "base/source/fstreamer.h"
#include "pluginterfaces/vst/ivstevents.h"
#include "pluginterfaces/vst/ivstparameterchanges.h"
#include "pluginterfaces/vst/vstspeaker.h"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <type_traits>

namespace harmonyplugin {
using namespace Steinberg;
using namespace Steinberg::Vst;

HarmonyProcessorVST3::HarmonyProcessorVST3() {
    setControllerClass(FUID::fromTUID(kControllerUID));
    resetDefaults();
    lastPublishedMeters_.fill(-1.0f);
}

void HarmonyProcessorVST3::resetDefaults() noexcept {
    values_.fill(0.0f);
    for (const auto& spec : parameterSpecs()) {
        if (!spec.readOnly && spec.id < values_.size())
            values_[spec.id] = static_cast<float>(defaultNormalized(spec));
    }
}

tresult PLUGIN_API HarmonyProcessorVST3::initialize(FUnknown* context) {
    const auto result = AudioEffect::initialize(context);
    if (result != kResultOk) return result;

    addAudioInput(STR16("Input"), SpeakerArr::kStereo);
    addAudioOutput(STR16("Output"), SpeakerArr::kStereo);
    addEventInput(STR16("MIDI In"), 16);
    return kResultOk;
}

tresult PLUGIN_API HarmonyProcessorVST3::terminate() {
    monoInput_.clear();
    outputL_.clear();
    outputR_.clear();
    return AudioEffect::terminate();
}

tresult PLUGIN_API HarmonyProcessorVST3::setupProcessing(ProcessSetup& setup) {
    const auto result = AudioEffect::setupProcessing(setup);
    if (result != kResultOk) return result;
    if ((setup.symbolicSampleSize != kSample32 && setup.symbolicSampleSize != kSample64) ||
        setup.sampleRate < 8000.0) return kResultFalse;

    sampleRate_ = setup.sampleRate;
    engine_.prepare(sampleRate_);
    engine_.setParams(readProcessorParams());

    const auto requested = static_cast<std::size_t>(std::max<int32>(1, setup.maxSamplesPerBlock));
    const auto capacity = std::max(kScratchCapacity, requested);
    monoInput_.assign(capacity, 0.0f);
    outputL_.assign(capacity, 0.0f);
    outputR_.assign(capacity, 0.0f);

    // The original lead remains a true zero-latency path. Harmony synthesis
    // has its own intrinsic look-back delay, like a backing singer, but the
    // singer's direct monitor must never be held back by the pitch shifter.

    activeMidiNotes_.fill(false);
    physicalMidiNotes_.fill(false);
    lastMidiHold_ = false;
    lastPublishedMeters_.fill(-1.0f);
    harmonyMetersActive_ = false;
    harmonyWasActive_ = false;
    hostInputPeak_ = hostOutputLPeak_ = hostOutputRPeak_ = 0.0;
    dryInputGainSmooth_ = harmony::dbToGain(static_cast<float>(paramPlain(kInputDb)));
    dryGainSmooth_ = harmony::dbToGain(static_cast<float>(paramPlain(kDryDb)));
    outputGainSmooth_ = harmony::dbToGain(static_cast<float>(paramPlain(kOutputDb)));
    return kResultOk;
}

tresult PLUGIN_API HarmonyProcessorVST3::setActive(TBool state) {
    if (state) {
        engine_.reset();
        harmonyMetersActive_ = false;
        harmonyWasActive_ = false;
        hostInputPeak_ = hostOutputLPeak_ = hostOutputRPeak_ = 0.0;
        dryInputGainSmooth_ = harmony::dbToGain(static_cast<float>(paramPlain(kInputDb)));
        dryGainSmooth_ = harmony::dbToGain(static_cast<float>(paramPlain(kDryDb)));
        outputGainSmooth_ = harmony::dbToGain(static_cast<float>(paramPlain(kOutputDb)));
    } else {
        activeMidiNotes_.fill(false);
        physicalMidiNotes_.fill(false);
    }
    return AudioEffect::setActive(state);
}

tresult PLUGIN_API HarmonyProcessorVST3::setBusArrangements(SpeakerArrangement* inputs,
                                                              int32 numIns,
                                                              SpeakerArrangement* outputs,
                                                              int32 numOuts) {
    if (numIns != 1 || numOuts != 1 || inputs == nullptr || outputs == nullptr) return kResultFalse;
    const int inCh = SpeakerArr::getChannelCount(inputs[0]);
    const int outCh = SpeakerArr::getChannelCount(outputs[0]);
    const bool supported = (inCh == 1 || inCh == 2) && (outCh == 1 || outCh == 2);
    if (!supported) return kResultFalse;

    if (auto* in = getAudioInput(0)) {
        in->setArrangement(inputs[0]);
        in->setName(inCh == 1 ? STR16("Mono In") : STR16("Stereo In"));
    }
    if (auto* out = getAudioOutput(0)) {
        out->setArrangement(outputs[0]);
        out->setName(outCh == 1 ? STR16("Mono Out") : STR16("Stereo Out"));
    }
    return kResultOk;
}

tresult PLUGIN_API HarmonyProcessorVST3::canProcessSampleSize(int32 symbolicSampleSize) {
    return (symbolicSampleSize == kSample32 || symbolicSampleSize == kSample64)
        ? kResultTrue : kResultFalse;
}

double HarmonyProcessorVST3::paramNorm(std::uint32_t id) const noexcept {
    return id < values_.size() ? static_cast<double>(values_[id]) : 0.0;
}

double HarmonyProcessorVST3::paramPlain(std::uint32_t id) const noexcept {
    if (const auto* spec = findSpec(id)) return denormalize(*spec, paramNorm(id));
    return 0.0;
}

void HarmonyProcessorVST3::applyParameterChangesAtOffset(IParameterChanges* changes,
                                                             int32 sampleOffset,
                                                             int32 blockSamples) noexcept {
    if (!changes) return;
    const int32 count = changes->getParameterCount();
    for (int32 i = 0; i < count; ++i) {
        auto* queue = changes->getParameterData(i);
        if (!queue) continue;
        const auto id = static_cast<std::uint32_t>(queue->getParameterId());
        const auto* spec = findSpec(id);
        if (!spec || spec->readOnly || id >= values_.size()) continue;

        const int32 points = queue->getPointCount();
        for (int32 p = 0; p < points; ++p) {
            int32 pointOffset = 0;
            ParamValue value = 0.0;
            if (queue->getPoint(p, pointOffset, value) != kResultTrue) continue;
            pointOffset = std::clamp(pointOffset, 0, std::max<int32>(0, blockSamples));
            if (pointOffset == sampleOffset)
                values_[id] = static_cast<float>(clamp01(value));
        }
    }
}

int32 HarmonyProcessorVST3::nextParameterChangeOffset(IParameterChanges* changes,
                                                        int32 afterOffset,
                                                        int32 blockSamples) const noexcept {
    int32 next = blockSamples;
    if (!changes) return next;
    const int32 count = changes->getParameterCount();
    for (int32 i = 0; i < count; ++i) {
        auto* queue = changes->getParameterData(i);
        if (!queue) continue;
        const int32 points = queue->getPointCount();
        for (int32 p = 0; p < points; ++p) {
            int32 pointOffset = 0;
            ParamValue value = 0.0;
            if (queue->getPoint(p, pointOffset, value) != kResultTrue) continue;
            pointOffset = std::clamp(pointOffset, 0, blockSamples);
            if (pointOffset > afterOffset && pointOffset < next) next = pointOffset;
        }
    }
    return next;
}

void HarmonyProcessorVST3::rebuildMidiChord() noexcept {
    std::array<int, 16> notes{};
    std::size_t noteCount = 0;
    for (int n = 0; n < 128 && noteCount < notes.size(); ++n) {
        if (activeMidiNotes_[static_cast<std::size_t>(n)]) notes[noteCount++] = n;
    }
    engine_.setChordNotes(notes.data(), noteCount);
}

void HarmonyProcessorVST3::applyMidiAtOffset(IEventList* events,
                                               int32 sampleOffset,
                                               int32 blockSamples) noexcept {
    const bool hold = paramPlain(kMidiHold) >= 0.5;
    const int channelChoice = std::clamp(static_cast<int>(std::lround(paramPlain(kMidiChannel))), 0, 16);

    bool changed = false;
    if (!hold && lastMidiHold_) {
        activeMidiNotes_ = physicalMidiNotes_;
        changed = true;
    }

    if (events) {
        const int32 count = events->getEventCount();
        for (int32 i = 0; i < count; ++i) {
            Event e{};
            if (events->getEvent(i, e) != kResultOk) continue;
            const int32 eventOffset = std::clamp(e.sampleOffset, 0, std::max<int32>(0, blockSamples));
            if (eventOffset != sampleOffset) continue;

            if (e.type == Event::kNoteOnEvent) {
                if (channelChoice != 0 && e.noteOn.channel != channelChoice - 1) continue;
                const int note = std::clamp<int>(e.noteOn.pitch, 0, 127);
                const bool hadPhysical = std::any_of(physicalMidiNotes_.begin(), physicalMidiNotes_.end(), [](bool x) { return x; });
                if (hold && !hadPhysical) activeMidiNotes_.fill(false);
                physicalMidiNotes_[static_cast<std::size_t>(note)] = true;
                activeMidiNotes_[static_cast<std::size_t>(note)] = true;
                changed = true;
            } else if (e.type == Event::kNoteOffEvent) {
                if (channelChoice != 0 && e.noteOff.channel != channelChoice - 1) continue;
                const int note = std::clamp<int>(e.noteOff.pitch, 0, 127);
                physicalMidiNotes_[static_cast<std::size_t>(note)] = false;
                if (!hold) activeMidiNotes_[static_cast<std::size_t>(note)] = false;
                changed = true;
            }
        }
    }

    lastMidiHold_ = hold;
    if (changed) rebuildMidiChord();
}

int32 HarmonyProcessorVST3::nextMidiOffset(IEventList* events,
                                             int32 afterOffset,
                                             int32 blockSamples) const noexcept {
    int32 next = blockSamples;
    if (!events) return next;
    const int32 count = events->getEventCount();
    for (int32 i = 0; i < count; ++i) {
        Event e{};
        if (events->getEvent(i, e) != kResultOk) continue;
        const int32 eventOffset = std::clamp(e.sampleOffset, 0, blockSamples);
        if (eventOffset > afterOffset && eventOffset < next) next = eventOffset;
    }
    return next;
}

harmony::ProcessorParams HarmonyProcessorVST3::readProcessorParams() const noexcept {
    harmony::ProcessorParams p;
    p.inputDb = static_cast<float>(paramPlain(kInputDb));
    p.outputDb = 0.0f;
    p.dryDb = -120.0f;
    p.wetDb = static_cast<float>(paramPlain(kWetDb));
    p.harmonyWidth = 0.0f;
    p.tuningHz = 440.0f;
    p.tightness = 0.72f;
    p.pitchSmoothingMs = 18.0f;
    p.humanize = 0.0f;
    p.formantPreserve = 1.0f;
    p.transientProtection = 0.92f;
    p.unvoicedPreserve = 0.96f;
    p.autoKeyThreshold = 1.0f;
    p.mode = harmony::HarmonyMode::KeyScale;
    p.keyRoot = std::clamp(static_cast<int>(std::lround(paramPlain(kKey))), 0, 11);
    p.scale = static_cast<harmony::ScaleType>(std::clamp(static_cast<int>(std::lround(paramPlain(kScale))), 0, 8));

    auto& vp = p.voices[0];
    const bool explicitEnable = paramPlain(voiceParamId(0, kVoiceEnable)) >= 0.5;
    vp.mute = paramPlain(voiceParamId(0, kVoiceMute)) >= 0.5;
    vp.solo = paramPlain(voiceParamId(0, kVoiceSolo)) >= 0.5;
    vp.rule.enabled = explicitEnable || vp.solo;
    const int preset = std::clamp(static_cast<int>(std::lround(paramPlain(voiceParamId(0, kVoiceHarmonyPreset)))), 1, 6);
    vp.preset = static_cast<harmony::HarmonyIntervalPreset>(preset);
    vp.levelDb = static_cast<float>(paramPlain(voiceParamId(0, kVoiceLevel)));
    vp.pan = 0.0f;
    vp.formantSemitones = 0.0f;
    vp.detuneCents = 0.0f;
    vp.humanizeCents = 0.0f;
    vp.delayMs = 0.0f;
    vp.vibratoCents = 0.0f;
    vp.vibratoRateHz = 5.2f;
    vp.choirVoices = 1;
    vp.choirSpread = 0.0f;
    vp.choirDepth = 0.0f;
    vp.minMidi = 24;
    vp.maxMidi = 108;
    for (std::size_t i = 1; i < p.voices.size(); ++i) {
        p.voices[i].rule.enabled = false;
        p.voices[i].mute = true;
        p.voices[i].solo = false;
    }
    return p;
}

tresult PLUGIN_API HarmonyProcessorVST3::process(ProcessData& data) {
    if (data.symbolicSampleSize != kSample32 && data.symbolicSampleSize != kSample64)
        return kResultFalse;

    if (data.numSamples <= 0 || data.numInputs <= 0 || data.numOutputs <= 0 || !data.inputs || !data.outputs) {
        applyParameterChangesAtOffset(data.inputParameterChanges, 0, std::max<int32>(0, data.numSamples));
        applyMidiAtOffset(data.inputEvents, 0, std::max<int32>(0, data.numSamples));
        engine_.setParams(readProcessorParams());
        publishMeters(data);
        return kResultOk;
    }

    auto& inBus = data.inputs[0];
    auto& outBus = data.outputs[0];
    if (inBus.numChannels <= 0 || outBus.numChannels <= 0) return kResultFalse;

    const auto scratchCapacity = std::min({monoInput_.size(), outputL_.size(), outputR_.size()});
    if (scratchCapacity == 0U) return kResultFalse;
    hostInputPeak_ = hostOutputLPeak_ = hostOutputRPeak_ = 0.0;
    harmonyMetersActive_ = false;
    bool sawBypass = false;
    bool sawActive = false;

    auto processRange = [&](auto* in0, auto* in1, auto* out0, auto* out1, int32 rangeStart, int32 rangeCount) {
        using Sample = std::remove_cv_t<std::remove_pointer_t<decltype(out0)>>;
        int32 localOffset = 0;
        while (localOffset < rangeCount) {
            const int32 chunk = std::min<int32>(rangeCount - localOffset, static_cast<int32>(scratchCapacity));
            const int32 base = rangeStart + localOffset;

            const bool bypass = paramPlain(kBypass) >= 0.5;

            std::array<VoiceAuditionState, 4> auditionVoices{};
            auditionVoices[0] = {
                paramPlain(voiceParamId(0, kVoiceEnable)) >= 0.5,
                paramPlain(voiceParamId(0, kVoiceMute)) >= 0.5,
                paramPlain(voiceParamId(0, kVoiceSolo)) >= 0.5
            };
            for (int v = 1; v < 4; ++v) auditionVoices[static_cast<std::size_t>(v)] = {false, true, false};
            const auto audition = decideAudition(auditionVoices, paramPlain(kLeadMute) >= 0.5);
            const bool harmonyActive = audition.harmonyActive;
            const bool leadAudible = audition.leadAudible;

            sawBypass = sawBypass || bypass;
            sawActive = sawActive || !bypass;

            if (!bypass && harmonyActive) {
                // Build the mono analysis/synthesis input only when at least one
                // harmony voice is actually audible. With all voices off the
                // expensive pitch tracker and STFT path stay completely asleep.
                for (int32 i = 0; i < chunk; ++i) {
                    const int32 sidx = base + i;
                    const double l = static_cast<double>(in0[sidx]);
                    const double r = in1 ? static_cast<double>(in1[sidx]) : l;
                    monoInput_[static_cast<std::size_t>(i)] = static_cast<float>(in1 ? 0.5 * (l + r) : l);
                }
                if (!harmonyWasActive_) {
                    engine_.reset();
                    engine_.setParams(readProcessorParams());
                }
                engine_.processBlock(monoInput_.data(), outputL_.data(), outputR_.data(),
                                     static_cast<std::size_t>(chunk));
                harmonyMetersActive_ = true;
            }
            harmonyWasActive_ = (!bypass && harmonyActive);

            const double targetInputGain = harmony::dbToGain(static_cast<float>(paramPlain(kInputDb)));
            const double targetDryGain = harmony::dbToGain(static_cast<float>(paramPlain(kDryDb)));
            const double targetOutputGain = harmony::dbToGain(static_cast<float>(paramPlain(kOutputDb)));
            const double mixCoeff = std::exp(-1.0 / std::max(1.0, sampleRate_ * 0.012));

            for (int32 i = 0; i < chunk; ++i) {
                const int32 sidx = base + i;
                const double srcL = static_cast<double>(in0[sidx]);
                const double srcR = in1 ? static_cast<double>(in1[sidx]) : srcL;


                dryInputGainSmooth_ = mixCoeff * dryInputGainSmooth_ + (1.0 - mixCoeff) * targetInputGain;
                dryGainSmooth_ = mixCoeff * dryGainSmooth_ + (1.0 - mixCoeff) * targetDryGain;
                outputGainSmooth_ = mixCoeff * outputGainSmooth_ + (1.0 - mixCoeff) * targetOutputGain;

                double yL = 0.0;
                double yR = 0.0;
                if (bypass) {
                    // True bypass is immediate and bit-transparent apart from
                    // the host sample-format conversion already in use.
                    yL = srcL;
                    yR = srcR;
                } else {
                    const double dryL = leadAudible ? srcL * dryInputGainSmooth_ * dryGainSmooth_ : 0.0;
                    const double dryR = leadAudible ? srcR * dryInputGainSmooth_ * dryGainSmooth_ : 0.0;
                    const double wetL = harmonyActive ? static_cast<double>(outputL_[static_cast<std::size_t>(i)]) : 0.0;
                    const double wetR = harmonyActive ? static_cast<double>(outputR_[static_cast<std::size_t>(i)]) : 0.0;
                    yL = (dryL + wetL) * outputGainSmooth_;
                    yR = (dryR + wetR) * outputGainSmooth_;
                }

                const double monoOut = 0.5 * (yL + yR);
                out0[sidx] = static_cast<Sample>(out1 ? yL : monoOut);
                if (out1) out1[sidx] = static_cast<Sample>(yR);

                hostInputPeak_ = std::max(hostInputPeak_, std::max(std::abs(srcL), std::abs(srcR)));
                hostOutputLPeak_ = std::max(hostOutputLPeak_, std::abs(out1 ? yL : monoOut));
                hostOutputRPeak_ = std::max(hostOutputRPeak_, std::abs(out1 ? yR : monoOut));
            }
            localOffset += chunk;
        }
    };
    int32 cursor = 0;
    while (cursor < data.numSamples) {
        applyParameterChangesAtOffset(data.inputParameterChanges, cursor, data.numSamples);
        applyMidiAtOffset(data.inputEvents, cursor, data.numSamples);
        engine_.setParams(readProcessorParams());

        const int32 nextParam = nextParameterChangeOffset(data.inputParameterChanges, cursor, data.numSamples);
        const int32 nextMidi = nextMidiOffset(data.inputEvents, cursor, data.numSamples);
        const int32 next = std::min({data.numSamples, nextParam, nextMidi});
        const int32 count = std::max<int32>(0, next - cursor);
        if (count == 0) {
            if (cursor >= data.numSamples) break;
            ++cursor;
            continue;
        }

        if (data.symbolicSampleSize == kSample32) {
            if (!inBus.channelBuffers32 || !outBus.channelBuffers32) return kResultFalse;
            const float* in0 = inBus.channelBuffers32[0];
            const float* in1 = inBus.numChannels > 1 ? inBus.channelBuffers32[1] : nullptr;
            float* out0 = outBus.channelBuffers32[0];
            float* out1 = outBus.numChannels > 1 ? outBus.channelBuffers32[1] : nullptr;
            if (!in0 || !out0) return kResultFalse;
            processRange(in0, in1, out0, out1, cursor, count);
        } else {
            if (!inBus.channelBuffers64 || !outBus.channelBuffers64) return kResultFalse;
            const double* in0 = inBus.channelBuffers64[0];
            const double* in1 = inBus.numChannels > 1 ? inBus.channelBuffers64[1] : nullptr;
            double* out0 = outBus.channelBuffers64[0];
            double* out1 = outBus.numChannels > 1 ? outBus.channelBuffers64[1] : nullptr;
            if (!in0 || !out0) return kResultFalse;
            processRange(in0, in1, out0, out1, cursor, count);
        }
        cursor = next;
    }

    // Apply points explicitly located at the block end so the next block starts
    // from the exact host state.
    applyParameterChangesAtOffset(data.inputParameterChanges, data.numSamples, data.numSamples);
    applyMidiAtOffset(data.inputEvents, data.numSamples, data.numSamples);
    engine_.setParams(readProcessorParams());

    bypassMeters_ = sawBypass && !sawActive;
    outBus.silenceFlags = 0;
    publishMeters(data);
    return kResultOk;
}

void HarmonyProcessorVST3::writeMeter(IParameterChanges* changes, ParamID id, double normalized, int32 sampleOffset) noexcept {
    if (!changes || id >= lastPublishedMeters_.size()) return;
    const float v = static_cast<float>(clamp01(normalized));
    const float old = lastPublishedMeters_[id];
    if (old >= 0.0f && std::abs(old - v) < 0.0005f) return;
    int32 queueIndex = 0;
    if (auto* q = changes->addParameterData(id, queueIndex)) {
        int32 pointIndex = 0;
        if (q->addPoint(sampleOffset, v, pointIndex) == kResultTrue) lastPublishedMeters_[id] = v;
    }
}

void HarmonyProcessorVST3::publishMeters(ProcessData& data) noexcept {
    auto* changes = data.outputParameterChanges;
    if (!changes) return;
    const int32 sampleOffset = std::max<int32>(0, data.numSamples - 1);
    writeMeter(changes, kMeterInput, std::clamp<double>(hostInputPeak_, 0.0, 1.0), sampleOffset);
    writeMeter(changes, kMeterOutputL, std::clamp<double>(hostOutputLPeak_, 0.0, 1.0), sampleOffset);
    writeMeter(changes, kMeterOutputR, std::clamp<double>(hostOutputRPeak_, 0.0, 1.0), sampleOffset);

    if (bypassMeters_ || !harmonyMetersActive_) {
        writeMeter(changes, kMeterVoice1, 0.0, sampleOffset);
        writeMeter(changes, kMeterVoice2, 0.0, sampleOffset);
        writeMeter(changes, kMeterVoice3, 0.0, sampleOffset);
        writeMeter(changes, kMeterVoice4, 0.0, sampleOffset);
        if (const auto* s = findSpec(kMeterPitchMidi)) writeMeter(changes, kMeterPitchMidi, normalizePlain(*s, 0.0), sampleOffset);
        if (findSpec(kMeterPitchConfidence)) writeMeter(changes, kMeterPitchConfidence, 0.0, sampleOffset);
        if (findSpec(kMeterKeyConfidence)) writeMeter(changes, kMeterKeyConfidence, 0.0, sampleOffset);
        const std::uint32_t tids[4] = {kMeterTarget1,kMeterTarget2,kMeterTarget3,kMeterTarget4};
        for (auto id : tids) if (const auto* s = findSpec(id)) writeMeter(changes, id, normalizePlain(*s, -1.0), sampleOffset);
        return;
    }

    const auto m = engine_.meters();
    writeMeter(changes, kMeterVoice1, std::clamp<double>(m.voicePeak[0], 0.0, 1.0), sampleOffset);
    writeMeter(changes, kMeterVoice2, std::clamp<double>(m.voicePeak[1], 0.0, 1.0), sampleOffset);
    writeMeter(changes, kMeterVoice3, std::clamp<double>(m.voicePeak[2], 0.0, 1.0), sampleOffset);
    writeMeter(changes, kMeterVoice4, std::clamp<double>(m.voicePeak[3], 0.0, 1.0), sampleOffset);
    if (const auto* s = findSpec(kMeterPitchMidi)) writeMeter(changes, kMeterPitchMidi, normalizePlain(*s, m.pitchMidi), sampleOffset);
    if (const auto* s = findSpec(kMeterPitchConfidence)) writeMeter(changes, kMeterPitchConfidence, normalizePlain(*s, m.pitchConfidence * 100.0), sampleOffset);
    if (const auto* s = findSpec(kMeterDetectedKey)) writeMeter(changes, kMeterDetectedKey, normalizePlain(*s, m.detectedKeyRoot), sampleOffset);
    if (const auto* s = findSpec(kMeterDetectedScale)) writeMeter(changes, kMeterDetectedScale, normalizePlain(*s, static_cast<int>(m.detectedScale)), sampleOffset);
    if (const auto* s = findSpec(kMeterKeyConfidence)) writeMeter(changes, kMeterKeyConfidence, normalizePlain(*s, m.keyConfidence * 100.0), sampleOffset);
    const auto target = engine_.targetNotes();
    const std::uint32_t targetIds[4] = {kMeterTarget1, kMeterTarget2, kMeterTarget3, kMeterTarget4};
    for (int i = 0; i < 4; ++i) if (const auto* s = findSpec(targetIds[i])) writeMeter(changes, targetIds[i], normalizePlain(*s, target[static_cast<std::size_t>(i)]), sampleOffset);
}

tresult PLUGIN_API HarmonyProcessorVST3::getState(IBStream* state) {
    if (!state) return kInvalidArgument;
    IBStreamer stream(state, kLittleEndian);
    const auto edit = editableSpecs();
    if (!stream.writeInt32(static_cast<int32>(kStateMagic))) return kResultFalse;
    if (!stream.writeInt32(static_cast<int32>(kStateVersion))) return kResultFalse;
    if (!stream.writeInt32(static_cast<int32>(edit.size()))) return kResultFalse;
    for (const auto* spec : edit) {
        if (!stream.writeInt32(static_cast<int32>(spec->id))) return kResultFalse;
        if (!stream.writeFloat(values_[spec->id])) return kResultFalse;
    }
    return kResultOk;
}

tresult PLUGIN_API HarmonyProcessorVST3::setState(IBStream* state) {
    if (!state) return kInvalidArgument;
    IBStreamer stream(state, kLittleEndian);
    int32 magic = 0, version = 0, count = 0;
    if (!stream.readInt32(magic) || static_cast<std::uint32_t>(magic) != kStateMagic) return kResultFalse;
    if (!stream.readInt32(version) || version < 1 || version > static_cast<int32>(kStateVersion)) return kResultFalse;
    if (!stream.readInt32(count) || count < 0 || count > 512) return kResultFalse;
    for (int32 i = 0; i < count; ++i) {
        int32 id = 0;
        float value = 0.0f;
        if (!stream.readInt32(id) || !stream.readFloat(value)) return kResultFalse;
        if (id >= 0 && static_cast<std::size_t>(id) < values_.size()) {
            const auto* spec = findSpec(static_cast<std::uint32_t>(id));
            if (spec && !spec->readOnly) values_[static_cast<std::size_t>(id)] = static_cast<float>(clamp01(value));
        }
    }
    engine_.setParams(readProcessorParams());
    return kResultOk;
}

uint32 PLUGIN_API HarmonyProcessorVST3::getLatencySamples() {
    // The direct lead/bypass path is zero latency. Reporting the harmony
    // shifter's analysis window here would make Cubase delay the singer too,
    // which is exactly the monitoring latency the user rejected.
    return 0;
}

uint32 PLUGIN_API HarmonyProcessorVST3::getTailSamples() {
    return static_cast<uint32>(std::max(0.0, sampleRate_ * 0.25));
}

} // namespace harmonyplugin
