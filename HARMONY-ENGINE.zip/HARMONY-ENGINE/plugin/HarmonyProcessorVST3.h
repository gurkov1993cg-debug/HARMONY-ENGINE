#pragma once

#include "public.sdk/source/vst/vstaudioeffect.h"
#include "harmony/HarmonyProcessor.h"
#include "Parameters.h"

#include <array>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace harmonyplugin {

class HarmonyProcessorVST3 final : public Steinberg::Vst::AudioEffect {
public:
    HarmonyProcessorVST3();
    ~HarmonyProcessorVST3() override = default;

    static Steinberg::FUnknown* createInstance(void*) {
        return static_cast<Steinberg::Vst::IAudioProcessor*>(new HarmonyProcessorVST3());
    }

    Steinberg::tresult PLUGIN_API initialize(Steinberg::FUnknown* context) SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API terminate() SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API setupProcessing(Steinberg::Vst::ProcessSetup& setup) SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API setActive(Steinberg::TBool state) SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API setBusArrangements(Steinberg::Vst::SpeakerArrangement* inputs,
                                                    Steinberg::int32 numIns,
                                                    Steinberg::Vst::SpeakerArrangement* outputs,
                                                    Steinberg::int32 numOuts) SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API canProcessSampleSize(Steinberg::int32 symbolicSampleSize) SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API process(Steinberg::Vst::ProcessData& data) SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API setState(Steinberg::IBStream* state) SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API getState(Steinberg::IBStream* state) SMTG_OVERRIDE;
    Steinberg::uint32 PLUGIN_API getLatencySamples() SMTG_OVERRIDE;
    Steinberg::uint32 PLUGIN_API getTailSamples() SMTG_OVERRIDE;

private:
    static constexpr std::size_t kScratchCapacity = 8192U;
    static constexpr std::uint32_t kStateMagic = 0x48454E47U; // HENG
    static constexpr std::uint32_t kStateVersion = 2U;

    void resetDefaults() noexcept;
    void applyParameterChanges(Steinberg::Vst::IParameterChanges* changes) noexcept;
    void applyMidi(Steinberg::Vst::IEventList* events) noexcept;
    harmony::ProcessorParams readProcessorParams() const noexcept;
    double paramPlain(std::uint32_t id) const noexcept;
    double paramNorm(std::uint32_t id) const noexcept;
    void publishMeters(Steinberg::Vst::ProcessData& data) noexcept;
    void writeMeter(Steinberg::Vst::IParameterChanges* changes,
                    Steinberg::Vst::ParamID id,
                    double normalized,
                    Steinberg::int32 sampleOffset) noexcept;

    harmony::HarmonyProcessor engine_;
    std::array<float, kParamStorageSize> values_{};
    std::array<float, kParamStorageSize> lastPublishedMeters_{};

    std::array<bool, 128> activeMidiNotes_{};
    std::array<bool, 128> physicalMidiNotes_{};
    bool lastMidiHold_ = false;

    std::vector<float> monoInput_;
    std::vector<float> outputL_;
    std::vector<float> outputR_;
    std::vector<float> bypassDelayL_;
    std::vector<float> bypassDelayR_;
    std::size_t bypassWrite_ = 0;
    double sampleRate_ = 48000.0;
    bool bypassMeters_ = false;
    float bypassInputPeak_ = 0.0f;
    float bypassOutputLPeak_ = 0.0f;
    float bypassOutputRPeak_ = 0.0f;
};

} // namespace harmonyplugin
