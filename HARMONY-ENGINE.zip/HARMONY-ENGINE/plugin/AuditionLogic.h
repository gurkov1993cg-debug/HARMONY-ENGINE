#pragma once
#include <array>
#include <cstddef>

namespace harmonyplugin {

struct VoiceAuditionState {
    bool enabled = false;
    bool mute = false;
    bool solo = false;
};

struct AuditionDecision {
    bool anySolo = false;
    bool leadAudible = true;
    bool harmonyActive = false;
    std::array<bool, 4> voiceAudible{{false, false, false, false}};
};

inline AuditionDecision decideAudition(const std::array<VoiceAuditionState, 4>& voices,
                                       bool leadMute) noexcept {
    AuditionDecision d;
    for (const auto& v : voices)
        if (!v.mute && v.solo) d.anySolo = true;

    d.leadAudible = !leadMute && !d.anySolo;
    for (std::size_t i = 0; i < voices.size(); ++i) {
        const auto& v = voices[i];
        const bool effectiveEnabled = v.enabled || v.solo;
        d.voiceAudible[i] = effectiveEnabled && !v.mute && (!d.anySolo || v.solo);
        d.harmonyActive = d.harmonyActive || d.voiceAudible[i];
    }
    return d;
}

} // namespace harmonyplugin
