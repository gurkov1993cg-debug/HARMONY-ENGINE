#pragma once

#include "public.sdk/source/vst/vsteditcontroller.h"

namespace harmonyplugin {

class HarmonyController final : public Steinberg::Vst::EditControllerEx1 {
public:
    HarmonyController() = default;
    ~HarmonyController() override = default;

    static Steinberg::FUnknown* createInstance(void*) {
        return static_cast<Steinberg::Vst::IEditController*>(new HarmonyController());
    }

    Steinberg::tresult PLUGIN_API initialize(Steinberg::FUnknown* context) SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API terminate() SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API setComponentState(Steinberg::IBStream* state) SMTG_OVERRIDE;
    Steinberg::IPlugView* PLUGIN_API createView(const char* name) SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API setState(Steinberg::IBStream* state) SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API getState(Steinberg::IBStream* state) SMTG_OVERRIDE;

    bool setFromUI(Steinberg::Vst::ParamID id, double normalized, bool begin, bool end);
};

} // namespace harmonyplugin
