#pragma once
#include <JuceHeader.h>

namespace harmonyplugin {
inline juce::String voiceId(int voice, const juce::String& suffix) {
    return "v" + juce::String(voice + 1) + "_" + suffix;
}

inline juce::StringArray keyNames() {
    return {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
}

inline juce::StringArray scaleNames() {
    return {"Major", "Natural Minor", "Harmonic Minor", "Melodic Minor", "Dorian", "Phrygian", "Lydian", "Mixolydian", "Locrian"};
}

inline juce::StringArray harmonyModeNames() {
    return {"Key / Scale", "Manual Chord", "MIDI Chord", "Auto Key"};
}

inline juce::StringArray midiChannelNames() {
    juce::StringArray names;
    names.add("Omni");
    for (int ch = 1; ch <= 16; ++ch) names.add(juce::String(ch));
    return names;
}

inline juce::StringArray chordTypeNames() {
    return {"Major", "Minor", "Diminished", "Augmented", "Sus2", "Sus4", "Major 7", "Minor 7", "Dominant 7", "Half-Dim 7", "Dim 7", "Add 9", "Minor Add 9", "Major 6", "Minor 6"};
}

inline juce::StringArray choirSizeNames() {
    return {"1", "2", "4", "8"};
}

inline juce::StringArray voiceModeNames() {
    return {"Scale Degree", "Chromatic", "Chord Tone"};
}

inline juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout() {
    using APF = juce::AudioParameterFloat;
    using API = juce::AudioParameterInt;
    using APB = juce::AudioParameterBool;
    using APC = juce::AudioParameterChoice;
    using PID = juce::ParameterID;

    juce::AudioProcessorValueTreeState::ParameterLayout layout;
    layout.add(std::make_unique<APB>(PID{"bypass", 1}, "Bypass", false));
    layout.add(std::make_unique<APF>(PID{"inputDb", 1}, "Input", juce::NormalisableRange<float>{-24.0f, 24.0f, 0.01f}, 0.0f, "dB"));
    layout.add(std::make_unique<APF>(PID{"outputDb", 1}, "Output", juce::NormalisableRange<float>{-24.0f, 24.0f, 0.01f}, 0.0f, "dB"));
    layout.add(std::make_unique<APF>(PID{"dryDb", 1}, "Dry", juce::NormalisableRange<float>{-60.0f, 6.0f, 0.01f}, -3.0f, "dB"));
    layout.add(std::make_unique<APF>(PID{"wetDb", 1}, "Harmony", juce::NormalisableRange<float>{-60.0f, 6.0f, 0.01f}, -3.0f, "dB"));
    layout.add(std::make_unique<APF>(PID{"harmonyWidth", 1}, "Harmony Width", juce::NormalisableRange<float>{0.0f, 200.0f, 0.1f}, 100.0f, "%"));
    layout.add(std::make_unique<APF>(PID{"tuningHz", 1}, "Reference A4", juce::NormalisableRange<float>{400.0f, 480.0f, 0.1f}, 440.0f, "Hz"));
    layout.add(std::make_unique<APC>(PID{"mode", 1}, "Harmony Mode", harmonyModeNames(), 0));
    layout.add(std::make_unique<APC>(PID{"key", 1}, "Key", keyNames(), 0));
    layout.add(std::make_unique<APC>(PID{"scale", 1}, "Scale", scaleNames(), 0));
    layout.add(std::make_unique<APC>(PID{"chordRoot", 1}, "Chord Root", keyNames(), 0));
    layout.add(std::make_unique<APC>(PID{"chordType", 1}, "Chord Type", chordTypeNames(), 0));
    layout.add(std::make_unique<APC>(PID{"midiChannel", 1}, "MIDI Channel", midiChannelNames(), 0));
    layout.add(std::make_unique<APB>(PID{"midiHold", 1}, "MIDI Chord Hold", false));
    layout.add(std::make_unique<APF>(PID{"autoKeyThreshold", 1}, "Auto Key Threshold", juce::NormalisableRange<float>{0.0f, 100.0f, 0.1f}, 12.0f, "%"));
    layout.add(std::make_unique<APF>(PID{"tightness", 1}, "Tightness", juce::NormalisableRange<float>{0.0f, 100.0f, 0.1f}, 18.0f, "%"));
    layout.add(std::make_unique<APF>(PID{"smoothingMs", 1}, "Pitch Glide", juce::NormalisableRange<float>{1.0f, 120.0f, 0.1f, 0.45f}, 9.0f, "ms"));
    layout.add(std::make_unique<APF>(PID{"humanize", 1}, "Humanize", juce::NormalisableRange<float>{0.0f, 100.0f, 0.1f}, 35.0f, "%"));
    layout.add(std::make_unique<APF>(PID{"formantPreserve", 1}, "Formant Preserve", juce::NormalisableRange<float>{0.0f, 100.0f, 0.1f}, 100.0f, "%"));
    layout.add(std::make_unique<APF>(PID{"transientProtect", 1}, "Transient Protect", juce::NormalisableRange<float>{0.0f, 100.0f, 0.1f}, 85.0f, "%"));
    layout.add(std::make_unique<APF>(PID{"unvoicedPreserve", 1}, "Consonant Protect", juce::NormalisableRange<float>{0.0f, 100.0f, 0.1f}, 92.0f, "%"));

    const std::array<int, 4> defaultIntervals {{2, -2, 4, 0}};
    const std::array<int, 4> defaultOctaves {{0, 0, 0, 1}};
    const std::array<float, 4> defaultLevels {{-8.0f, -9.0f, -12.0f, -14.0f}};
    const std::array<float, 4> defaultPans {{-0.28f, 0.28f, -0.58f, 0.58f}};
    const std::array<bool, 4> defaultEnabled {{true, true, false, false}};
    const std::array<float, 4> defaultDelay {{5.0f, 9.0f, 13.0f, 17.0f}};

    for (int v = 0; v < 4; ++v) {
        const juce::String label = "Voice " + juce::String(v + 1) + " ";
        layout.add(std::make_unique<APB>(PID{voiceId(v, "enable"), 1}, label + "Enable", defaultEnabled[static_cast<std::size_t>(v)]));
        layout.add(std::make_unique<APB>(PID{voiceId(v, "mute"), 1}, label + "Mute", false));
        layout.add(std::make_unique<APB>(PID{voiceId(v, "solo"), 1}, label + "Solo", false));
        layout.add(std::make_unique<APC>(PID{voiceId(v, "mode"), 1}, label + "Mode", voiceModeNames(), 0));
        layout.add(std::make_unique<API>(PID{voiceId(v, "interval"), 1}, label + "Interval", -12, 12, defaultIntervals[static_cast<std::size_t>(v)]));
        layout.add(std::make_unique<API>(PID{voiceId(v, "octave"), 1}, label + "Octave", -2, 2, defaultOctaves[static_cast<std::size_t>(v)]));
        layout.add(std::make_unique<APF>(PID{voiceId(v, "level"), 1}, label + "Level", juce::NormalisableRange<float>{-60.0f, 6.0f, 0.01f}, defaultLevels[static_cast<std::size_t>(v)], "dB"));
        layout.add(std::make_unique<APF>(PID{voiceId(v, "pan"), 1}, label + "Pan", juce::NormalisableRange<float>{-100.0f, 100.0f, 0.1f}, defaultPans[static_cast<std::size_t>(v)] * 100.0f, "%"));
        layout.add(std::make_unique<APF>(PID{voiceId(v, "formant"), 1}, label + "Formant", juce::NormalisableRange<float>{-12.0f, 12.0f, 0.01f}, 0.0f, "st"));
        layout.add(std::make_unique<APF>(PID{voiceId(v, "detune"), 1}, label + "Detune", juce::NormalisableRange<float>{-50.0f, 50.0f, 0.1f}, 0.0f, "ct"));
        layout.add(std::make_unique<APF>(PID{voiceId(v, "humanizeCents"), 1}, label + "Pitch Humanize", juce::NormalisableRange<float>{0.0f, 18.0f, 0.1f}, 3.0f, "ct"));
        layout.add(std::make_unique<APF>(PID{voiceId(v, "delayMs"), 1}, label + "Timing", juce::NormalisableRange<float>{0.0f, 80.0f, 0.1f}, defaultDelay[static_cast<std::size_t>(v)], "ms"));
        layout.add(std::make_unique<APF>(PID{voiceId(v, "vibratoCents"), 1}, label + "Vibrato Depth", juce::NormalisableRange<float>{0.0f, 100.0f, 0.1f}, 0.0f, "ct"));
        layout.add(std::make_unique<APF>(PID{voiceId(v, "vibratoRate"), 1}, label + "Vibrato Rate", juce::NormalisableRange<float>{0.1f, 12.0f, 0.01f}, 5.2f, "Hz"));
        layout.add(std::make_unique<APC>(PID{voiceId(v, "choirVoices"), 1}, label + "Choir Voices", choirSizeNames(), 0));
        layout.add(std::make_unique<APF>(PID{voiceId(v, "choirSpread"), 1}, label + "Choir Spread", juce::NormalisableRange<float>{0.0f, 100.0f, 0.1f}, 0.0f, "%"));
        layout.add(std::make_unique<APF>(PID{voiceId(v, "choirDepth"), 1}, label + "Choir Depth", juce::NormalisableRange<float>{0.0f, 100.0f, 0.1f}, 0.0f, "%"));
        layout.add(std::make_unique<API>(PID{voiceId(v, "minMidi"), 1}, label + "Low Range", 24, 84, 36));
        layout.add(std::make_unique<API>(PID{voiceId(v, "maxMidi"), 1}, label + "High Range", 48, 120, 96));
    }
    return layout;
}
}
