#pragma once
#include <array>
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace harmonyplugin {

enum class ParamKind : std::uint8_t { Continuous, Integer, Toggle, Choice, Meter };

struct ParamSpec {
    std::uint32_t id = 0;
    const char* name = "";
    const char* unit = "";
    ParamKind kind = ParamKind::Continuous;
    double minPlain = 0.0;
    double maxPlain = 1.0;
    double defaultPlain = 0.0;
    const char* const* choices = nullptr;
    int choiceCount = 0;
    bool bypass = false;
    bool readOnly = false;
};

enum GlobalParamID : std::uint32_t {
    kBypass = 100,
    kInputDb,
    kOutputDb,
    kDryDb,
    kWetDb,
    kHarmonyWidth,
    kTuningHz,
    kMode,
    kKey,
    kScale,
    kChordRoot,
    kChordType,
    kMidiChannel,
    kMidiHold,
    kAutoKeyThreshold,
    kTightness,
    kSmoothingMs,
    kHumanize,
    kFormantPreserve,
    kTransientProtect,
    kUnvoicedPreserve
};

enum VoiceParamOffset : std::uint32_t {
    kVoiceEnable = 0,
    kVoiceMute,
    kVoiceSolo,
    kVoiceMode,
    kVoiceInterval,
    kVoiceOctave,
    kVoiceLevel,
    kVoicePan,
    kVoiceFormant,
    kVoiceDetune,
    kVoiceHumanizeCents,
    kVoiceDelayMs,
    kVoiceVibratoCents,
    kVoiceVibratoRate,
    kVoiceChoirVoices,
    kVoiceChoirSpread,
    kVoiceChoirDepth,
    kVoiceMinMidi,
    kVoiceMaxMidi
};

constexpr std::uint32_t kVoiceBase = 1000;
constexpr std::uint32_t kVoiceStride = 100;
constexpr std::uint32_t voiceParamId(int voice, VoiceParamOffset offset) noexcept {
    return kVoiceBase + static_cast<std::uint32_t>(voice) * kVoiceStride + static_cast<std::uint32_t>(offset);
}

enum MeterParamID : std::uint32_t {
    kMeterInput = 5000,
    kMeterOutputL,
    kMeterOutputR,
    kMeterVoice1,
    kMeterVoice2,
    kMeterVoice3,
    kMeterVoice4,
    kMeterPitchMidi,
    kMeterPitchConfidence,
    kMeterDetectedKey,
    kMeterDetectedScale,
    kMeterKeyConfidence,
    kMeterTarget1,
    kMeterTarget2,
    kMeterTarget3,
    kMeterTarget4
};

constexpr std::size_t kParamStorageSize = 6000;

const std::vector<ParamSpec>& parameterSpecs();
const ParamSpec* findSpec(std::uint32_t id) noexcept;
std::vector<const ParamSpec*> editableSpecs();
std::vector<const ParamSpec*> meterSpecs();

double clamp01(double v) noexcept;
double normalizePlain(const ParamSpec& spec, double plain) noexcept;
double denormalize(const ParamSpec& spec, double normalized) noexcept;
double defaultNormalized(const ParamSpec& spec) noexcept;
std::string valueText(const ParamSpec& spec, double normalized);

} // namespace harmonyplugin
