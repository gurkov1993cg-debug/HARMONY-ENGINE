#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include "harmony/HarmonyProcessor.h"
#include "Parameters.h"
#include <array>
#include <atomic>
#include <cstddef>
#include <vector>

class HarmonyEngineAudioProcessor final : public juce::AudioProcessor {
public:
    HarmonyEngineAudioProcessor();
    ~HarmonyEngineAudioProcessor() override = default;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "Harmony Engine"; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.25; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}

    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState apvts;

    float meterInput() const noexcept { return meterInput_.load(std::memory_order_relaxed); }
    float meterOutputL() const noexcept { return meterOutputL_.load(std::memory_order_relaxed); }
    float meterOutputR() const noexcept { return meterOutputR_.load(std::memory_order_relaxed); }
    float meterVoice(int v) const noexcept { return meterVoice_[static_cast<std::size_t>(juce::jlimit(0, 3, v))].load(std::memory_order_relaxed); }
    float detectedPitchMidi() const noexcept { return pitchMidi_.load(std::memory_order_relaxed); }
    float detectedPitchConfidence() const noexcept { return pitchConfidence_.load(std::memory_order_relaxed); }
    int detectedKeyRoot() const noexcept { return detectedKeyRoot_.load(std::memory_order_relaxed); }
    int detectedScaleIndex() const noexcept { return detectedScale_.load(std::memory_order_relaxed); }
    float detectedKeyConfidence() const noexcept { return detectedKeyConfidence_.load(std::memory_order_relaxed); }
    int targetNote(int v) const noexcept { return targetNotes_[static_cast<std::size_t>(juce::jlimit(0, 3, v))].load(std::memory_order_relaxed); }

private:
    enum class GlobalParam : std::size_t {
        Bypass,
        InputDb,
        OutputDb,
        DryDb,
        WetDb,
        HarmonyWidth,
        TuningHz,
        Mode,
        Key,
        Scale,
        ChordRoot,
        ChordType,
        MidiChannel,
        MidiHold,
        AutoKeyThreshold,
        Tightness,
        SmoothingMs,
        Humanize,
        FormantPreserve,
        TransientProtect,
        UnvoicedPreserve,
        Count
    };

    enum class VoiceParam : std::size_t {
        Enable,
        Mute,
        Solo,
        Mode,
        Interval,
        Octave,
        Level,
        Pan,
        Formant,
        Detune,
        HumanizeCents,
        DelayMs,
        VibratoCents,
        VibratoRate,
        ChoirVoices,
        ChoirSpread,
        ChoirDepth,
        MinMidi,
        MaxMidi,
        Count
    };

    static constexpr std::size_t kScratchCapacity = 8192U;

    void cacheParameterPointers();
    float globalValue(GlobalParam p) const noexcept;
    float voiceValue(std::size_t voice, VoiceParam p) const noexcept;
    harmony::ProcessorParams readParameters() const noexcept;
    void updateMidiChord(const juce::MidiBuffer& midi) noexcept;
    void publishMeters() noexcept;

    harmony::HarmonyProcessor engine_;
    std::array<std::atomic<float>*, static_cast<std::size_t>(GlobalParam::Count)> globalParams_{};
    std::array<std::array<std::atomic<float>*, static_cast<std::size_t>(VoiceParam::Count)>, 4> voiceParams_{};

    std::array<bool, 128> activeMidiNotes_{};
    std::array<bool, 128> physicalMidiNotes_{};
    bool lastMidiHold_ = false;

    std::vector<float> monoInput_;
    std::vector<float> outputL_;
    std::vector<float> outputR_;
    std::vector<float> bypassDelayL_;
    std::vector<float> bypassDelayR_;
    std::size_t bypassWrite_ = 0;

    std::atomic<float> meterInput_{0.0f};
    std::atomic<float> meterOutputL_{0.0f};
    std::atomic<float> meterOutputR_{0.0f};
    std::array<std::atomic<float>, 4> meterVoice_{};
    std::atomic<float> pitchMidi_{0.0f};
    std::atomic<float> pitchConfidence_{0.0f};
    std::atomic<int> detectedKeyRoot_{0};
    std::atomic<int> detectedScale_{0};
    std::atomic<float> detectedKeyConfidence_{0.0f};
    std::array<std::atomic<int>, 4> targetNotes_{};

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(HarmonyEngineAudioProcessor)
};
