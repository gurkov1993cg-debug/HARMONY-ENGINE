#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include "PluginProcessor.h"
#include <array>
#include <memory>

class HarmonyLookAndFeel final : public juce::LookAndFeel_V4 {
public:
    HarmonyLookAndFeel();
    void drawRotarySlider(juce::Graphics&, int x, int y, int width, int height,
                          float sliderPos, float rotaryStartAngle, float rotaryEndAngle,
                          juce::Slider&) override;
    void drawToggleButton(juce::Graphics&, juce::ToggleButton&, bool, bool) override;
    void drawButtonBackground(juce::Graphics&, juce::Button&, const juce::Colour&,
                              bool highlighted, bool down) override;
};

class HarmonyLevelMeter final : public juce::Component {
public:
    void setLevel(float linear) noexcept;
    void paint(juce::Graphics&) override;
private:
    float level_ = 0.0f;
    float hold_ = 0.0f;
    int holdTicks_ = 0;
};

class HarmonyVoicePanel final : public juce::Component {
public:
    HarmonyVoicePanel(HarmonyEngineAudioProcessor&, int voiceIndex);
    void resized() override;
    void paint(juce::Graphics&) override;
    void updateRealtime();
    void setAdvanced(bool advanced);

private:
    static void setupKnob(juce::Slider&, const juce::String& name, double defaultValue);
    static void setupSmallSlider(juce::Slider&, double defaultValue);
    void addLabeledKnob(juce::Slider&, juce::Label&, const juce::String& text);

    HarmonyEngineAudioProcessor& processor_;
    int voiceIndex_ = 0;
    bool advanced_ = false;

    juce::ToggleButton enable_;
    juce::TextButton mute_{"M"}, solo_{"S"};
    juce::ComboBox mode_, choirVoices_;
    juce::Label targetCaption_, targetLabel_, choirL_;
    HarmonyLevelMeter meter_;

    juce::Slider interval_, octave_, level_, pan_, formant_, detune_, humanize_, timing_;
    juce::Slider vibratoDepth_, vibratoRate_, choirSpread_, choirDepth_, lowRange_, highRange_;
    juce::Label intervalL_, octaveL_, levelL_, panL_, formantL_, detuneL_, humanizeL_, timingL_;
    juce::Label vibratoDepthL_, vibratoRateL_, choirSpreadL_, choirDepthL_, lowRangeL_, highRangeL_;

    using BA = juce::AudioProcessorValueTreeState::ButtonAttachment;
    using CA = juce::AudioProcessorValueTreeState::ComboBoxAttachment;
    using SA = juce::AudioProcessorValueTreeState::SliderAttachment;
    std::unique_ptr<BA> enableA_, muteA_, soloA_;
    std::unique_ptr<CA> modeA_, choirA_;
    std::array<std::unique_ptr<SA>, 14> sliderA_;
};

class HarmonyEngineAudioProcessorEditor final : public juce::AudioProcessorEditor,
                                                 private juce::Timer {
public:
    explicit HarmonyEngineAudioProcessorEditor(HarmonyEngineAudioProcessor&);
    ~HarmonyEngineAudioProcessorEditor() override;
    void paint(juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override;
    static void setupKnob(juce::Slider&, double defaultValue);
    void addGlobalKnob(juce::Slider&, juce::Label&, const juce::String& name, double defaultValue);
    void switchAB(bool useA);
    void copyAB();
    void resetParameters();
    void refreshABButtons();
    void setAdvancedView(bool advanced);

    HarmonyEngineAudioProcessor& processor_;
    HarmonyLookAndFeel lookAndFeel_;
    juce::ToggleButton bypass_;
    juce::TextButton advancedButton_{"ADVANCED"};
    juce::TextButton aButton_{"A"}, bButton_{"B"}, copyButton_{"COPY A→B"}, resetButton_{"RESET"};
    bool advancedView_ = false;
    bool usingA_ = true;
    juce::ValueTree stateA_, stateB_;

    juce::ComboBox mode_, key_, scale_, chordRoot_, chordType_, midiChannel_;
    juce::ToggleButton midiHold_;
    juce::Label modeL_, keyL_, scaleL_, chordRootL_, chordTypeL_, midiChannelL_;
    juce::Label detectedPitch_, detectedKey_;

    juce::Slider input_, dry_, wet_, output_, harmonyWidth_, tuningHz_;
    juce::Slider tightness_, smoothing_, humanize_, formantPreserve_, transientProtect_, consonantProtect_, autoKeyThreshold_;
    juce::Label inputL_, dryL_, wetL_, outputL_, harmonyWidthL_, tuningHzL_;
    juce::Label tightnessL_, smoothingL_, humanizeL_, formantPreserveL_, transientProtectL_, consonantProtectL_, autoKeyThresholdL_;

    HarmonyLevelMeter inputMeter_, outputMeterL_, outputMeterR_;
    juce::Label inputMeterL_, outputMeterLL_, outputMeterRL_;

    using BA = juce::AudioProcessorValueTreeState::ButtonAttachment;
    using CA = juce::AudioProcessorValueTreeState::ComboBoxAttachment;
    using SA = juce::AudioProcessorValueTreeState::SliderAttachment;
    std::unique_ptr<BA> bypassA_, midiHoldA_;
    std::unique_ptr<CA> modeA_, keyA_, scaleA_, chordRootA_, chordTypeA_, midiChannelA_;
    std::array<std::unique_ptr<SA>, 13> globalA_;
    std::array<std::unique_ptr<HarmonyVoicePanel>, 4> voices_;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(HarmonyEngineAudioProcessorEditor)
};
