#import <Cocoa/Cocoa.h>

#include "HarmonyEditor.h"
#include "HarmonyController.h"
#include "Parameters.h"
#include "PluginIDs.h"

#include "public.sdk/source/common/pluginview.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>

using namespace harmonyplugin;
using namespace Steinberg;
using namespace Steinberg::Vst;

namespace {
constexpr CGFloat kEditorWidth = 1280.0;
constexpr CGFloat kEditorHeight = 800.0;
constexpr std::uint32_t kTabMain = 0xFFFFFF01U;
constexpr std::uint32_t kTabAdvanced = 0xFFFFFF02U;
constexpr std::uint32_t kQuickPresetBase = 0xFFF10000U;

constexpr std::uint32_t quickPresetId(int voice, int preset) noexcept {
    return kQuickPresetBase | (static_cast<std::uint32_t>(voice & 0x0F) << 8U) |
           static_cast<std::uint32_t>(preset & 0xFF);
}

static bool decodeQuickPreset(std::uint32_t id, int& voice, int& preset) noexcept {
    if ((id & 0xFFFF0000U) != kQuickPresetBase) return false;
    voice = static_cast<int>((id >> 8U) & 0x0FU);
    preset = static_cast<int>(id & 0xFFU);
    return voice >= 0 && voice < 4 && preset >= 0 && preset <= 16;
}

struct HitItem {
    NSRect rect{};
    std::uint32_t id = 0;
    bool numeric = false;
};

static NSColor* rgb(CGFloat r, CGFloat g, CGFloat b, CGFloat a = 1.0) {
    return [NSColor colorWithCalibratedRed:r green:g blue:b alpha:a];
}

static void roundedFill(NSRect r, CGFloat radius, NSColor* color) {
    [color setFill];
    [[NSBezierPath bezierPathWithRoundedRect:r xRadius:radius yRadius:radius] fill];
}

static void roundedStroke(NSRect r, CGFloat radius, NSColor* color, CGFloat width = 1.0) {
    [color setStroke];
    NSBezierPath* p = [NSBezierPath bezierPathWithRoundedRect:r xRadius:radius yRadius:radius];
    [p setLineWidth:width];
    [p stroke];
}

static void text(NSString* s, NSRect r, CGFloat size, NSColor* color,
                 NSTextAlignment align = NSTextAlignmentLeft, bool bold = false) {
    if (!s) return;
    NSMutableParagraphStyle* ps = [[NSMutableParagraphStyle alloc] init];
    ps.alignment = align;
    NSFont* font = bold ? [NSFont boldSystemFontOfSize:size] : [NSFont systemFontOfSize:size];
    NSDictionary* attrs = @{NSFontAttributeName: font,
                            NSForegroundColorAttributeName: color,
                            NSParagraphStyleAttributeName: ps};
    [s drawInRect:r withAttributes:attrs];
}

static NSString* ns(const std::string& s) {
    return [NSString stringWithUTF8String:s.c_str()];
}

static std::string midiName(int midi) {
    if (midi < 0 || midi > 127) return "--";
    static const char* names[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
    const int octave = midi / 12 - 1;
    return std::string(names[midi % 12]) + std::to_string(octave);
}

static float linearToDb(float x) {
    return x <= 1.0e-6f ? -60.0f : std::max(-60.0f, 20.0f * std::log10(x));
}

static CGFloat meterNormForDb(float db) {
    return static_cast<CGFloat>(std::clamp((db + 60.0f) / 60.0f, 0.0f, 1.0f));
}

static NSString* presetClassText(int preset) {
    if (preset == 1 || preset == 2 || preset == 7 || preset == 8 || preset == 11 || preset == 12)
        return @"SCALE AWARE";
    if (preset == 0) return @"CUSTOM";
    return @"FIXED INTERVAL";
}

} // namespace

@interface HarmonyNativeView : NSView <NSTextFieldDelegate> {
@private
    harmonyplugin::HarmonyController* _controller;
    std::vector<HitItem> _hits;
    BOOL _advanced;
    BOOL _dragging;
    std::uint32_t _dragId;
    double _dragStartNorm;
    CGFloat _dragStartY;
    NSTextField* _numberEditor;
    std::uint32_t _numberId;
    NSTimer* _timer;
    std::array<float, 7> _peakHoldDb;
    std::array<int, 7> _peakHoldTicks;
}
- (instancetype)initWithFrame:(NSRect)frame controller:(harmonyplugin::HarmonyController*)controller;
- (void)choiceMenuSelected:(NSMenuItem*)sender;
- (void)shutdown;
@end

@implementation HarmonyNativeView

- (instancetype)initWithFrame:(NSRect)frame controller:(harmonyplugin::HarmonyController*)controller {
    self = [super initWithFrame:frame];
    if (self) {
        _controller = controller;
        _advanced = NO;
        _dragging = NO;
        _dragId = 0;
        _numberEditor = nil;
        _numberId = 0;
        _peakHoldDb.fill(-60.0f);
        _peakHoldTicks.fill(0);
        // NSTimer retains its target. A self-target timer here creates a retain
        // cycle (run loop -> timer -> view -> timer). When Cubase removes the
        // plug-in, that stale timer can keep firing after the VST controller
        // has been released. Use a weak block target and also shut the timer
        // down explicitly from IPlugView::removed().
        __weak HarmonyNativeView* weakSelf = self;
        _timer = [NSTimer scheduledTimerWithTimeInterval:0.05
                                                 repeats:YES
                                                   block:^(NSTimer* timer) {
            HarmonyNativeView* strongSelf = weakSelf;
            if (strongSelf) [strongSelf refreshMeters:timer];
            else [timer invalidate];
        }];
    }
    return self;
}

- (BOOL)isFlipped { return YES; }
- (BOOL)acceptsFirstResponder { return YES; }

- (void)shutdown {
    // Idempotent teardown. The controller pointer belongs to the VST3
    // controller and must never be touched after the editor is detached.
    _controller = nullptr;
    _dragging = NO;
    _dragId = 0;
    _numberId = 0;

    if (_timer) {
        [_timer invalidate];
        _timer = nil;
    }
    if (_numberEditor) {
        _numberEditor.delegate = nil;
        [_numberEditor removeFromSuperview];
        _numberEditor = nil;
    }
}

- (void)dealloc {
    [self shutdown];
#if !__has_feature(objc_arc)
    [super dealloc];
#endif
}

- (double)normFor:(std::uint32_t)pid {
    return _controller ? _controller->getParamNormalized(static_cast<ParamID>(pid)) : 0.0;
}

- (double)plainFor:(std::uint32_t)pid {
    const auto* spec = harmonyplugin::findSpec(pid);
    return spec ? harmonyplugin::denormalize(*spec, [self normFor:pid]) : 0.0;
}

- (void)setParam:(std::uint32_t)pid norm:(double)value begin:(BOOL)begin end:(BOOL)end {
    if (_controller) _controller->setFromUI(static_cast<ParamID>(pid), value, begin, end);
    [self setNeedsDisplay:YES];
}

- (void)setPlain:(std::uint32_t)pid value:(double)value {
    const auto* spec = harmonyplugin::findSpec(pid);
    if (!spec || spec->readOnly) return;
    [self setParam:pid norm:harmonyplugin::normalizePlain(*spec, value) begin:YES end:YES];
}

- (void)resetParam:(std::uint32_t)pid {
    if (const auto* spec = harmonyplugin::findSpec(pid))
        [self setParam:pid norm:harmonyplugin::defaultNormalized(*spec) begin:YES end:YES];
}

- (void)refreshMeters:(NSTimer*)timer {
    (void)timer;
    const std::uint32_t ids[7] = {kMeterInput, kMeterOutputL, kMeterOutputR,
                                  kMeterVoice1, kMeterVoice2, kMeterVoice3, kMeterVoice4};
    for (int i = 0; i < 7; ++i) {
        const float db = linearToDb(static_cast<float>([self normFor:ids[i]]));
        if (db >= _peakHoldDb[static_cast<std::size_t>(i)]) {
            _peakHoldDb[static_cast<std::size_t>(i)] = db;
            _peakHoldTicks[static_cast<std::size_t>(i)] = 20;
        } else if (_peakHoldTicks[static_cast<std::size_t>(i)] > 0) {
            --_peakHoldTicks[static_cast<std::size_t>(i)];
        } else {
            _peakHoldDb[static_cast<std::size_t>(i)] = std::max(-60.0f, _peakHoldDb[static_cast<std::size_t>(i)] - 1.25f);
        }
    }
    [self setNeedsDisplay:YES];
}

- (void)addHit:(NSRect)r id:(std::uint32_t)pid numeric:(BOOL)numeric {
    _hits.push_back({r, pid, numeric == YES});
}

- (void)drawPanel:(NSRect)r title:(NSString*)titleString {
    roundedFill(r, 9.0, rgb(0.060, 0.071, 0.082));
    roundedStroke(r, 9.0, rgb(0.145, 0.175, 0.198), 1.0);
    if (titleString) {
        [rgb(0.075, 0.48, 0.72) setFill];
        NSRectFill(NSMakeRect(r.origin.x, r.origin.y, 3.0, r.size.height));
        text(titleString, NSMakeRect(r.origin.x + 14, r.origin.y + 9, r.size.width - 28, 17),
             10.5, rgb(0.68, 0.76, 0.82), NSTextAlignmentLeft, true);
    }
}

- (void)drawToggle:(std::uint32_t)pid label:(NSString*)label rect:(NSRect)r {
    const BOOL on = [self plainFor:pid] >= 0.5;
    roundedFill(r, 5.0, on ? rgb(0.065, 0.42, 0.64) : rgb(0.095, 0.11, 0.125));
    roundedStroke(r, 5.0, on ? rgb(0.18, 0.70, 0.94) : rgb(0.19, 0.22, 0.25), 1.0);
    text(label, NSInsetRect(r, 4, 5), 9.5, on ? NSColor.whiteColor : rgb(0.62, 0.68, 0.72), NSTextAlignmentCenter, true);
    [self addHit:r id:pid numeric:NO];
}

- (void)drawChoice:(std::uint32_t)pid label:(NSString*)label rect:(NSRect)r {
    const auto* spec = harmonyplugin::findSpec(pid);
    if (!spec) return;
    text(label, NSMakeRect(r.origin.x, r.origin.y, r.size.width, 13), 8.5, rgb(0.43, 0.52, 0.59), NSTextAlignmentLeft, true);
    NSRect valueRect = NSMakeRect(r.origin.x, r.origin.y + 16, r.size.width, 30);
    roundedFill(valueRect, 5.0, rgb(0.080, 0.095, 0.108));
    roundedStroke(valueRect, 5.0, rgb(0.16, 0.27, 0.34), 1.0);
    const std::string v = harmonyplugin::valueText(*spec, [self normFor:pid]);
    text(ns(v), NSMakeRect(valueRect.origin.x + 8, valueRect.origin.y + 7, valueRect.size.width - 27, 16),
         10, rgb(0.82, 0.88, 0.92), NSTextAlignmentLeft, true);
    text(@"▾", NSMakeRect(NSMaxX(valueRect) - 21, valueRect.origin.y + 6, 14, 17),
         11, rgb(0.28, 0.68, 0.90), NSTextAlignmentCenter, true);
    [self addHit:valueRect id:pid numeric:NO];
}

- (void)drawKnob:(std::uint32_t)pid label:(NSString*)label rect:(NSRect)r {
    const auto* spec = harmonyplugin::findSpec(pid);
    if (!spec) return;
    const double norm = [self normFor:pid];
    text(label, NSMakeRect(r.origin.x, r.origin.y, r.size.width, 12), 8, rgb(0.43, 0.52, 0.59), NSTextAlignmentCenter, true);

    const CGFloat cx = NSMidX(r);
    const CGFloat cy = r.origin.y + 35.0;
    const CGFloat radius = std::min<CGFloat>(18.0, r.size.width * 0.29);
    NSRect circle = NSMakeRect(cx - radius, cy - radius, radius * 2.0, radius * 2.0);
    roundedFill(circle, radius, rgb(0.085, 0.102, 0.116));
    roundedStroke(circle, radius, rgb(0.20, 0.24, 0.27), 1.0);

    NSBezierPath* track = [NSBezierPath bezierPath];
    [track appendBezierPathWithArcWithCenter:NSMakePoint(cx, cy) radius:radius + 4.0 startAngle:225 endAngle:-45 clockwise:YES];
    [track setLineWidth:2.3];
    [rgb(0.13, 0.16, 0.18) setStroke];
    [track stroke];

    const CGFloat angle = 225.0 - static_cast<CGFloat>(270.0 * harmonyplugin::clamp01(norm));
    const CGFloat radians = angle * static_cast<CGFloat>(M_PI / 180.0);
    NSPoint p1 = NSMakePoint(cx + std::cos(radians) * 4.0, cy - std::sin(radians) * 4.0);
    NSPoint p2 = NSMakePoint(cx + std::cos(radians) * (radius - 3.0), cy - std::sin(radians) * (radius - 3.0));
    NSBezierPath* needle = [NSBezierPath bezierPath];
    [needle moveToPoint:p1];
    [needle lineToPoint:p2];
    [needle setLineWidth:2.0];
    [rgb(0.15, 0.70, 0.95) setStroke];
    [needle stroke];

    NSRect valueRect = NSMakeRect(r.origin.x + 3, r.origin.y + r.size.height - 18, r.size.width - 6, 17);
    roundedFill(valueRect, 3.0, rgb(0.047, 0.058, 0.068));
    const std::string v = harmonyplugin::valueText(*spec, norm);
    text(ns(v), NSInsetRect(valueRect, 2, 2), 8, rgb(0.68, 0.77, 0.83), NSTextAlignmentCenter, false);

    NSRect dragRect = NSMakeRect(r.origin.x, r.origin.y + 13, r.size.width, r.size.height - 32);
    [self addHit:dragRect id:pid numeric:NO];
    [self addHit:valueRect id:pid numeric:YES];
}

- (void)drawSmallControl:(std::uint32_t)pid label:(NSString*)label rect:(NSRect)r {
    const auto* spec = harmonyplugin::findSpec(pid);
    if (!spec) return;
    if (spec->kind == ParamKind::Toggle) {
        [self drawToggle:pid label:label rect:NSMakeRect(r.origin.x, r.origin.y + 16, r.size.width, 26)];
        return;
    }
    if (spec->kind == ParamKind::Choice) {
        [self drawChoice:pid label:label rect:r];
        return;
    }
    [self drawKnob:pid label:label rect:NSMakeRect(r.origin.x, r.origin.y, r.size.width, 68)];
}

- (void)drawQuickPresetForVoice:(int)voice preset:(int)preset label:(NSString*)label rect:(NSRect)r {
    const int current = static_cast<int>(std::lround([self plainFor:voiceParamId(voice, kVoiceHarmonyPreset)]));
    const BOOL active = current == preset;
    roundedFill(r, 4.0, active ? rgb(0.07, 0.42, 0.63) : rgb(0.077, 0.091, 0.103));
    roundedStroke(r, 4.0, active ? rgb(0.17, 0.70, 0.94) : rgb(0.16, 0.20, 0.23), 1.0);
    text(label, NSInsetRect(r, 3, 5), 8.5, active ? NSColor.whiteColor : rgb(0.63, 0.70, 0.75), NSTextAlignmentCenter, true);
    [self addHit:r id:quickPresetId(voice, preset) numeric:NO];
}

- (void)drawMeter:(std::uint32_t)pid holdIndex:(int)holdIndex label:(NSString*)label rect:(NSRect)r {
    const float linear = static_cast<float>([self normFor:pid]);
    const float db = linearToDb(linear);
    const CGFloat n = meterNormForDb(db);
    NSRect track = NSMakeRect(r.origin.x + 6, r.origin.y + 18, r.size.width - 12, r.size.height - 39);
    roundedFill(track, 3.0, rgb(0.035, 0.044, 0.051));
    roundedStroke(track, 3.0, rgb(0.12, 0.15, 0.17), 1.0);

    NSRect bar = track;
    bar.origin.y = track.origin.y + track.size.height * (1.0 - n);
    bar.size.height = track.size.height * n;
    if (bar.size.height > 0.5) {
        NSGradient* g = [[NSGradient alloc] initWithColors:@[rgb(0.16,0.72,0.35), rgb(0.88,0.72,0.16), rgb(0.90,0.20,0.16)]];
        [g drawInRect:bar angle:90.0];
    }

    const float holdDb = _peakHoldDb[static_cast<std::size_t>(std::clamp(holdIndex, 0, 6))];
    const CGFloat hn = meterNormForDb(holdDb);
    const CGFloat hy = track.origin.y + track.size.height * (1.0 - hn);
    [rgb(0.84, 0.91, 0.95) setFill];
    NSRectFill(NSMakeRect(track.origin.x, hy, track.size.width, 1.0));

    text(label, NSMakeRect(r.origin.x, r.origin.y, r.size.width, 14), 8, rgb(0.53,0.61,0.67), NSTextAlignmentCenter, true);
    char dbText[32]{};
    std::snprintf(dbText, sizeof(dbText), db <= -59.9f ? "-inf" : "%.1f", db);
    text([NSString stringWithUTF8String:dbText], NSMakeRect(r.origin.x, NSMaxY(r)-17, r.size.width, 14), 7.5, rgb(0.58,0.66,0.72), NSTextAlignmentCenter, false);
}

- (void)drawMeterPanel {
    NSRect panel = NSMakeRect(1000, 82, 262, 700);
    [self drawPanel:panel title:@"REAL-TIME ANALYSIS"];

    const CGFloat meterY = 122;
    const CGFloat meterH = 312;
    const CGFloat meterX = 1030;
    const CGFloat step = 29.5;
    const std::uint32_t ids[7] = {kMeterInput,kMeterOutputL,kMeterOutputR,kMeterVoice1,kMeterVoice2,kMeterVoice3,kMeterVoice4};
    NSString* labels[7] = {@"IN",@"L",@"R",@"V1",@"V2",@"V3",@"V4"};
    for (int i = 0; i < 7; ++i)
        [self drawMeter:ids[i] holdIndex:i label:labels[i] rect:NSMakeRect(meterX + step*i, meterY, 25, meterH)];

    const int dbMarks[] = {0, -6, -12, -24, -36, -48, -60};
    for (int db : dbMarks) {
        const CGFloat y = meterY + 18 + (meterH - 39) * (1.0 - meterNormForDb(static_cast<float>(db)));
        [rgb(0.16,0.19,0.21) setFill];
        NSRectFill(NSMakeRect(1011, y, 12, 1));
        text([NSString stringWithFormat:@"%d", db], NSMakeRect(1006, y - 6, 23, 12), 6.5, rgb(0.38,0.45,0.50), NSTextAlignmentLeft, false);
    }

    const double pitch = [self plainFor:kMeterPitchMidi];
    const double pconf = [self plainFor:kMeterPitchConfidence];
    const double kconf = [self plainFor:kMeterKeyConfidence];
    const auto* keySpec = harmonyplugin::findSpec(kMeterDetectedKey);
    const auto* scaleSpec = harmonyplugin::findSpec(kMeterDetectedScale);
    const std::string keyText = keySpec ? harmonyplugin::valueText(*keySpec, [self normFor:kMeterDetectedKey]) : "--";
    const std::string scaleText = scaleSpec ? harmonyplugin::valueText(*scaleSpec, [self normFor:kMeterDetectedScale]) : "--";

    roundedFill(NSMakeRect(1016, 456, 230, 102), 7, rgb(0.046,0.057,0.066));
    text(@"DETECTOR", NSMakeRect(1028, 466, 200, 14), 9, rgb(0.28,0.68,0.90), NSTextAlignmentLeft, true);
    text([NSString stringWithFormat:@"Pitch   %s   %.0f%%", midiName(static_cast<int>(std::lround(pitch))).c_str(), pconf],
         NSMakeRect(1028, 489, 205, 18), 10, rgb(0.78,0.84,0.88), NSTextAlignmentLeft, false);
    text([NSString stringWithFormat:@"Key     %s", keyText.c_str()], NSMakeRect(1028, 510, 205, 18), 10, rgb(0.78,0.84,0.88), NSTextAlignmentLeft, false);
    text([NSString stringWithFormat:@"Mode    %s   %.0f%%", scaleText.c_str(), kconf], NSMakeRect(1028, 531, 205, 18), 9.5, rgb(0.65,0.72,0.77), NSTextAlignmentLeft, false);

    roundedFill(NSMakeRect(1016, 572, 230, 150), 7, rgb(0.046,0.057,0.066));
    text(@"VOICE TARGETS", NSMakeRect(1028, 582, 200, 14), 9, rgb(0.28,0.68,0.90), NSTextAlignmentLeft, true);
    const std::uint32_t tids[4] = {kMeterTarget1,kMeterTarget2,kMeterTarget3,kMeterTarget4};
    for (int i = 0; i < 4; ++i) {
        const int note = static_cast<int>(std::lround([self plainFor:tids[i]]));
        const float meter = static_cast<float>([self normFor:kMeterVoice1 + i]);
        text([NSString stringWithFormat:@"VOICE %d", i+1], NSMakeRect(1028, 608 + i*25, 72, 18), 9, rgb(0.55,0.63,0.69), NSTextAlignmentLeft, true);
        text(ns(midiName(note)), NSMakeRect(1100, 608 + i*25, 54, 18), 11, rgb(0.80,0.87,0.92), NSTextAlignmentCenter, true);
        roundedFill(NSMakeRect(1164, 613 + i*25, 66, 7), 3, rgb(0.08,0.10,0.11));
        NSRect mini = NSMakeRect(1164, 613 + i*25, 66 * std::clamp<CGFloat>(meter,0.0,1.0), 7);
        roundedFill(mini, 3, rgb(0.10,0.55,0.80));
    }

    text(@"Meters are driven by the real DSP signal", NSMakeRect(1016, 744, 230, 16), 7.5, rgb(0.39,0.46,0.51), NSTextAlignmentCenter, false);
}

- (void)drawHeader {
    [rgb(0.027, 0.033, 0.039) setFill];
    NSRectFill(self.bounds);
    [rgb(0.043, 0.052, 0.061) setFill];
    NSRectFill(NSMakeRect(0, 0, kEditorWidth, 66));
    [rgb(0.07,0.48,0.72) setFill];
    NSRectFill(NSMakeRect(0, 64, kEditorWidth, 2));

    text(@"TERCIOR AUDIO", NSMakeRect(20, 9, 160, 14), 8.5, rgb(0.24,0.67,0.91), NSTextAlignmentLeft, true);
    text(@"HARMONY ENGINE", NSMakeRect(20, 22, 330, 29), 23, rgb(0.87,0.92,0.95), NSTextAlignmentLeft, true);
    text(@"4-VOICE SCALE-AWARE VOCAL HARMONY", NSMakeRect(222, 30, 300, 15), 8.5, rgb(0.44,0.52,0.58), NSTextAlignmentLeft, true);

    NSRect mainTab = NSMakeRect(540, 17, 92, 32);
    NSRect advTab = NSMakeRect(638, 17, 108, 32);
    roundedFill(mainTab, 6, _advanced ? rgb(0.072,0.086,0.099) : rgb(0.065,0.42,0.64));
    roundedFill(advTab, 6, _advanced ? rgb(0.065,0.42,0.64) : rgb(0.072,0.086,0.099));
    roundedStroke(mainTab, 6, rgb(0.13,0.22,0.28), 1);
    roundedStroke(advTab, 6, rgb(0.13,0.22,0.28), 1);
    text(@"MAIN", NSInsetRect(mainTab, 4, 8), 9.5, NSColor.whiteColor, NSTextAlignmentCenter, true);
    text(@"ADVANCED", NSInsetRect(advTab, 4, 8), 9.5, NSColor.whiteColor, NSTextAlignmentCenter, true);
    [self addHit:mainTab id:kTabMain numeric:NO];
    [self addHit:advTab id:kTabAdvanced numeric:NO];

    text(@"Click a selector to open the complete list", NSMakeRect(755, 24, 245, 16), 8, rgb(0.39,0.47,0.53), NSTextAlignmentRight, false);
    [self drawToggle:kLeadMute label:@"LEAD MUTE" rect:NSMakeRect(1022, 17, 126, 31)];
    [self drawToggle:kBypass label:@"BYPASS" rect:NSMakeRect(1158, 17, 98, 31)];
}

- (void)drawTopStrip {
    NSRect p = NSMakeRect(18, 82, 964, 104);
    [self drawPanel:p title:@"MUSICAL CONTROL"];

    [self drawChoice:kMode label:@"HARMONY MODE" rect:NSMakeRect(36, 112, 155, 48)];
    [self drawChoice:kKey label:@"KEY / TONALITY" rect:NSMakeRect(207, 112, 112, 48)];
    [self drawChoice:kScale label:@"SCALE / MODE" rect:NSMakeRect(335, 112, 175, 48)];

    [self drawKnob:kInputDb label:@"INPUT" rect:NSMakeRect(528, 101, 72, 72)];
    [self drawKnob:kWetDb label:@"HARMONY" rect:NSMakeRect(609, 101, 72, 72)];
    [self drawKnob:kOutputDb label:@"OUTPUT" rect:NSMakeRect(690, 101, 72, 72)];

    const int pitch = static_cast<int>(std::lround([self plainFor:kMeterPitchMidi]));
    const double conf = [self plainFor:kMeterPitchConfidence];
    roundedFill(NSMakeRect(785, 111, 176, 50), 6, rgb(0.042,0.052,0.061));
    roundedStroke(NSMakeRect(785, 111, 176, 50), 6, rgb(0.13,0.20,0.25), 1);
    text(@"LIVE PITCH", NSMakeRect(797, 118, 150, 13), 8, rgb(0.27,0.66,0.88), NSTextAlignmentLeft, true);
    text([NSString stringWithFormat:@"%s   %.0f%%", midiName(pitch).c_str(), conf], NSMakeRect(797, 136, 150, 19), 13, rgb(0.83,0.89,0.93), NSTextAlignmentLeft, true);

    text(@"Scale-aware 3rd/4th/5th follow KEY + SCALE/MODE.  m3 / M3 / P4 / P5 are fixed chromatic intervals.",
         NSMakeRect(36, 166, 920, 14), 7.8, rgb(0.41,0.49,0.55), NSTextAlignmentLeft, false);
}

- (void)drawVoiceCard:(int)v rect:(NSRect)panel {
    [self drawPanel:panel title:[NSString stringWithFormat:@"VOICE %d", v + 1]];
    const CGFloat x = panel.origin.x;
    const CGFloat y = panel.origin.y;
    const CGFloat w = panel.size.width;

    [self drawToggle:voiceParamId(v, kVoiceEnable) label:@"ON" rect:NSMakeRect(x+w-184, y+8, 42, 25)];
    [self drawToggle:voiceParamId(v, kVoiceMute) label:@"MUTE" rect:NSMakeRect(x+w-136, y+8, 56, 25)];
    [self drawToggle:voiceParamId(v, kVoiceSolo) label:@"SOLO" rect:NSMakeRect(x+w-72, y+8, 56, 25)];

    [self drawChoice:voiceParamId(v, kVoiceHarmonyPreset) label:@"HARMONY INTERVAL" rect:NSMakeRect(x+16, y+39, 218, 48)];

    const int preset = static_cast<int>(std::lround([self plainFor:voiceParamId(v, kVoiceHarmonyPreset)]));
    roundedFill(NSMakeRect(x+247, y+55, 102, 30), 5, rgb(0.043,0.055,0.064));
    text(presetClassText(preset), NSMakeRect(x+252, y+63, 92, 14), 7.5, rgb(0.31,0.65,0.84), NSTextAlignmentCenter, true);

    const int target = static_cast<int>(std::lround([self plainFor:kMeterTarget1 + v]));
    roundedFill(NSMakeRect(x+362, y+43, w-378, 44), 6, rgb(0.040,0.050,0.059));
    text(@"TARGET", NSMakeRect(x+368, y+48, w-390, 12), 7.5, rgb(0.37,0.50,0.58), NSTextAlignmentCenter, true);
    text(ns(midiName(target)), NSMakeRect(x+368, y+61, w-390, 18), 12, rgb(0.77,0.87,0.93), NSTextAlignmentCenter, true);

    const int quickPresets[7] = {1,3,5,7,11,15,16};
    NSString* quickLabels[7] = {@"3rd",@"m3",@"M3",@"4th",@"5th",@"+8",@"-8"};
    const CGFloat qx = x + 16;
    for (int i = 0; i < 7; ++i)
        [self drawQuickPresetForVoice:v preset:quickPresets[i] label:quickLabels[i] rect:NSMakeRect(qx + i*59, y+96, 54, 25)];

    const CGFloat ky = y + 132;
    const CGFloat kw = 76;
    const CGFloat ks = 84;
    [self drawKnob:voiceParamId(v,kVoiceLevel) label:@"LEVEL" rect:NSMakeRect(x+18 + ks*0, ky, kw, 72)];
    [self drawKnob:voiceParamId(v,kVoicePan) label:@"PAN" rect:NSMakeRect(x+18 + ks*1, ky, kw, 72)];
    [self drawKnob:voiceParamId(v,kVoiceFormant) label:@"FORMANT" rect:NSMakeRect(x+18 + ks*2, ky, kw, 72)];
    [self drawKnob:voiceParamId(v,kVoiceHumanizeCents) label:@"HUMAN" rect:NSMakeRect(x+18 + ks*3, ky, kw, 72)];
    [self drawKnob:voiceParamId(v,kVoiceDelayMs) label:@"TIMING" rect:NSMakeRect(x+18 + ks*4, ky, kw, 72)];
}

- (void)drawGlobalStrip {
    NSRect global = NSMakeRect(18, 694, 964, 88);
    [self drawPanel:global title:@"GLOBAL VOICE CONTROL"];
    const CGFloat x = 35;
    const CGFloat step = 112;
    [self drawKnob:kTightness label:@"INDEPEND" rect:NSMakeRect(x + step*0, 706, 76, 70)];
    [self drawKnob:kSmoothingMs label:@"GLIDE" rect:NSMakeRect(x + step*1, 706, 76, 70)];
    [self drawKnob:kHumanize label:@"HUMANIZE" rect:NSMakeRect(x + step*2, 706, 76, 70)];
    [self drawKnob:kFormantPreserve label:@"FORMANT" rect:NSMakeRect(x + step*3, 706, 76, 70)];
    [self drawKnob:kTransientProtect label:@"TRANSIENT" rect:NSMakeRect(x + step*4, 706, 76, 70)];
    [self drawKnob:kUnvoicedPreserve label:@"CONSONANT" rect:NSMakeRect(x + step*5, 706, 76, 70)];
    [self drawKnob:kDryDb label:@"DRY" rect:NSMakeRect(x + step*6, 706, 76, 70)];
    [self drawKnob:kHarmonyWidth label:@"WIDTH" rect:NSMakeRect(x + step*7, 706, 76, 70)];
}

- (void)drawMainPage {
    [self drawVoiceCard:0 rect:NSMakeRect(18, 202, 467, 232)];
    [self drawVoiceCard:1 rect:NSMakeRect(503, 202, 479, 232)];
    [self drawVoiceCard:2 rect:NSMakeRect(18, 450, 467, 232)];
    [self drawVoiceCard:3 rect:NSMakeRect(503, 450, 479, 232)];
    [self drawGlobalStrip];
    [self drawMeterPanel];
}

- (void)drawAdvancedVoice:(int)v rect:(NSRect)panel {
    [self drawPanel:panel title:[NSString stringWithFormat:@"VOICE %d DETAIL", v+1]];
    const CGFloat x = panel.origin.x;
    const CGFloat y = panel.origin.y;

    [self drawChoice:voiceParamId(v,kVoiceHarmonyPreset) label:@"HARMONY INTERVAL" rect:NSMakeRect(x+16,y+34,215,48)];
    [self drawChoice:voiceParamId(v,kVoiceMode) label:@"CUSTOM MODE" rect:NSMakeRect(x+246,y+34,196,48)];

    const CGFloat row1 = y + 92;
    const CGFloat w = 64;
    const CGFloat step = 72;
    [self drawSmallControl:voiceParamId(v,kVoiceInterval) label:@"INTERVAL" rect:NSMakeRect(x+15+step*0,row1,w,68)];
    [self drawSmallControl:voiceParamId(v,kVoiceOctave) label:@"OCTAVE" rect:NSMakeRect(x+15+step*1,row1,w,68)];
    [self drawSmallControl:voiceParamId(v,kVoiceDetune) label:@"DETUNE" rect:NSMakeRect(x+15+step*2,row1,w,68)];
    [self drawSmallControl:voiceParamId(v,kVoiceVibratoCents) label:@"VIB DEPTH" rect:NSMakeRect(x+15+step*3,row1,w,68)];
    [self drawSmallControl:voiceParamId(v,kVoiceVibratoRate) label:@"VIB RATE" rect:NSMakeRect(x+15+step*4,row1,w,68)];
    [self drawSmallControl:voiceParamId(v,kVoiceChoirVoices) label:@"CHOIR" rect:NSMakeRect(x+15+step*5,row1,w,52)];

    const CGFloat row2 = y + 158;
    [self drawSmallControl:voiceParamId(v,kVoiceChoirSpread) label:@"SPREAD" rect:NSMakeRect(x+15+step*0,row2,w,68)];
    [self drawSmallControl:voiceParamId(v,kVoiceChoirDepth) label:@"DEPTH" rect:NSMakeRect(x+15+step*1,row2,w,68)];
    [self drawSmallControl:voiceParamId(v,kVoiceMinMidi) label:@"LOW MIDI" rect:NSMakeRect(x+15+step*2,row2,w,68)];
    [self drawSmallControl:voiceParamId(v,kVoiceMaxMidi) label:@"HIGH MIDI" rect:NSMakeRect(x+15+step*3,row2,w,68)];
    text(@"Custom Mode / Interval / Octave are used when HARMONY INTERVAL = Custom",
         NSMakeRect(x+304, row2+22, 145, 34), 6.8, rgb(0.39,0.47,0.53), NSTextAlignmentCenter, false);
}

- (void)drawAdvancedPage {
    NSRect globals = NSMakeRect(18, 202, 964, 94);
    [self drawPanel:globals title:@"MODE / CHORD / TUNING"];
    [self drawChoice:kChordRoot label:@"CHORD ROOT" rect:NSMakeRect(35, 230, 105, 48)];
    [self drawChoice:kChordType label:@"CHORD TYPE" rect:NSMakeRect(152, 230, 150, 48)];
    [self drawChoice:kMidiChannel label:@"MIDI CH" rect:NSMakeRect(314, 230, 92, 48)];
    [self drawToggle:kMidiHold label:@"HOLD" rect:NSMakeRect(420, 247, 58, 28)];
    [self drawKnob:kAutoKeyThreshold label:@"AUTO KEY" rect:NSMakeRect(493, 218, 72, 70)];
    [self drawKnob:kTuningHz label:@"A4 TUNING" rect:NSMakeRect(575, 218, 72, 70)];
    [self drawKnob:kHarmonyWidth label:@"WIDTH" rect:NSMakeRect(657, 218, 72, 70)];
    [self drawKnob:kDryDb label:@"DRY" rect:NSMakeRect(739, 218, 72, 70)];
    [self drawKnob:kFormantPreserve label:@"FORMANT" rect:NSMakeRect(821, 218, 72, 70)];
    [self drawKnob:kTransientProtect label:@"TRANSIENT" rect:NSMakeRect(903, 218, 66, 70)];

    [self drawAdvancedVoice:0 rect:NSMakeRect(18, 310, 467, 226)];
    [self drawAdvancedVoice:1 rect:NSMakeRect(503, 310, 479, 226)];
    [self drawAdvancedVoice:2 rect:NSMakeRect(18, 550, 467, 226)];
    [self drawAdvancedVoice:3 rect:NSMakeRect(503, 550, 479, 226)];
    [self drawMeterPanel];
}

- (void)drawRect:(NSRect)dirtyRect {
    (void)dirtyRect;
    _hits.clear();
    [self drawHeader];
    [self drawTopStrip];
    if (_advanced) [self drawAdvancedPage];
    else [self drawMainPage];
}

- (HitItem*)hitAt:(NSPoint)p {
    for (auto it = _hits.rbegin(); it != _hits.rend(); ++it)
        if (NSPointInRect(p, it->rect)) return &(*it);
    return nullptr;
}

- (void)beginNumericFor:(std::uint32_t)pid rect:(NSRect)r {
    const auto* spec = harmonyplugin::findSpec(pid);
    if (!spec || spec->readOnly) return;
    [_numberEditor removeFromSuperview];
    _numberEditor = [[NSTextField alloc] initWithFrame:NSInsetRect(r, -3, -2)];
    _numberId = pid;
    _numberEditor.delegate = self;
    _numberEditor.font = [NSFont systemFontOfSize:11];
    _numberEditor.alignment = NSTextAlignmentCenter;
    _numberEditor.stringValue = [NSString stringWithFormat:@"%.4g", [self plainFor:pid]];
    [self addSubview:_numberEditor];
    [self.window makeFirstResponder:_numberEditor];
    [_numberEditor selectText:nil];
}

- (void)controlTextDidEndEditing:(NSNotification*)obj {
    (void)obj;
    if (!_numberEditor || _numberId == 0) return;
    const auto* spec = harmonyplugin::findSpec(_numberId);
    if (spec) {
        const double plain = _numberEditor.doubleValue;
        [self setParam:_numberId norm:harmonyplugin::normalizePlain(*spec, plain) begin:YES end:YES];
    }
    [_numberEditor removeFromSuperview];
    _numberEditor = nil;
    _numberId = 0;
    [self.window makeFirstResponder:self];
}

- (void)showChoiceMenuFor:(std::uint32_t)pid event:(NSEvent*)event {
    const auto* spec = harmonyplugin::findSpec(pid);
    if (!spec || spec->readOnly || spec->kind != ParamKind::Choice || !spec->choices || spec->choiceCount <= 0) return;

    NSMenu* menu = [[NSMenu alloc] initWithTitle:@""];
    const int current = std::clamp(static_cast<int>(std::lround([self plainFor:pid])), 0, spec->choiceCount - 1);
    for (int i = 0; i < spec->choiceCount; ++i) {
        NSMenuItem* item = [[NSMenuItem alloc] initWithTitle:[NSString stringWithUTF8String:spec->choices[i]]
                                                      action:@selector(choiceMenuSelected:)
                                               keyEquivalent:@""];
        item.target = self;
        item.representedObject = @[@(pid), @(i)];
        item.state = (i == current) ? NSControlStateValueOn : NSControlStateValueOff;
        [menu addItem:item];
    }
    [NSMenu popUpContextMenu:menu withEvent:event forView:self];
}

- (void)choiceMenuSelected:(NSMenuItem*)sender {
    NSArray* data = (NSArray*)sender.representedObject;
    if (![data isKindOfClass:[NSArray class]] || data.count != 2) return;
    const std::uint32_t pid = [data[0] unsignedIntValue];
    const int index = [data[1] intValue];
    [self setPlain:pid value:index];
}

- (void)mouseDown:(NSEvent*)event {
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    HitItem* h = [self hitAt:p];
    if (!h) return;

    if (h->id == kTabMain) { _advanced = NO; [self setNeedsDisplay:YES]; return; }
    if (h->id == kTabAdvanced) { _advanced = YES; [self setNeedsDisplay:YES]; return; }

    int quickVoice = 0, quickPreset = 0;
    if (decodeQuickPreset(h->id, quickVoice, quickPreset)) {
        [self setPlain:voiceParamId(quickVoice, kVoiceHarmonyPreset) value:quickPreset];
        // A quick harmony button is an audition/action control, not merely a
        // hidden preset selector. Make the selected voice audible immediately.
        [self setPlain:voiceParamId(quickVoice, kVoiceEnable) value:1.0];
        return;
    }

    const auto* spec = harmonyplugin::findSpec(h->id);
    if (!spec || spec->readOnly) return;

    if (event.clickCount >= 2) { [self resetParam:h->id]; return; }
    if (h->numeric || (event.modifierFlags & NSEventModifierFlagOption)) {
        [self beginNumericFor:h->id rect:h->rect];
        return;
    }

    if (spec->kind == ParamKind::Toggle) {
        const double next = [self plainFor:h->id] >= 0.5 ? 0.0 : 1.0;
        [self setPlain:h->id value:next];
        if (next >= 0.5 && h->id >= kVoiceBase && h->id < kVoiceBase + 4 * kVoiceStride) {
            const std::uint32_t rel = h->id - kVoiceBase;
            const int voice = static_cast<int>(rel / kVoiceStride);
            const std::uint32_t offset = rel % kVoiceStride;
            if (voice >= 0 && voice < 4 && offset == static_cast<std::uint32_t>(kVoiceSolo))
                [self setPlain:voiceParamId(voice, kVoiceEnable) value:1.0];
        }
        return;
    }
    if (spec->kind == ParamKind::Choice) {
        [self showChoiceMenuFor:h->id event:event];
        return;
    }

    _dragging = YES;
    _dragId = h->id;
    _dragStartNorm = [self normFor:h->id];
    _dragStartY = p.y;
    if (_controller) _controller->beginEdit(static_cast<ParamID>(_dragId));
}

- (void)mouseDragged:(NSEvent*)event {
    if (!_dragging || _dragId == 0) return;
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    const double sensitivity = (event.modifierFlags & NSEventModifierFlagShift) ? 600.0 : 180.0;
    const double norm = harmonyplugin::clamp01(_dragStartNorm + (_dragStartY - p.y) / sensitivity);
    if (_controller) {
        _controller->setParamNormalized(static_cast<ParamID>(_dragId), norm);
        _controller->performEdit(static_cast<ParamID>(_dragId), norm);
    }
    [self setNeedsDisplay:YES];
}

- (void)mouseUp:(NSEvent*)event {
    (void)event;
    if (_dragging && _dragId != 0 && _controller)
        _controller->endEdit(static_cast<ParamID>(_dragId));
    _dragging = NO;
    _dragId = 0;
}

@end

namespace harmonyplugin {

class HarmonyEditorView final : public CPluginView {
public:
    explicit HarmonyEditorView(HarmonyController* controller)
        : CPluginView(&initialRect()), controller_(controller) {
        if (controller_) controller_->addRef();
    }

    ~HarmonyEditorView() override {
        if (nativeView_) {
            [nativeView_ shutdown];
            [nativeView_ removeFromSuperview];
            nativeView_ = nil;
        }
        if (controller_) {
            controller_->release();
            controller_ = nullptr;
        }
    }

    tresult PLUGIN_API isPlatformTypeSupported(FIDString type) SMTG_OVERRIDE {
        return type && std::strcmp(type, kPlatformTypeNSView) == 0 ? kResultTrue : kResultFalse;
    }

    tresult PLUGIN_API attached(void* parent, FIDString type) SMTG_OVERRIDE {
        if (!parent || isPlatformTypeSupported(type) != kResultTrue || nativeView_) return kResultFalse;
        systemWindow = parent;
        NSView* parentView = (__bridge NSView*)parent;
        nativeView_ = [[HarmonyNativeView alloc] initWithFrame:NSMakeRect(0, 0, kEditorWidth, kEditorHeight) controller:controller_];
        [parentView addSubview:nativeView_];
        return kResultOk;
    }

    tresult PLUGIN_API removed() SMTG_OVERRIDE {
        if (nativeView_) {
            // Stop all callbacks before releasing the native view or the
            // controller. This is required because Cubase can destroy the
            // VST3 instance immediately after detaching the editor.
            [nativeView_ shutdown];
            [nativeView_ removeFromSuperview];
            nativeView_ = nil;
        }
        systemWindow = nullptr;
        return kResultOk;
    }

    tresult PLUGIN_API onSize(ViewRect* newSize) SMTG_OVERRIDE {
        if (!newSize) return kInvalidArgument;
        rect = *newSize;
        if (nativeView_) [nativeView_ setFrame:NSMakeRect(0, 0, rect.getWidth(), rect.getHeight())];
        return kResultTrue;
    }

    tresult PLUGIN_API canResize() SMTG_OVERRIDE { return kResultFalse; }

private:
    static ViewRect& initialRect() {
        static ViewRect r(0, 0, static_cast<int32>(kEditorWidth), static_cast<int32>(kEditorHeight));
        return r;
    }

    HarmonyController* controller_ = nullptr;
    HarmonyNativeView* nativeView_ = nil;
};

Steinberg::IPlugView* createHarmonyEditor(HarmonyController* controller) {
    return new HarmonyEditorView(controller);
}

} // namespace harmonyplugin
