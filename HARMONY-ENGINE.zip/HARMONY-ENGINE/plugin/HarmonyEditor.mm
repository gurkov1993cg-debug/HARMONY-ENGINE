#import <Cocoa/Cocoa.h>

#include "HarmonyEditor.h"
#include "HarmonyController.h"
#include "Parameters.h"
#include "PluginIDs.h"

#include "public.sdk/source/common/pluginview.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>

using namespace harmonyplugin;
using namespace Steinberg;
using namespace Steinberg::Vst;

namespace {
constexpr CGFloat kEditorWidth = 980.0;
constexpr CGFloat kEditorHeight = 600.0;
constexpr std::uint32_t kQuickPresetBase = 0xFFF10000U;

constexpr std::uint32_t quickPresetId(int voice, int preset) noexcept {
    return kQuickPresetBase | (static_cast<std::uint32_t>(voice & 0x0F) << 8U) |
           static_cast<std::uint32_t>(preset & 0xFF);
}

static bool decodeQuickPreset(std::uint32_t id, int& voice, int& preset) noexcept {
    if ((id & 0xFFFF0000U) != kQuickPresetBase) return false;
    voice = static_cast<int>((id >> 8U) & 0x0FU);
    preset = static_cast<int>(id & 0xFFU);
    return voice >= 0 && voice < 4 && preset >= 0 && preset <= 16;
}

struct HitItem {
    NSRect rect{};
    std::uint32_t id = 0;
    bool numeric = false;
};

static NSColor* rgb(CGFloat r, CGFloat g, CGFloat b, CGFloat a = 1.0) {
    return [NSColor colorWithCalibratedRed:r green:g blue:b alpha:a];
}

static void roundedFill(NSRect r, CGFloat radius, NSColor* color) {
    [color setFill];
    [[NSBezierPath bezierPathWithRoundedRect:r xRadius:radius yRadius:radius] fill];
}

static void roundedStroke(NSRect r, CGFloat radius, NSColor* color, CGFloat width = 1.0) {
    [color setStroke];
    NSBezierPath* p = [NSBezierPath bezierPathWithRoundedRect:r xRadius:radius yRadius:radius];
    [p setLineWidth:width];
    [p stroke];
}

static void text(NSString* s, NSRect r, CGFloat size, NSColor* color,
                 NSTextAlignment align = NSTextAlignmentLeft, bool bold = false) {
    if (!s) return;
    NSMutableParagraphStyle* ps = [[NSMutableParagraphStyle alloc] init];
    ps.alignment = align;
    NSFont* font = bold ? [NSFont boldSystemFontOfSize:size] : [NSFont systemFontOfSize:size];
    NSDictionary* attrs = @{NSFontAttributeName: font,
                            NSForegroundColorAttributeName: color,
                            NSParagraphStyleAttributeName: ps};
    [s drawInRect:r withAttributes:attrs];
}

static NSString* ns(const std::string& s) {
    return [NSString stringWithUTF8String:s.c_str()];
}

static std::string midiName(int midi) {
    if (midi < 0 || midi > 127) return "--";
    static const char* names[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
    const int octave = midi / 12 - 1;
    return std::string(names[midi % 12]) + std::to_string(octave);
}

static float linearToDb(float x) {
    return x <= 1.0e-6f ? -60.0f : std::max(-60.0f, 20.0f * std::log10(x));
}

static CGFloat meterNormForDb(float db) {
    return static_cast<CGFloat>(std::clamp((db + 60.0f) / 60.0f, 0.0f, 1.0f));
}

static NSString* presetClassText(int preset) {
    if (preset == 1 || preset == 2 || preset == 7 || preset == 8 || preset == 11 || preset == 12)
        return @"SCALE AWARE";
    if (preset == 0) return @"CUSTOM";
    return @"FIXED INTERVAL";
}

} // namespace

@interface HarmonyNativeView : NSView <NSTextFieldDelegate> {
@private
    harmonyplugin::HarmonyController* _controller;
    std::vector<HitItem> _hits;
    BOOL _dragging;
    std::uint32_t _dragId;
    double _dragStartNorm;
    CGFloat _dragStartY;
    NSTextField* _numberEditor;
    std::uint32_t _numberId;
    NSTimer* _timer;
    std::array<float, 7> _peakHoldDb;
    std::array<int, 7> _peakHoldTicks;
}
- (instancetype)initWithFrame:(NSRect)frame controller:(harmonyplugin::HarmonyController*)controller;
- (void)choiceMenuSelected:(NSMenuItem*)sender;
- (void)shutdown;
@end

@implementation HarmonyNativeView

- (instancetype)initWithFrame:(NSRect)frame controller:(harmonyplugin::HarmonyController*)controller {
    self = [super initWithFrame:frame];
    if (self) {
        _controller = controller;
        _dragging = NO;
        _dragId = 0;
        _numberEditor = nil;
        _numberId = 0;
        _peakHoldDb.fill(-60.0f);
        _peakHoldTicks.fill(0);
        // NSTimer retains its target. A self-target timer here creates a retain
        // cycle (run loop -> timer -> view -> timer). When Cubase removes the
        // plug-in, that stale timer can keep firing after the VST controller
        // has been released. Use a weak block target and also shut the timer
        // down explicitly from IPlugView::removed().
        __weak HarmonyNativeView* weakSelf = self;
        _timer = [NSTimer scheduledTimerWithTimeInterval:0.05
                                                 repeats:YES
                                                   block:^(NSTimer* timer) {
            HarmonyNativeView* strongSelf = weakSelf;
            if (strongSelf) [strongSelf refreshMeters:timer];
            else [timer invalidate];
        }];
    }
    return self;
}

- (BOOL)isFlipped { return YES; }
- (BOOL)acceptsFirstResponder { return YES; }

- (void)shutdown {
    // Idempotent teardown. The controller pointer belongs to the VST3
    // controller and must never be touched after the editor is detached.
    _controller = nullptr;
    _dragging = NO;
    _dragId = 0;
    _numberId = 0;

    if (_timer) {
        [_timer invalidate];
        _timer = nil;
    }
    if (_numberEditor) {
        _numberEditor.delegate = nil;
        [_numberEditor removeFromSuperview];
        _numberEditor = nil;
    }
}

- (void)dealloc {
    [self shutdown];
#if !__has_feature(objc_arc)
    [super dealloc];
#endif
}

- (double)normFor:(std::uint32_t)pid {
    return _controller ? _controller->getParamNormalized(static_cast<ParamID>(pid)) : 0.0;
}

- (double)plainFor:(std::uint32_t)pid {
    const auto* spec = harmonyplugin::findSpec(pid);
    return spec ? harmonyplugin::denormalize(*spec, [self normFor:pid]) : 0.0;
}

- (void)setParam:(std::uint32_t)pid norm:(double)value begin:(BOOL)begin end:(BOOL)end {
    if (_controller) _controller->setFromUI(static_cast<ParamID>(pid), value, begin, end);
    [self setNeedsDisplay:YES];
}

- (void)setPlain:(std::uint32_t)pid value:(double)value {
    const auto* spec = harmonyplugin::findSpec(pid);
    if (!spec || spec->readOnly) return;
    [self setParam:pid norm:harmonyplugin::normalizePlain(*spec, value) begin:YES end:YES];
}

- (void)resetParam:(std::uint32_t)pid {
    if (const auto* spec = harmonyplugin::findSpec(pid))
        [self setParam:pid norm:harmonyplugin::defaultNormalized(*spec) begin:YES end:YES];
}

- (void)refreshMeters:(NSTimer*)timer {
    (void)timer;
    const std::uint32_t ids[7] = {kMeterInput, kMeterOutputL, kMeterOutputR,
                                  kMeterVoice1, kMeterVoice2, kMeterVoice3, kMeterVoice4};
    for (int i = 0; i < 7; ++i) {
        const float db = linearToDb(static_cast<float>([self normFor:ids[i]]));
        if (db >= _peakHoldDb[static_cast<std::size_t>(i)]) {
            _peakHoldDb[static_cast<std::size_t>(i)] = db;
            _peakHoldTicks[static_cast<std::size_t>(i)] = 20;
        } else if (_peakHoldTicks[static_cast<std::size_t>(i)] > 0) {
            --_peakHoldTicks[static_cast<std::size_t>(i)];
        } else {
            _peakHoldDb[static_cast<std::size_t>(i)] = std::max(-60.0f, _peakHoldDb[static_cast<std::size_t>(i)] - 1.25f);
        }
    }
    [self setNeedsDisplay:YES];
}

- (void)addHit:(NSRect)r id:(std::uint32_t)pid numeric:(BOOL)numeric {
    _hits.push_back({r, pid, numeric == YES});
}

- (void)drawPanel:(NSRect)r title:(NSString*)titleString {
    roundedFill(r, 9.0, rgb(0.060, 0.071, 0.082));
    roundedStroke(r, 9.0, rgb(0.145, 0.175, 0.198), 1.0);
    if (titleString) {
        [rgb(0.075, 0.48, 0.72) setFill];
        NSRectFill(NSMakeRect(r.origin.x, r.origin.y, 3.0, r.size.height));
        text(titleString, NSMakeRect(r.origin.x + 14, r.origin.y + 9, r.size.width - 28, 17),
             10.5, rgb(0.68, 0.76, 0.82), NSTextAlignmentLeft, true);
    }
}

- (void)drawToggle:(std::uint32_t)pid label:(NSString*)label rect:(NSRect)r {
    const BOOL on = [self plainFor:pid] >= 0.5;
    roundedFill(r, 5.0, on ? rgb(0.065, 0.42, 0.64) : rgb(0.095, 0.11, 0.125));
    roundedStroke(r, 5.0, on ? rgb(0.18, 0.70, 0.94) : rgb(0.19, 0.22, 0.25), 1.0);
    text(label, NSInsetRect(r, 4, 5), 9.5, on ? NSColor.whiteColor : rgb(0.62, 0.68, 0.72), NSTextAlignmentCenter, true);
    [self addHit:r id:pid numeric:NO];
}

- (void)drawChoice:(std::uint32_t)pid label:(NSString*)label rect:(NSRect)r {
    const auto* spec = harmonyplugin::findSpec(pid);
    if (!spec) return;
    text(label, NSMakeRect(r.origin.x, r.origin.y, r.size.width, 13), 8.5, rgb(0.43, 0.52, 0.59), NSTextAlignmentLeft, true);
    NSRect valueRect = NSMakeRect(r.origin.x, r.origin.y + 16, r.size.width, 30);
    roundedFill(valueRect, 5.0, rgb(0.080, 0.095, 0.108));
    roundedStroke(valueRect, 5.0, rgb(0.16, 0.27, 0.34), 1.0);
    const std::string v = harmonyplugin::valueText(*spec, [self normFor:pid]);
    text(ns(v), NSMakeRect(valueRect.origin.x + 8, valueRect.origin.y + 7, valueRect.size.width - 27, 16),
         10, rgb(0.82, 0.88, 0.92), NSTextAlignmentLeft, true);
    text(@"▾", NSMakeRect(NSMaxX(valueRect) - 21, valueRect.origin.y + 6, 14, 17),
         11, rgb(0.28, 0.68, 0.90), NSTextAlignmentCenter, true);
    [self addHit:valueRect id:pid numeric:NO];
}

- (void)drawKnob:(std::uint32_t)pid label:(NSString*)label rect:(NSRect)r {
    const auto* spec = harmonyplugin::findSpec(pid);
    if (!spec) return;
    const double norm = [self normFor:pid];
    text(label, NSMakeRect(r.origin.x, r.origin.y, r.size.width, 12), 8, rgb(0.43, 0.52, 0.59), NSTextAlignmentCenter, true);

    const CGFloat cx = NSMidX(r);
    const CGFloat cy = r.origin.y + 35.0;
    const CGFloat radius = std::min<CGFloat>(18.0, r.size.width * 0.29);
    NSRect circle = NSMakeRect(cx - radius, cy - radius, radius * 2.0, radius * 2.0);
    roundedFill(circle, radius, rgb(0.085, 0.102, 0.116));
    roundedStroke(circle, radius, rgb(0.20, 0.24, 0.27), 1.0);

    NSBezierPath* track = [NSBezierPath bezierPath];
    [track appendBezierPathWithArcWithCenter:NSMakePoint(cx, cy) radius:radius + 4.0 startAngle:225 endAngle:-45 clockwise:YES];
    [track setLineWidth:2.3];
    [rgb(0.13, 0.16, 0.18) setStroke];
    [track stroke];

    const CGFloat angle = 225.0 - static_cast<CGFloat>(270.0 * harmonyplugin::clamp01(norm));
    const CGFloat radians = angle * static_cast<CGFloat>(M_PI / 180.0);
    NSPoint p1 = NSMakePoint(cx + std::cos(radians) * 4.0, cy - std::sin(radians) * 4.0);
    NSPoint p2 = NSMakePoint(cx + std::cos(radians) * (radius - 3.0), cy - std::sin(radians) * (radius - 3.0));
    NSBezierPath* needle = [NSBezierPath bezierPath];
    [needle moveToPoint:p1];
    [needle lineToPoint:p2];
    [needle setLineWidth:2.0];
    [rgb(0.15, 0.70, 0.95) setStroke];
    [needle stroke];

    NSRect valueRect = NSMakeRect(r.origin.x + 3, r.origin.y + r.size.height - 18, r.size.width - 6, 17);
    roundedFill(valueRect, 3.0, rgb(0.047, 0.058, 0.068));
    const std::string v = harmonyplugin::valueText(*spec, norm);
    text(ns(v), NSInsetRect(valueRect, 2, 2), 8, rgb(0.68, 0.77, 0.83), NSTextAlignmentCenter, false);

    NSRect dragRect = NSMakeRect(r.origin.x, r.origin.y + 13, r.size.width, r.size.height - 32);
    [self addHit:dragRect id:pid numeric:NO];
    [self addHit:valueRect id:pid numeric:YES];
}

- (void)drawSmallControl:(std::uint32_t)pid label:(NSString*)label rect:(NSRect)r {
    const auto* spec = harmonyplugin::findSpec(pid);
    if (!spec) return;
    if (spec->kind == ParamKind::Toggle) {
        [self drawToggle:pid label:label rect:NSMakeRect(r.origin.x, r.origin.y + 16, r.size.width, 26)];
        return;
    }
    if (spec->kind == ParamKind::Choice) {
        [self drawChoice:pid label:label rect:r];
        return;
    }
    [self drawKnob:pid label:label rect:NSMakeRect(r.origin.x, r.origin.y, r.size.width, 68)];
}

- (void)drawQuickPresetForVoice:(int)voice preset:(int)preset label:(NSString*)label rect:(NSRect)r {
    const int current = static_cast<int>(std::lround([self plainFor:voiceParamId(voice, kVoiceHarmonyPreset)]));
    const BOOL active = current == preset;
    roundedFill(r, 4.0, active ? rgb(0.07, 0.42, 0.63) : rgb(0.077, 0.091, 0.103));
    roundedStroke(r, 4.0, active ? rgb(0.17, 0.70, 0.94) : rgb(0.16, 0.20, 0.23), 1.0);
    text(label, NSInsetRect(r, 3, 5), 8.5, active ? NSColor.whiteColor : rgb(0.63, 0.70, 0.75), NSTextAlignmentCenter, true);
    [self addHit:r id:quickPresetId(voice, preset) numeric:NO];
}

- (void)drawMeter:(std::uint32_t)pid holdIndex:(int)holdIndex label:(NSString*)label rect:(NSRect)r {
    const float linear = static_cast<float>([self normFor:pid]);
    const float db = linearToDb(linear);
    const CGFloat n = meterNormForDb(db);
    NSRect track = NSMakeRect(r.origin.x + 6, r.origin.y + 18, r.size.width - 12, r.size.height - 39);
    roundedFill(track, 3.0, rgb(0.035, 0.044, 0.051));
    roundedStroke(track, 3.0, rgb(0.12, 0.15, 0.17), 1.0);

    NSRect bar = track;
    bar.origin.y = track.origin.y + track.size.height * (1.0 - n);
    bar.size.height = track.size.height * n;
    if (bar.size.height > 0.5) {
        NSGradient* g = [[NSGradient alloc] initWithColors:@[rgb(0.16,0.72,0.35), rgb(0.88,0.72,0.16), rgb(0.90,0.20,0.16)]];
        [g drawInRect:bar angle:90.0];
    }

    const float holdDb = _peakHoldDb[static_cast<std::size_t>(std::clamp(holdIndex, 0, 6))];
    const CGFloat hn = meterNormForDb(holdDb);
    const CGFloat hy = track.origin.y + track.size.height * (1.0 - hn);
    [rgb(0.84, 0.91, 0.95) setFill];
    NSRectFill(NSMakeRect(track.origin.x, hy, track.size.width, 1.0));

    text(label, NSMakeRect(r.origin.x, r.origin.y, r.size.width, 14), 8, rgb(0.53,0.61,0.67), NSTextAlignmentCenter, true);
    char dbText[32]{};
    std::snprintf(dbText, sizeof(dbText), db <= -59.9f ? "-inf" : "%.1f", db);
    text([NSString stringWithUTF8String:dbText], NSMakeRect(r.origin.x, NSMaxY(r)-17, r.size.width, 14), 7.5, rgb(0.58,0.66,0.72), NSTextAlignmentCenter, false);
}

- (void)drawMeterPanel {
    NSRect panel = NSMakeRect(742, 82, 220, 500);
    [self drawPanel:panel title:@"REAL-TIME"];
    const CGFloat meterY = 125, meterH = 260, meterX = 774, step = 42.0;
    const std::uint32_t ids[4] = {kMeterInput,kMeterVoice1,kMeterOutputL,kMeterOutputR};
    NSString* labels[4] = {@"IN",@"3RD",@"L",@"R"};
    for (int i=0;i<4;++i) [self drawMeter:ids[i] holdIndex:i label:labels[i] rect:NSMakeRect(meterX+step*i,meterY,28,meterH)];
    const int dbMarks[] = {0,-6,-12,-24,-36,-48,-60};
    for (int db:dbMarks) {
        const CGFloat y=meterY+18+(meterH-39)*(1.0-meterNormForDb((float)db));
        [rgb(0.16,0.19,0.21) setFill]; NSRectFill(NSMakeRect(754,y,12,1));
        text([NSString stringWithFormat:@"%d",db],NSMakeRect(748,y-6,24,12),6.5,rgb(0.38,0.45,0.50),NSTextAlignmentLeft,false);
    }
    const int pitch=(int)std::lround([self plainFor:kMeterPitchMidi]);
    const double conf=[self plainFor:kMeterPitchConfidence];
    const int target=(int)std::lround([self plainFor:kMeterTarget1]);
    roundedFill(NSMakeRect(758,414,188,104),7,rgb(0.046,0.057,0.066));
    text(@"PITCH TRACKER",NSMakeRect(772,425,160,14),9,rgb(0.28,0.68,0.90),NSTextAlignmentLeft,true);
    text([NSString stringWithFormat:@"Lead     %s",midiName(pitch).c_str()],NSMakeRect(772,449,160,18),11,rgb(0.79,0.86,0.91),NSTextAlignmentLeft,true);
    text([NSString stringWithFormat:@"Third    %s",midiName(target).c_str()],NSMakeRect(772,472,160,18),11,rgb(0.79,0.86,0.91),NSTextAlignmentLeft,true);
    text([NSString stringWithFormat:@"Lock     %.0f%%",conf],NSMakeRect(772,495,160,16),9,rgb(0.55,0.64,0.70),NSTextAlignmentLeft,false);
    text(@"Real DSP meters",NSMakeRect(758,548,188,16),7.5,rgb(0.39,0.46,0.51),NSTextAlignmentCenter,false);
}

- (void)drawHeader {
    [rgb(0.027,0.033,0.039) setFill]; NSRectFill(self.bounds);
    [rgb(0.043,0.052,0.061) setFill]; NSRectFill(NSMakeRect(0,0,kEditorWidth,66));
    [rgb(0.07,0.48,0.72) setFill]; NSRectFill(NSMakeRect(0,64,kEditorWidth,2));
    text(@"TERCIOR AUDIO",NSMakeRect(20,9,160,14),8.5,rgb(0.24,0.67,0.91),NSTextAlignmentLeft,true);
    text(@"HARMONY ENGINE",NSMakeRect(20,22,330,29),23,rgb(0.87,0.92,0.95),NSTextAlignmentLeft,true);
    text(@"THIRDS ONLY / STABLE TRACKING",NSMakeRect(222,30,280,15),8.5,rgb(0.44,0.52,0.58),NSTextAlignmentLeft,true);
    [self drawToggle:kLeadMute label:@"LEAD MUTE" rect:NSMakeRect(725,17,126,31)];
    [self drawToggle:kBypass label:@"BYPASS" rect:NSMakeRect(861,17,98,31)];
}

- (void)drawTopStrip {
    NSRect p=NSMakeRect(18,82,706,118); [self drawPanel:p title:@"TONALITY"];
    [self drawChoice:kKey label:@"KEY / TONALITY" rect:NSMakeRect(40,118,130,48)];
    [self drawChoice:kScale label:@"SCALE / MODE" rect:NSMakeRect(190,118,185,48)];
    [self drawKnob:kInputDb label:@"INPUT" rect:NSMakeRect(405,108,76,76)];
    [self drawKnob:kWetDb label:@"HARMONY" rect:NSMakeRect(497,108,76,76)];
    [self drawKnob:kOutputDb label:@"OUTPUT" rect:NSMakeRect(589,108,76,76)];
    text(@"Only third harmonies are active in this build.",NSMakeRect(40,175,620,14),8.2,rgb(0.41,0.49,0.55),NSTextAlignmentLeft,false);
}

- (void)drawThirdsPanel {
    NSRect panel=NSMakeRect(18,218,706,364); [self drawPanel:panel title:@"THIRDS"];
    [self drawToggle:voiceParamId(0,kVoiceEnable) label:@"ON" rect:NSMakeRect(42,257,60,29)];
    [self drawToggle:voiceParamId(0,kVoiceMute) label:@"MUTE" rect:NSMakeRect(112,257,72,29)];
    [self drawToggle:voiceParamId(0,kVoiceSolo) label:@"SOLO THIRD" rect:NSMakeRect(194,257,104,29)];
    const int presets[6]={1,2,3,4,5,6};
    NSString* labels[6]={@"3RD UP",@"3RD DOWN",@"m3 UP",@"m3 DOWN",@"M3 UP",@"M3 DOWN"};
    for(int i=0;i<6;++i){ const int row=i/3,col=i%3; [self drawQuickPresetForVoice:0 preset:presets[i] label:labels[i] rect:NSMakeRect(42+col*205,315+row*62,185,42)]; }
    const int preset=(int)std::lround([self plainFor:voiceParamId(0,kVoiceHarmonyPreset)]);
    NSString* kind=presetClassText(preset);
    roundedFill(NSMakeRect(42,454,390,62),7,rgb(0.043,0.055,0.064)); roundedStroke(NSMakeRect(42,454,390,62),7,rgb(0.13,0.20,0.25),1);
    text(@"ACTIVE THIRD",NSMakeRect(57,465,120,13),8,rgb(0.28,0.68,0.90),NSTextAlignmentLeft,true);
    const auto* spec=harmonyplugin::findSpec(voiceParamId(0,kVoiceHarmonyPreset));
    const std::string value=spec?harmonyplugin::valueText(*spec,[self normFor:voiceParamId(0,kVoiceHarmonyPreset)]):"--";
    text(ns(value),NSMakeRect(57,484,240,19),13,rgb(0.84,0.90,0.94),NSTextAlignmentLeft,true);
    text(kind,NSMakeRect(295,485,120,17),8,rgb(0.33,0.65,0.82),NSTextAlignmentRight,true);
    [self drawKnob:voiceParamId(0,kVoiceLevel) label:@"THIRD LEVEL" rect:NSMakeRect(505,443,112,92)];
    text(@"Scale 3rd uses KEY + SCALE.  m3/M3 are fixed 3/4-semitone thirds.",NSMakeRect(42,542,615,18),8.2,rgb(0.45,0.53,0.59),NSTextAlignmentLeft,false);
}

- (void)drawMainPage { [self drawThirdsPanel]; [self drawMeterPanel]; }

- (void)drawRect:(NSRect)dirtyRect {
    (void)dirtyRect;
    _hits.clear();
    [self drawHeader];
    [self drawTopStrip];
    [self drawMainPage];
}

- (HitItem*)hitAt:(NSPoint)p {
    for (auto it = _hits.rbegin(); it != _hits.rend(); ++it)
        if (NSPointInRect(p, it->rect)) return &(*it);
    return nullptr;
}

- (void)beginNumericFor:(std::uint32_t)pid rect:(NSRect)r {
    const auto* spec = harmonyplugin::findSpec(pid);
    if (!spec || spec->readOnly) return;
    [_numberEditor removeFromSuperview];
    _numberEditor = [[NSTextField alloc] initWithFrame:NSInsetRect(r, -3, -2)];
    _numberId = pid;
    _numberEditor.delegate = self;
    _numberEditor.font = [NSFont systemFontOfSize:11];
    _numberEditor.alignment = NSTextAlignmentCenter;
    _numberEditor.stringValue = [NSString stringWithFormat:@"%.4g", [self plainFor:pid]];
    [self addSubview:_numberEditor];
    [self.window makeFirstResponder:_numberEditor];
    [_numberEditor selectText:nil];
}

- (void)controlTextDidEndEditing:(NSNotification*)obj {
    (void)obj;
    if (!_numberEditor || _numberId == 0) return;
    const auto* spec = harmonyplugin::findSpec(_numberId);
    if (spec) {
        const double plain = _numberEditor.doubleValue;
        [self setParam:_numberId norm:harmonyplugin::normalizePlain(*spec, plain) begin:YES end:YES];
    }
    [_numberEditor removeFromSuperview];
    _numberEditor = nil;
    _numberId = 0;
    [self.window makeFirstResponder:self];
}

- (void)showChoiceMenuFor:(std::uint32_t)pid event:(NSEvent*)event {
    const auto* spec = harmonyplugin::findSpec(pid);
    if (!spec || spec->readOnly || spec->kind != ParamKind::Choice || !spec->choices || spec->choiceCount <= 0) return;

    NSMenu* menu = [[NSMenu alloc] initWithTitle:@""];
    const int current = std::clamp(static_cast<int>(std::lround([self plainFor:pid])), 0, spec->choiceCount - 1);
    for (int i = 0; i < spec->choiceCount; ++i) {
        NSMenuItem* item = [[NSMenuItem alloc] initWithTitle:[NSString stringWithUTF8String:spec->choices[i]]
                                                      action:@selector(choiceMenuSelected:)
                                               keyEquivalent:@""];
        item.target = self;
        item.representedObject = @[@(pid), @(i)];
        item.state = (i == current) ? NSControlStateValueOn : NSControlStateValueOff;
        [menu addItem:item];
    }
    [NSMenu popUpContextMenu:menu withEvent:event forView:self];
}

- (void)choiceMenuSelected:(NSMenuItem*)sender {
    NSArray* data = (NSArray*)sender.representedObject;
    if (![data isKindOfClass:[NSArray class]] || data.count != 2) return;
    const std::uint32_t pid = [data[0] unsignedIntValue];
    const int index = [data[1] intValue];
    [self setPlain:pid value:index];
}

- (void)mouseDown:(NSEvent*)event {
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    HitItem* h = [self hitAt:p];
    if (!h) return;


    int quickVoice = 0, quickPreset = 0;
    if (decodeQuickPreset(h->id, quickVoice, quickPreset)) {
        [self setPlain:voiceParamId(quickVoice, kVoiceHarmonyPreset) value:quickPreset];
        // A quick harmony button is an audition/action control, not merely a
        // hidden preset selector. Make the selected voice audible immediately.
        [self setPlain:voiceParamId(quickVoice, kVoiceEnable) value:1.0];
        return;
    }

    const auto* spec = harmonyplugin::findSpec(h->id);
    if (!spec || spec->readOnly) return;

    if (event.clickCount >= 2) { [self resetParam:h->id]; return; }
    if (h->numeric || (event.modifierFlags & NSEventModifierFlagOption)) {
        [self beginNumericFor:h->id rect:h->rect];
        return;
    }

    if (spec->kind == ParamKind::Toggle) {
        const double next = [self plainFor:h->id] >= 0.5 ? 0.0 : 1.0;
        [self setPlain:h->id value:next];
        if (next >= 0.5 && h->id >= kVoiceBase && h->id < kVoiceBase + 4 * kVoiceStride) {
            const std::uint32_t rel = h->id - kVoiceBase;
            const int voice = static_cast<int>(rel / kVoiceStride);
            const std::uint32_t offset = rel % kVoiceStride;
            if (voice >= 0 && voice < 4 && offset == static_cast<std::uint32_t>(kVoiceSolo))
                [self setPlain:voiceParamId(voice, kVoiceEnable) value:1.0];
        }
        return;
    }
    if (spec->kind == ParamKind::Choice) {
        [self showChoiceMenuFor:h->id event:event];
        return;
    }

    _dragging = YES;
    _dragId = h->id;
    _dragStartNorm = [self normFor:h->id];
    _dragStartY = p.y;
    if (_controller) _controller->beginEdit(static_cast<ParamID>(_dragId));
}

- (void)mouseDragged:(NSEvent*)event {
    if (!_dragging || _dragId == 0) return;
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    const double sensitivity = (event.modifierFlags & NSEventModifierFlagShift) ? 600.0 : 180.0;
    const double norm = harmonyplugin::clamp01(_dragStartNorm + (_dragStartY - p.y) / sensitivity);
    if (_controller) {
        _controller->setParamNormalized(static_cast<ParamID>(_dragId), norm);
        _controller->performEdit(static_cast<ParamID>(_dragId), norm);
    }
    [self setNeedsDisplay:YES];
}

- (void)mouseUp:(NSEvent*)event {
    (void)event;
    if (_dragging && _dragId != 0 && _controller)
        _controller->endEdit(static_cast<ParamID>(_dragId));
    _dragging = NO;
    _dragId = 0;
}

@end

namespace harmonyplugin {

class HarmonyEditorView final : public CPluginView {
public:
    explicit HarmonyEditorView(HarmonyController* controller)
        : CPluginView(&initialRect()), controller_(controller) {
        if (controller_) controller_->addRef();
    }

    ~HarmonyEditorView() override {
        if (nativeView_) {
            [nativeView_ shutdown];
            [nativeView_ removeFromSuperview];
            nativeView_ = nil;
        }
        if (controller_) {
            controller_->release();
            controller_ = nullptr;
        }
    }

    tresult PLUGIN_API isPlatformTypeSupported(FIDString type) SMTG_OVERRIDE {
        return type && std::strcmp(type, kPlatformTypeNSView) == 0 ? kResultTrue : kResultFalse;
    }

    tresult PLUGIN_API attached(void* parent, FIDString type) SMTG_OVERRIDE {
        if (!parent || isPlatformTypeSupported(type) != kResultTrue || nativeView_) return kResultFalse;
        systemWindow = parent;
        NSView* parentView = (__bridge NSView*)parent;
        nativeView_ = [[HarmonyNativeView alloc] initWithFrame:NSMakeRect(0, 0, kEditorWidth, kEditorHeight) controller:controller_];
        [parentView addSubview:nativeView_];
        return kResultOk;
    }

    tresult PLUGIN_API removed() SMTG_OVERRIDE {
        if (nativeView_) {
            // Stop all callbacks before releasing the native view or the
            // controller. This is required because Cubase can destroy the
            // VST3 instance immediately after detaching the editor.
            [nativeView_ shutdown];
            [nativeView_ removeFromSuperview];
            nativeView_ = nil;
        }
        systemWindow = nullptr;
        return kResultOk;
    }

    tresult PLUGIN_API onSize(ViewRect* newSize) SMTG_OVERRIDE {
        if (!newSize) return kInvalidArgument;
        rect = *newSize;
        if (nativeView_) [nativeView_ setFrame:NSMakeRect(0, 0, rect.getWidth(), rect.getHeight())];
        return kResultTrue;
    }

    tresult PLUGIN_API canResize() SMTG_OVERRIDE { return kResultFalse; }

private:
    static ViewRect& initialRect() {
        static ViewRect r(0, 0, static_cast<int32>(kEditorWidth), static_cast<int32>(kEditorHeight));
        return r;
    }

    HarmonyController* controller_ = nullptr;
    HarmonyNativeView* nativeView_ = nil;
};

Steinberg::IPlugView* createHarmonyEditor(HarmonyController* controller) {
    return new HarmonyEditorView(controller);
}

} // namespace harmonyplugin
