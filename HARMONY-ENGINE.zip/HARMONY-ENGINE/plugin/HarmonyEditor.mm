#import <Cocoa/Cocoa.h>

#include "HarmonyEditor.h"
#include "HarmonyController.h"
#include "Parameters.h"
#include "PluginIDs.h"

#include "public.sdk/source/common/pluginview.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>

using namespace harmonyplugin;
using namespace Steinberg;
using namespace Steinberg::Vst;

namespace {
constexpr CGFloat kEditorWidth = 1180.0;
constexpr CGFloat kEditorHeight = 760.0;
constexpr std::uint32_t kTabMain = 0xFFFFFF01U;
constexpr std::uint32_t kTabAdvanced = 0xFFFFFF02U;

struct HitItem {
    NSRect rect{};
    std::uint32_t id = 0;
    bool numeric = false;
};

static NSColor* rgb(CGFloat r, CGFloat g, CGFloat b, CGFloat a = 1.0) {
    return [NSColor colorWithCalibratedRed:r green:g blue:b alpha:a];
}

static void roundedFill(NSRect r, CGFloat radius, NSColor* color) {
    [color setFill];
    [[NSBezierPath bezierPathWithRoundedRect:r xRadius:radius yRadius:radius] fill];
}

static void roundedStroke(NSRect r, CGFloat radius, NSColor* color, CGFloat width = 1.0) {
    [color setStroke];
    NSBezierPath* p = [NSBezierPath bezierPathWithRoundedRect:r xRadius:radius yRadius:radius];
    [p setLineWidth:width];
    [p stroke];
}

static void text(NSString* s, NSRect r, CGFloat size, NSColor* color, NSTextAlignment align = NSTextAlignmentLeft, bool bold = false) {
    if (!s) return;
    NSMutableParagraphStyle* ps = [[NSMutableParagraphStyle alloc] init];
    ps.alignment = align;
    NSFont* font = bold ? [NSFont boldSystemFontOfSize:size] : [NSFont systemFontOfSize:size];
    NSDictionary* attrs = @{ NSFontAttributeName: font, NSForegroundColorAttributeName: color, NSParagraphStyleAttributeName: ps };
    [s drawInRect:r withAttributes:attrs];
}

static NSString* ns(const std::string& s) {
    return [NSString stringWithUTF8String:s.c_str()];
}

static std::string midiName(int midi) {
    if (midi < 0 || midi > 127) return "--";
    static const char* names[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
    const int octave = midi / 12 - 1;
    return std::string(names[midi % 12]) + std::to_string(octave);
}

static float linearToDb(float x) {
    return x <= 1.0e-6f ? -60.0f : std::max(-60.0f, 20.0f * std::log10(x));
}

static CGFloat meterNormForDb(float db) {
    return static_cast<CGFloat>(std::clamp((db + 60.0f) / 60.0f, 0.0f, 1.0f));
}

} // namespace

@interface HarmonyNativeView : NSView <NSTextFieldDelegate> {
@private
    harmonyplugin::HarmonyController* _controller;
    std::vector<HitItem> _hits;
    BOOL _advanced;
    BOOL _dragging;
    std::uint32_t _dragId;
    double _dragStartNorm;
    CGFloat _dragStartY;
    NSTextField* _numberEditor;
    std::uint32_t _numberId;
    NSTimer* _timer;
    std::array<float, 7> _peakHoldDb;
    std::array<int, 7> _peakHoldTicks;
}
- (instancetype)initWithFrame:(NSRect)frame controller:(harmonyplugin::HarmonyController*)controller;
@end

@implementation HarmonyNativeView

- (instancetype)initWithFrame:(NSRect)frame controller:(harmonyplugin::HarmonyController*)controller {
    self = [super initWithFrame:frame];
    if (self) {
        _controller = controller;
        _advanced = NO;
        _dragging = NO;
        _dragId = 0;
        _numberEditor = nil;
        _numberId = 0;
        _peakHoldDb.fill(-60.0f);
        _peakHoldTicks.fill(0);
        _timer = [NSTimer scheduledTimerWithTimeInterval:0.05
                                                  target:self
                                                selector:@selector(refreshMeters:)
                                                userInfo:nil
                                                 repeats:YES];
    }
    return self;
}

- (BOOL)isFlipped { return YES; }
- (BOOL)acceptsFirstResponder { return YES; }

- (void)dealloc {
    [_timer invalidate];
    _timer = nil;
    [_numberEditor removeFromSuperview];
    _numberEditor = nil;
#if !__has_feature(objc_arc)
    [super dealloc];
#endif
}

- (double)normFor:(std::uint32_t)pid {
    return _controller ? _controller->getParamNormalized(static_cast<ParamID>(pid)) : 0.0;
}

- (double)plainFor:(std::uint32_t)pid {
    const auto* spec = harmonyplugin::findSpec(pid);
    return spec ? harmonyplugin::denormalize(*spec, [self normFor:pid]) : 0.0;
}

- (void)setParam:(std::uint32_t)pid norm:(double)value begin:(BOOL)begin end:(BOOL)end {
    if (_controller) _controller->setFromUI(static_cast<ParamID>(pid), value, begin, end);
    [self setNeedsDisplay:YES];
}

- (void)resetParam:(std::uint32_t)pid {
    if (const auto* spec = harmonyplugin::findSpec(pid))
        [self setParam:pid norm:harmonyplugin::defaultNormalized(*spec) begin:YES end:YES];
}

- (void)refreshMeters:(NSTimer*)timer {
    (void)timer;
    const std::uint32_t ids[7] = { kMeterInput, kMeterOutputL, kMeterOutputR,
                                   kMeterVoice1, kMeterVoice2, kMeterVoice3, kMeterVoice4 };
    for (int i = 0; i < 7; ++i) {
        const float db = linearToDb(static_cast<float>([self normFor:ids[i]]));
        if (db >= _peakHoldDb[static_cast<std::size_t>(i)]) {
            _peakHoldDb[static_cast<std::size_t>(i)] = db;
            _peakHoldTicks[static_cast<std::size_t>(i)] = 20; // ~1 second at 20 Hz
        } else if (_peakHoldTicks[static_cast<std::size_t>(i)] > 0) {
            --_peakHoldTicks[static_cast<std::size_t>(i)];
        } else {
            _peakHoldDb[static_cast<std::size_t>(i)] = std::max(-60.0f, _peakHoldDb[static_cast<std::size_t>(i)] - 1.25f);
        }
    }
    [self setNeedsDisplay:YES];
}

- (void)addHit:(NSRect)r id:(std::uint32_t)pid numeric:(BOOL)numeric {
    _hits.push_back({r, pid, numeric == YES});
}

- (void)drawPanel:(NSRect)r title:(NSString*)titleString {
    roundedFill(r, 8.0, rgb(0.085, 0.095, 0.108));
    roundedStroke(r, 8.0, rgb(0.18, 0.21, 0.24), 1.0);
    if (titleString) text(titleString, NSMakeRect(r.origin.x + 12, r.origin.y + 8, r.size.width - 24, 18), 11, rgb(0.60, 0.67, 0.73), NSTextAlignmentLeft, true);
}

- (void)drawToggle:(std::uint32_t)pid label:(NSString*)label rect:(NSRect)r {
    const BOOL on = [self plainFor:pid] >= 0.5;
    roundedFill(r, 5.0, on ? rgb(0.08, 0.45, 0.67) : rgb(0.13, 0.15, 0.17));
    roundedStroke(r, 5.0, on ? rgb(0.18, 0.68, 0.92) : rgb(0.25, 0.28, 0.31), 1.0);
    text(label, NSInsetRect(r, 4, 5), 10, on ? NSColor.whiteColor : rgb(0.70, 0.74, 0.78), NSTextAlignmentCenter, true);
    [self addHit:r id:pid numeric:NO];
}

- (void)drawChoice:(std::uint32_t)pid label:(NSString*)label rect:(NSRect)r {
    const auto* spec = harmonyplugin::findSpec(pid);
    if (!spec) return;
    text(label, NSMakeRect(r.origin.x, r.origin.y, r.size.width, 14), 9, rgb(0.48, 0.55, 0.61), NSTextAlignmentLeft, false);
    NSRect valueRect = NSMakeRect(r.origin.x, r.origin.y + 16, r.size.width, 29);
    roundedFill(valueRect, 5.0, rgb(0.11, 0.13, 0.15));
    roundedStroke(valueRect, 5.0, rgb(0.22, 0.27, 0.31), 1.0);
    const std::string v = harmonyplugin::valueText(*spec, [self normFor:pid]);
    text(ns(v), NSInsetRect(valueRect, 7, 7), 10, rgb(0.78, 0.84, 0.89), NSTextAlignmentCenter, true);
    [self addHit:valueRect id:pid numeric:NO];
}

- (void)drawKnob:(std::uint32_t)pid label:(NSString*)label rect:(NSRect)r {
    const auto* spec = harmonyplugin::findSpec(pid);
    if (!spec) return;
    const double norm = [self normFor:pid];
    text(label, NSMakeRect(r.origin.x, r.origin.y, r.size.width, 13), 8.5, rgb(0.48, 0.55, 0.61), NSTextAlignmentCenter, false);

    const CGFloat cx = NSMidX(r);
    const CGFloat cy = r.origin.y + 38.0;
    const CGFloat radius = std::min<CGFloat>(20.0, r.size.width * 0.31);
    NSRect circle = NSMakeRect(cx - radius, cy - radius, radius * 2.0, radius * 2.0);
    roundedFill(circle, radius, rgb(0.105, 0.12, 0.135));
    roundedStroke(circle, radius, rgb(0.28, 0.33, 0.37), 1.0);

    NSBezierPath* track = [NSBezierPath bezierPath];
    [track appendBezierPathWithArcWithCenter:NSMakePoint(cx, cy) radius:radius + 4.0 startAngle:225 endAngle:-45 clockwise:YES];
    [track setLineWidth:2.5];
    [rgb(0.18, 0.22, 0.25) setStroke];
    [track stroke];

    const CGFloat angle = 225.0 - static_cast<CGFloat>(270.0 * harmonyplugin::clamp01(norm));
    const CGFloat radians = angle * static_cast<CGFloat>(M_PI / 180.0);
    NSPoint p1 = NSMakePoint(cx + std::cos(radians) * 5.0, cy - std::sin(radians) * 5.0);
    NSPoint p2 = NSMakePoint(cx + std::cos(radians) * (radius - 3.0), cy - std::sin(radians) * (radius - 3.0));
    NSBezierPath* needle = [NSBezierPath bezierPath];
    [needle moveToPoint:p1];
    [needle lineToPoint:p2];
    [needle setLineWidth:2.0];
    [rgb(0.18, 0.69, 0.93) setStroke];
    [needle stroke];

    NSRect valueRect = NSMakeRect(r.origin.x + 2, r.origin.y + r.size.height - 18, r.size.width - 4, 17);
    roundedFill(valueRect, 3.0, rgb(0.075, 0.088, 0.10));
    const std::string v = harmonyplugin::valueText(*spec, norm);
    text(ns(v), NSInsetRect(valueRect, 2, 2), 8.5, rgb(0.72, 0.80, 0.86), NSTextAlignmentCenter, false);

    NSRect dragRect = NSMakeRect(r.origin.x, r.origin.y + 14, r.size.width, r.size.height - 33);
    [self addHit:dragRect id:pid numeric:NO];
    [self addHit:valueRect id:pid numeric:YES];
}

- (void)drawSmallControl:(std::uint32_t)pid label:(NSString*)label rect:(NSRect)r {
    const auto* spec = harmonyplugin::findSpec(pid);
    if (!spec) return;
    if (spec->kind == ParamKind::Toggle) {
        [self drawToggle:pid label:label rect:NSMakeRect(r.origin.x, r.origin.y + 18, r.size.width, 27)];
        text(label, NSMakeRect(r.origin.x, r.origin.y, r.size.width, 13), 8, rgb(0.48, 0.55, 0.61), NSTextAlignmentCenter, false);
        return;
    }
    if (spec->kind == ParamKind::Choice) {
        [self drawChoice:pid label:label rect:r];
        return;
    }
    [self drawKnob:pid label:label rect:NSMakeRect(r.origin.x, r.origin.y, r.size.width, 70)];
}

- (void)drawMeter:(std::uint32_t)pid holdIndex:(int)holdIndex label:(NSString*)label rect:(NSRect)r {
    const float linear = static_cast<float>([self normFor:pid]);
    const float db = linearToDb(linear);
    const CGFloat n = meterNormForDb(db);
    NSRect track = NSMakeRect(r.origin.x + 8, r.origin.y + 18, r.size.width - 16, r.size.height - 38);
    roundedFill(track, 3.0, rgb(0.055, 0.065, 0.073));

    NSRect bar = track;
    bar.origin.y = track.origin.y + track.size.height * (1.0 - n);
    bar.size.height = track.size.height * n;
    if (bar.size.height > 0.5) {
        NSGradient* g = [[NSGradient alloc] initWithColors:@[rgb(0.18,0.72,0.37), rgb(0.90,0.74,0.20), rgb(0.88,0.22,0.18)]];
        [g drawInRect:bar angle:90.0];
#if !__has_feature(objc_arc)
        [g release];
#endif
    }

    const float holdDb = _peakHoldDb[static_cast<std::size_t>(std::clamp(holdIndex, 0, 6))];
    const CGFloat hn = meterNormForDb(holdDb);
    const CGFloat hy = track.origin.y + track.size.height * (1.0 - hn);
    [rgb(0.85, 0.91, 0.96) setFill];
    NSRectFill(NSMakeRect(track.origin.x, hy, track.size.width, 1.0));

    text(label, NSMakeRect(r.origin.x, r.origin.y, r.size.width, 14), 8, rgb(0.55,0.62,0.68), NSTextAlignmentCenter, true);
    char dbText[32]{};
    std::snprintf(dbText, sizeof(dbText), db <= -59.9f ? "-inf" : "%.1f", db);
    text([NSString stringWithUTF8String:dbText], NSMakeRect(r.origin.x, NSMaxY(r)-17, r.size.width, 15), 8, rgb(0.64,0.71,0.77), NSTextAlignmentCenter, false);
}

- (void)drawMeterPanel {
    NSRect panel = NSMakeRect(935, 178, 225, 552);
    [self drawPanel:panel title:@"REAL-TIME METERS"];

    const CGFloat meterY = 215;
    const CGFloat meterH = 250;
    [self drawMeter:kMeterInput holdIndex:0 label:@"IN" rect:NSMakeRect(948, meterY, 28, meterH)];
    [self drawMeter:kMeterOutputL holdIndex:1 label:@"L" rect:NSMakeRect(981, meterY, 28, meterH)];
    [self drawMeter:kMeterOutputR holdIndex:2 label:@"R" rect:NSMakeRect(1014, meterY, 28, meterH)];
    [self drawMeter:kMeterVoice1 holdIndex:3 label:@"V1" rect:NSMakeRect(1055, meterY, 22, meterH)];
    [self drawMeter:kMeterVoice2 holdIndex:4 label:@"V2" rect:NSMakeRect(1080, meterY, 22, meterH)];
    [self drawMeter:kMeterVoice3 holdIndex:5 label:@"V3" rect:NSMakeRect(1105, meterY, 22, meterH)];
    [self drawMeter:kMeterVoice4 holdIndex:6 label:@"V4" rect:NSMakeRect(1130, meterY, 22, meterH)];

    for (int d = 0; d <= 5; ++d) {
        const int db = -d * 12;
        const CGFloat y = meterY + 18 + (meterH - 38) * (static_cast<CGFloat>(d) / 5.0);
        text([NSString stringWithFormat:@"%d", db], NSMakeRect(940, y - 6, 22, 12), 7, rgb(0.40,0.46,0.51), NSTextAlignmentLeft, false);
    }

    const double pitch = [self plainFor:kMeterPitchMidi];
    const double pconf = [self plainFor:kMeterPitchConfidence];
    const int key = static_cast<int>(std::lround([self plainFor:kMeterDetectedKey]));
    const int scale = static_cast<int>(std::lround([self plainFor:kMeterDetectedScale]));
    const double kconf = [self plainFor:kMeterKeyConfidence];
    const auto* keySpec = harmonyplugin::findSpec(kMeterDetectedKey);
    const auto* scaleSpec = harmonyplugin::findSpec(kMeterDetectedScale);
    std::string keyText = keySpec ? harmonyplugin::valueText(*keySpec, [self normFor:kMeterDetectedKey]) : "--";
    std::string scaleText = scaleSpec ? harmonyplugin::valueText(*scaleSpec, [self normFor:kMeterDetectedScale]) : "--";
    (void)key; (void)scale;

    text(@"DETECTOR", NSMakeRect(950, 486, 190, 16), 10, rgb(0.44,0.70,0.86), NSTextAlignmentLeft, true);
    const int midi = static_cast<int>(std::lround(pitch));
    text([NSString stringWithFormat:@"Pitch   %s   %.1f%%", midiName(midi).c_str(), pconf], NSMakeRect(950, 510, 190, 18), 10, rgb(0.78,0.84,0.89), NSTextAlignmentLeft, false);
    text([NSString stringWithFormat:@"Key     %s / %s", keyText.c_str(), scaleText.c_str()], NSMakeRect(950, 532, 190, 18), 10, rgb(0.78,0.84,0.89), NSTextAlignmentLeft, false);
    text([NSString stringWithFormat:@"Conf.   %.1f%%", kconf], NSMakeRect(950, 554, 190, 18), 10, rgb(0.62,0.70,0.76), NSTextAlignmentLeft, false);

    text(@"VOICE TARGETS", NSMakeRect(950, 590, 190, 16), 10, rgb(0.44,0.70,0.86), NSTextAlignmentLeft, true);
    const std::uint32_t tids[4] = {kMeterTarget1,kMeterTarget2,kMeterTarget3,kMeterTarget4};
    for (int i = 0; i < 4; ++i) {
        const int note = static_cast<int>(std::lround([self plainFor:tids[i]]));
        text([NSString stringWithFormat:@"V%d   %s", i+1, midiName(note).c_str()], NSMakeRect(950, 612 + i*21, 190, 18), 10, rgb(0.72,0.79,0.85), NSTextAlignmentLeft, false);
    }
}

- (void)drawHeader {
    [rgb(0.045, 0.052, 0.060) setFill];
    NSRectFill(self.bounds);
    [rgb(0.075,0.087,0.098) setFill];
    NSRectFill(NSMakeRect(0, 0, kEditorWidth, 64));
    text(@"HARMONY ENGINE", NSMakeRect(20, 11, 330, 28), 22, rgb(0.86,0.91,0.95), NSTextAlignmentLeft, true);
    text(@"VOCAL HARMONY PROCESSOR  •  NATIVE VST3  •  NO JUCE", NSMakeRect(22, 39, 430, 16), 9, rgb(0.38,0.66,0.84), NSTextAlignmentLeft, true);

    NSRect mainTab = NSMakeRect(486, 16, 90, 32);
    NSRect advTab = NSMakeRect(581, 16, 100, 32);
    roundedFill(mainTab, 6, _advanced ? rgb(0.105,0.12,0.135) : rgb(0.08,0.45,0.67));
    roundedFill(advTab, 6, _advanced ? rgb(0.08,0.45,0.67) : rgb(0.105,0.12,0.135));
    text(@"MAIN", NSInsetRect(mainTab, 4, 8), 10, NSColor.whiteColor, NSTextAlignmentCenter, true);
    text(@"ADVANCED", NSInsetRect(advTab, 4, 8), 10, NSColor.whiteColor, NSTextAlignmentCenter, true);
    [self addHit:mainTab id:kTabMain numeric:NO];
    [self addHit:advTab id:kTabAdvanced numeric:NO];

    [self drawToggle:kBypass label:@"BYPASS" rect:NSMakeRect(1060, 17, 96, 30)];
    text(@"Double-click = default   •   click value / Option-click = numeric entry", NSMakeRect(700, 23, 340, 18), 8, rgb(0.42,0.48,0.53), NSTextAlignmentRight, false);
}

- (void)drawTopStrip {
    NSRect p = NSMakeRect(20, 78, 1140, 86);
    [self drawPanel:p title:nil];
    [self drawChoice:kMode label:@"HARMONY MODE" rect:NSMakeRect(35, 96, 160, 48)];
    [self drawChoice:kKey label:@"KEY" rect:NSMakeRect(210, 96, 90, 48)];
    [self drawChoice:kScale label:@"SCALE" rect:NSMakeRect(315, 96, 150, 48)];
    [self drawKnob:kInputDb label:@"INPUT" rect:NSMakeRect(490, 88, 72, 68)];
    [self drawKnob:kWetDb label:@"HARMONY" rect:NSMakeRect(575, 88, 72, 68)];
    [self drawKnob:kOutputDb label:@"OUTPUT" rect:NSMakeRect(660, 88, 72, 68)];

    const int pitch = static_cast<int>(std::lround([self plainFor:kMeterPitchMidi]));
    const double conf = [self plainFor:kMeterPitchConfidence];
    roundedFill(NSMakeRect(760, 96, 156, 48), 6, rgb(0.075,0.088,0.10));
    text(@"LIVE PITCH", NSMakeRect(772, 102, 132, 14), 8, rgb(0.42,0.67,0.84), NSTextAlignmentLeft, true);
    text([NSString stringWithFormat:@"%s   %.0f%%", midiName(pitch).c_str(), conf], NSMakeRect(772, 120, 132, 18), 12, rgb(0.82,0.88,0.93), NSTextAlignmentLeft, true);
}

- (void)drawMainPage {
    for (int v = 0; v < 4; ++v) {
        const CGFloat y = 180 + v * 111;
        NSRect panel = NSMakeRect(20, y, 900, 100);
        [self drawPanel:panel title:[NSString stringWithFormat:@"VOICE %d", v + 1]];
        const CGFloat bx = 34;
        [self drawToggle:voiceParamId(v, kVoiceEnable) label:@"ON" rect:NSMakeRect(bx, y + 34, 44, 25)];
        [self drawToggle:voiceParamId(v, kVoiceMute) label:@"M" rect:NSMakeRect(bx + 50, y + 34, 34, 25)];
        [self drawToggle:voiceParamId(v, kVoiceSolo) label:@"S" rect:NSMakeRect(bx + 90, y + 34, 34, 25)];

        const CGFloat start = 170;
        const CGFloat step = 96;
        [self drawKnob:voiceParamId(v, kVoiceInterval) label:@"INTERVAL" rect:NSMakeRect(start + step*0, y + 18, 78, 72)];
        [self drawKnob:voiceParamId(v, kVoiceLevel) label:@"LEVEL" rect:NSMakeRect(start + step*1, y + 18, 78, 72)];
        [self drawKnob:voiceParamId(v, kVoicePan) label:@"PAN" rect:NSMakeRect(start + step*2, y + 18, 78, 72)];
        [self drawKnob:voiceParamId(v, kVoiceFormant) label:@"FORMANT" rect:NSMakeRect(start + step*3, y + 18, 78, 72)];
        [self drawKnob:voiceParamId(v, kVoiceHumanizeCents) label:@"PITCH HUMAN" rect:NSMakeRect(start + step*4, y + 18, 78, 72)];
        [self drawKnob:voiceParamId(v, kVoiceDelayMs) label:@"TIMING" rect:NSMakeRect(start + step*5, y + 18, 78, 72)];

        const int target = static_cast<int>(std::lround([self plainFor:kMeterTarget1 + v]));
        roundedFill(NSMakeRect(785, y + 32, 116, 43), 6, rgb(0.065,0.078,0.09));
        text(@"TARGET", NSMakeRect(795, y + 36, 96, 12), 8, rgb(0.42,0.59,0.70), NSTextAlignmentCenter, true);
        text(ns(midiName(target)), NSMakeRect(795, y + 51, 96, 18), 12, rgb(0.75,0.86,0.93), NSTextAlignmentCenter, true);
    }

    NSRect global = NSMakeRect(20, 629, 900, 101);
    [self drawPanel:global title:@"GLOBAL VOICE CONTROL"];
    const CGFloat x = 42;
    const CGFloat step = 118;
    [self drawKnob:kTightness label:@"TIGHTNESS" rect:NSMakeRect(x + step*0, 647, 82, 72)];
    [self drawKnob:kSmoothingMs label:@"PITCH GLIDE" rect:NSMakeRect(x + step*1, 647, 82, 72)];
    [self drawKnob:kHumanize label:@"HUMANIZE" rect:NSMakeRect(x + step*2, 647, 82, 72)];
    [self drawKnob:kFormantPreserve label:@"FORMANT" rect:NSMakeRect(x + step*3, 647, 82, 72)];
    [self drawKnob:kTransientProtect label:@"TRANSIENT" rect:NSMakeRect(x + step*4, 647, 82, 72)];
    [self drawKnob:kUnvoicedPreserve label:@"CONSONANT" rect:NSMakeRect(x + step*5, 647, 82, 72)];
    [self drawKnob:kDryDb label:@"DRY" rect:NSMakeRect(x + step*6, 647, 82, 72)];

    [self drawMeterPanel];
}

- (void)drawAdvancedPage {
    NSRect globals = NSMakeRect(20, 180, 1140, 108);
    [self drawPanel:globals title:@"MODE / GLOBAL DETAIL"];
    [self drawChoice:kChordRoot label:@"CHORD ROOT" rect:NSMakeRect(35, 210, 105, 48)];
    [self drawChoice:kChordType label:@"CHORD TYPE" rect:NSMakeRect(150, 210, 135, 48)];
    [self drawChoice:kMidiChannel label:@"MIDI CH" rect:NSMakeRect(295, 210, 90, 48)];
    [self drawToggle:kMidiHold label:@"HOLD" rect:NSMakeRect(397, 226, 60, 28)];
    [self drawKnob:kAutoKeyThreshold label:@"AUTO KEY" rect:NSMakeRect(475, 200, 74, 72)];
    [self drawKnob:kTuningHz label:@"A4 TUNING" rect:NSMakeRect(560, 200, 74, 72)];
    [self drawKnob:kHarmonyWidth label:@"WIDTH" rect:NSMakeRect(645, 200, 74, 72)];
    [self drawKnob:kDryDb label:@"DRY" rect:NSMakeRect(730, 200, 74, 72)];
    [self drawKnob:kWetDb label:@"HARMONY" rect:NSMakeRect(815, 200, 74, 72)];
    [self drawKnob:kInputDb label:@"INPUT" rect:NSMakeRect(900, 200, 74, 72)];
    [self drawKnob:kOutputDb label:@"OUTPUT" rect:NSMakeRect(985, 200, 74, 72)];
    [self drawKnob:kSmoothingMs label:@"GLIDE" rect:NSMakeRect(1070, 200, 74, 72)];

    const CGFloat panelY = 303;
    const CGFloat panelW = 277;
    for (int v = 0; v < 4; ++v) {
        const CGFloat px = 20 + v * 287;
        NSRect panel = NSMakeRect(px, panelY, panelW, 427);
        [self drawPanel:panel title:[NSString stringWithFormat:@"VOICE %d ADVANCED", v + 1]];

        [self drawToggle:voiceParamId(v,kVoiceEnable) label:@"ON" rect:NSMakeRect(px+14, panelY+32, 46, 25)];
        [self drawToggle:voiceParamId(v,kVoiceMute) label:@"M" rect:NSMakeRect(px+65, panelY+32, 34, 25)];
        [self drawToggle:voiceParamId(v,kVoiceSolo) label:@"S" rect:NSMakeRect(px+104, panelY+32, 34, 25)];
        [self drawChoice:voiceParamId(v,kVoiceMode) label:@"VOICE MODE" rect:NSMakeRect(px+148, panelY+20, 114, 48)];

        const CGFloat col[3] = {px+16, px+101, px+186};
        const CGFloat row[4] = {panelY+86, panelY+166, panelY+246, panelY+326};
        [self drawSmallControl:voiceParamId(v,kVoiceOctave) label:@"OCTAVE" rect:NSMakeRect(col[0],row[0],72,70)];
        [self drawSmallControl:voiceParamId(v,kVoiceDetune) label:@"DETUNE" rect:NSMakeRect(col[1],row[0],72,70)];
        [self drawSmallControl:voiceParamId(v,kVoiceDelayMs) label:@"TIMING" rect:NSMakeRect(col[2],row[0],72,70)];

        [self drawSmallControl:voiceParamId(v,kVoiceVibratoCents) label:@"VIB DEPTH" rect:NSMakeRect(col[0],row[1],72,70)];
        [self drawSmallControl:voiceParamId(v,kVoiceVibratoRate) label:@"VIB RATE" rect:NSMakeRect(col[1],row[1],72,70)];
        [self drawSmallControl:voiceParamId(v,kVoiceChoirVoices) label:@"CHOIR" rect:NSMakeRect(col[2],row[1],72,54)];

        [self drawSmallControl:voiceParamId(v,kVoiceChoirSpread) label:@"SPREAD" rect:NSMakeRect(col[0],row[2],72,70)];
        [self drawSmallControl:voiceParamId(v,kVoiceChoirDepth) label:@"DEPTH" rect:NSMakeRect(col[1],row[2],72,70)];
        [self drawSmallControl:voiceParamId(v,kVoiceHumanizeCents) label:@"PITCH HUMAN" rect:NSMakeRect(col[2],row[2],72,70)];

        [self drawSmallControl:voiceParamId(v,kVoiceMinMidi) label:@"LOW MIDI" rect:NSMakeRect(col[0],row[3],72,70)];
        [self drawSmallControl:voiceParamId(v,kVoiceMaxMidi) label:@"HIGH MIDI" rect:NSMakeRect(col[1],row[3],72,70)];
        [self drawSmallControl:voiceParamId(v,kVoiceFormant) label:@"FORMANT" rect:NSMakeRect(col[2],row[3],72,70)];
    }
}

- (void)drawRect:(NSRect)dirtyRect {
    (void)dirtyRect;
    _hits.clear();
    [self drawHeader];
    [self drawTopStrip];
    if (_advanced) [self drawAdvancedPage];
    else [self drawMainPage];
}

- (HitItem*)hitAt:(NSPoint)p {
    for (auto it = _hits.rbegin(); it != _hits.rend(); ++it) {
        if (NSPointInRect(p, it->rect)) return &(*it);
    }
    return nullptr;
}

- (void)beginNumericFor:(std::uint32_t)pid rect:(NSRect)r {
    const auto* spec = harmonyplugin::findSpec(pid);
    if (!spec || spec->readOnly) return;
    [_numberEditor removeFromSuperview];
    _numberEditor = [[NSTextField alloc] initWithFrame:NSInsetRect(r, -3, -2)];
    _numberId = pid;
    _numberEditor.delegate = self;
    _numberEditor.font = [NSFont systemFontOfSize:11];
    _numberEditor.alignment = NSTextAlignmentCenter;
    _numberEditor.stringValue = [NSString stringWithFormat:@"%.4g", [self plainFor:pid]];
    [self addSubview:_numberEditor];
    [self.window makeFirstResponder:_numberEditor];
    [_numberEditor selectText:nil];
#if !__has_feature(objc_arc)
    [_numberEditor release];
#endif
}

- (void)controlTextDidEndEditing:(NSNotification*)obj {
    (void)obj;
    if (!_numberEditor || _numberId == 0) return;
    const auto* spec = harmonyplugin::findSpec(_numberId);
    if (spec) {
        const double plain = _numberEditor.doubleValue;
        [self setParam:_numberId norm:harmonyplugin::normalizePlain(*spec, plain) begin:YES end:YES];
    }
    [_numberEditor removeFromSuperview];
    _numberEditor = nil;
    _numberId = 0;
    [self.window makeFirstResponder:self];
}

- (void)mouseDown:(NSEvent*)event {
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    HitItem* h = [self hitAt:p];
    if (!h) return;

    if (h->id == kTabMain) { _advanced = NO; [self setNeedsDisplay:YES]; return; }
    if (h->id == kTabAdvanced) { _advanced = YES; [self setNeedsDisplay:YES]; return; }

    const auto* spec = harmonyplugin::findSpec(h->id);
    if (!spec || spec->readOnly) return;

    if (event.clickCount >= 2) { [self resetParam:h->id]; return; }
    if (h->numeric || (event.modifierFlags & NSEventModifierFlagOption)) {
        [self beginNumericFor:h->id rect:h->rect];
        return;
    }

    if (spec->kind == ParamKind::Toggle) {
        const double next = [self plainFor:h->id] >= 0.5 ? 0.0 : 1.0;
        [self setParam:h->id norm:harmonyplugin::normalizePlain(*spec, next) begin:YES end:YES];
        return;
    }
    if (spec->kind == ParamKind::Choice) {
        int idx = static_cast<int>(std::lround([self plainFor:h->id]));
        idx = (idx + 1) % std::max(1, spec->choiceCount);
        [self setParam:h->id norm:harmonyplugin::normalizePlain(*spec, idx) begin:YES end:YES];
        return;
    }

    _dragging = YES;
    _dragId = h->id;
    _dragStartNorm = [self normFor:h->id];
    _dragStartY = p.y;
    if (_controller) _controller->beginEdit(static_cast<ParamID>(_dragId));
}

- (void)mouseDragged:(NSEvent*)event {
    if (!_dragging || _dragId == 0) return;
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    double sensitivity = (event.modifierFlags & NSEventModifierFlagShift) ? 600.0 : 180.0;
    const double norm = harmonyplugin::clamp01(_dragStartNorm + (_dragStartY - p.y) / sensitivity);
    if (_controller) {
        _controller->setParamNormalized(static_cast<ParamID>(_dragId), norm);
        _controller->performEdit(static_cast<ParamID>(_dragId), norm);
    }
    [self setNeedsDisplay:YES];
}

- (void)mouseUp:(NSEvent*)event {
    (void)event;
    if (_dragging && _dragId != 0 && _controller)
        _controller->endEdit(static_cast<ParamID>(_dragId));
    _dragging = NO;
    _dragId = 0;
}

@end

namespace harmonyplugin {

class HarmonyEditorView final : public CPluginView {
public:
    explicit HarmonyEditorView(HarmonyController* controller)
        : CPluginView(&initialRect()), controller_(controller) {
        if (controller_) controller_->addRef();
    }

    ~HarmonyEditorView() override {
        if (nativeView_) {
            [nativeView_ removeFromSuperview];
#if !__has_feature(objc_arc)
            [nativeView_ release];
#endif
            nativeView_ = nil;
        }
        if (controller_) controller_->release();
    }

    tresult PLUGIN_API isPlatformTypeSupported(FIDString type) SMTG_OVERRIDE {
        return type && std::strcmp(type, kPlatformTypeNSView) == 0 ? kResultTrue : kResultFalse;
    }

    tresult PLUGIN_API attached(void* parent, FIDString type) SMTG_OVERRIDE {
        if (!parent || isPlatformTypeSupported(type) != kResultTrue || nativeView_) return kResultFalse;
        systemWindow = parent;
        NSView* parentView = (__bridge NSView*)parent;
        nativeView_ = [[HarmonyNativeView alloc] initWithFrame:NSMakeRect(0, 0, kEditorWidth, kEditorHeight) controller:controller_];
        [parentView addSubview:nativeView_];
        return kResultOk;
    }

    tresult PLUGIN_API removed() SMTG_OVERRIDE {
        if (nativeView_) {
            [nativeView_ removeFromSuperview];
#if !__has_feature(objc_arc)
            [nativeView_ release];
#endif
            nativeView_ = nil;
        }
        systemWindow = nullptr;
        return kResultOk;
    }

    tresult PLUGIN_API onSize(ViewRect* newSize) SMTG_OVERRIDE {
        if (!newSize) return kInvalidArgument;
        rect = *newSize;
        if (nativeView_) [nativeView_ setFrame:NSMakeRect(0, 0, rect.getWidth(), rect.getHeight())];
        return kResultTrue;
    }

    tresult PLUGIN_API canResize() SMTG_OVERRIDE { return kResultFalse; }

private:
    static ViewRect& initialRect() {
        static ViewRect r(0, 0, static_cast<int32>(kEditorWidth), static_cast<int32>(kEditorHeight));
        return r;
    }

    HarmonyController* controller_ = nullptr;
    HarmonyNativeView* nativeView_ = nil;
};

IPlugView* createHarmonyEditor(HarmonyController* controller) {
    return new HarmonyEditorView(controller);
}

} // namespace harmonyplugin
