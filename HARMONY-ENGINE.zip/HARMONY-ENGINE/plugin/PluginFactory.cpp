#include "HarmonyController.h"
#include "HarmonyProcessorVST3.h"
#include "PluginIDs.h"

#include "public.sdk/source/main/pluginfactory_constexpr.h"

#define stringCompanyName "Tercior Audio"
#define stringCompanyWeb  "https://github.com/gurkov1993cg-debug/HARMONY-ENGINE"
#define stringCompanyEmail ""
#define stringPluginName  "Harmony Engine"
#define stringPluginVersion "0.8.0"

BEGIN_FACTORY_DEF(stringCompanyName, stringCompanyWeb, stringCompanyEmail, 2)

DEF_CLASS(harmonyplugin::kProcessorUID,
          Steinberg::PClassInfo::kManyInstances,
          kVstAudioEffectClass,
          stringPluginName,
          Steinberg::Vst::kDistributable,
          "Fx",
          stringPluginVersion,
          kVstVersionString,
          harmonyplugin::HarmonyProcessorVST3::createInstance,
          nullptr)

DEF_CLASS(harmonyplugin::kControllerUID,
          Steinberg::PClassInfo::kManyInstances,
          kVstComponentControllerClass,
          stringPluginName " Controller",
          0,
          "",
          stringPluginVersion,
          kVstVersionString,
          harmonyplugin::HarmonyController::createInstance,
          nullptr)

END_FACTORY
