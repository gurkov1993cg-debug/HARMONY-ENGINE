#include "HarmonyController.h"
#include "HarmonyProcessorVST3.h"
#include "PluginIDs.h"

#include "public.sdk/source/main/pluginfactory.h"

using namespace Steinberg;
using namespace Steinberg::Vst;
using namespace harmonyplugin;

BEGIN_FACTORY_DEF(kVendorName, kVendorURL, kVendorEmail)

DEF_CLASS2(INLINE_UID_FROM_FUID(kProcessorUID),
           PClassInfo::kManyInstances,
           kVstAudioEffectClass,
           kPluginName,
           Vst::kDistributable,
           kVst3Category,
           kPluginVersion,
           kVstVersionString,
           HarmonyProcessorVST3::createInstance)

DEF_CLASS2(INLINE_UID_FROM_FUID(kControllerUID),
           PClassInfo::kManyInstances,
           kVstComponentControllerClass,
           "Harmony Engine Controller",
           0,
           "",
           kPluginVersion,
           kVstVersionString,
           HarmonyController::createInstance)

END_FACTORY
