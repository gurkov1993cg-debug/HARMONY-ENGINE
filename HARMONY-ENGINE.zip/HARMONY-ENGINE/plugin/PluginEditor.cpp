#include "PluginEditor.h"
#include "Parameters.h"
#include <cmath>

namespace {
const juce::Colour kBg(0xff0f141a);
const juce::Colour kPanel(0xff171e27);
const juce::Colour kPanel2(0xff202a35);
const juce::Colour kPanel3(0xff10161d);
const juce::Colour kText(0xffdce7f2);
const juce::Colour kMuted(0xff7f91a3);
const juce::Colour kBlue(0xff4aa6ff);
const juce::Colour kBlueBright(0xff78beff);
const juce::Colour kBlueDim(0xff285f91);
const juce::Colour kRed(0xffe05362);
const juce::Colour kYellow(0xffffc84a);

juce::String midiName(int note) {
    if (note < 0 || note > 127) return "--";
    static const char* names[] = {"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};
    return juce::String(names[note % 12]) + juce::String(note / 12 - 1);
}

void styleLabel(juce::Label& l, float size = 11.0f, juce::Justification j = juce::Justification::centred) {
    l.setColour(juce::Label::textColourId, kText);
    l.setFont(juce::Font(size));
    l.setJustificationType(j);
}

void styleCombo(juce::ComboBox& c) {
    c.setColour(juce::ComboBox::backgroundColourId, kPanel2);
    c.setColour(juce::ComboBox::textColourId, kText);
    c.setColour(juce::ComboBox::outlineColourId, kBlueDim);
    c.setColour(juce::ComboBox::arrowColourId, kBlue);
}

void styleTextButton(juce::TextButton& b, juce::Colour on = kBlueDim) {
    b.setColour(juce::TextButton::buttonColourId, kPanel2);
    b.setColour(juce::TextButton::buttonOnColourId, on);
    b.setColour(juce::TextButton::textColourOffId, kText);
    b.setColour(juce::TextButton::textColourOnId, juce::Colours::white);
}

void drawPanel(juce::Graphics& g, juce::Rectangle<float> r, const juce::String& title) {
    g.setColour(kPanel);
    g.fillRoundedRectangle(r, 6.0f);
    g.setColour(kBlueDim.withAlpha(0.72f));
    g.drawRoundedRectangle(r, 6.0f, 1.0f);
    g.setColour(kMuted);
    g.setFont(10.0f);
    g.drawText(title, r.getX() + 10.0f, r.getY() + 5.0f, r.getWidth() - 20.0f, 14.0f,
               juce::Justification::centredLeft);
}
}

HarmonyLookAndFeel::HarmonyLookAndFeel() {
    setColour(juce::Slider::textBoxTextColourId, kText);
    setColour(juce::Slider::textBoxBackgroundColourId, kPanel3);
    setColour(juce::Slider::textBoxOutlineColourId, kBlueDim);
    setColour(juce::TextButton::buttonColourId, kPanel2);
    setColour(juce::PopupMenu::backgroundColourId, kPanel2);
    setColour(juce::PopupMenu::textColourId, kText);
    setColour(juce::ComboBox::backgroundColourId, kPanel2);
    setColour(juce::ComboBox::textColourId, kText);
    setColour(juce::ComboBox::outlineColourId, kBlueDim);
    setColour(juce::ComboBox::arrowColourId, kBlue);
}

void HarmonyLookAndFeel::drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                                           float sliderPos, float rotaryStartAngle, float rotaryEndAngle,
                                           juce::Slider&) {
    const auto radius = juce::jmin(width, height) * 0.5f - 6.0f;
    const auto centreX = static_cast<float>(x + width / 2);
    const auto centreY = static_cast<float>(y + height / 2);
    const auto angle = rotaryStartAngle + sliderPos * (rotaryEndAngle - rotaryStartAngle);
    const juce::Rectangle<float> r(centreX - radius, centreY - radius, radius * 2.0f, radius * 2.0f);

    g.setColour(juce::Colour(0xff090d12));
    g.fillEllipse(r);
    g.setColour(juce::Colour(0xff354454));
    g.drawEllipse(r, 1.0f);

    juce::Path bgArc;
    bgArc.addCentredArc(centreX, centreY, radius - 2.0f, radius - 2.0f, 0.0f,
                        rotaryStartAngle, rotaryEndAngle, true);
    g.setColour(juce::Colour(0xff26323e));
    g.strokePath(bgArc, juce::PathStrokeType(2.4f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

    juce::Path arc;
    arc.addCentredArc(centreX, centreY, radius - 2.0f, radius - 2.0f, 0.0f,
                      rotaryStartAngle, angle, true);
    g.setColour(kBlue);
    g.strokePath(arc, juce::PathStrokeType(2.6f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

    juce::Path pointer;
    const float pointerLength = radius * 0.62f;
    pointer.addRoundedRectangle(-1.0f, -pointerLength, 2.0f, pointerLength, 1.0f);
    g.setColour(kText);
    g.fillPath(pointer, juce::AffineTransform::rotation(angle).translated(centreX, centreY));
}

void HarmonyLookAndFeel::drawToggleButton(juce::Graphics& g, juce::ToggleButton& b, bool, bool) {
    const auto area = b.getLocalBounds().toFloat();
    const float h = juce::jmin(20.0f, area.getHeight() - 4.0f);
    const float w = 36.0f;
    const juce::Rectangle<float> track(2.0f, (area.getHeight() - h) * 0.5f, w, h);
    g.setColour(b.getToggleState() ? kBlueDim : juce::Colour(0xff303944));
    g.fillRoundedRectangle(track, h * 0.5f);
    const float d = h - 4.0f;
    const float px = b.getToggleState() ? track.getRight() - d - 2.0f : track.getX() + 2.0f;
    g.setColour(b.getToggleState() ? kBlue : kMuted);
    g.fillEllipse(px, track.getY() + 2.0f, d, d);
    g.setColour(kText);
    g.setFont(11.0f);
    g.drawText(b.getButtonText(), 44, 0, juce::jmax(0, b.getWidth() - 44), b.getHeight(), juce::Justification::centredLeft);
}

void HarmonyLookAndFeel::drawButtonBackground(juce::Graphics& g, juce::Button& b, const juce::Colour&,
                                               bool highlighted, bool down) {
    auto r = b.getLocalBounds().toFloat().reduced(0.5f);
    juce::Colour base = b.getToggleState() ? b.findColour(juce::TextButton::buttonOnColourId)
                                           : b.findColour(juce::TextButton::buttonColourId);
    if (highlighted) base = base.brighter(0.10f);
    if (down) base = base.darker(0.10f);
    g.setColour(base);
    g.fillRoundedRectangle(r, 4.0f);
    g.setColour(b.getToggleState() ? kBlueBright.withAlpha(0.85f) : kBlueDim.withAlpha(0.65f));
    g.drawRoundedRectangle(r, 4.0f, 1.0f);
}

void HarmonyLevelMeter::setLevel(float linear) noexcept {
    level_ = juce::jlimit(0.0f, 4.0f, linear);
    if (level_ >= hold_) { hold_ = level_; holdTicks_ = 35; }
    else if (holdTicks_ > 0) --holdTicks_;
    else hold_ *= 0.985f;
    repaint();
}

void HarmonyLevelMeter::paint(juce::Graphics& g) {
    auto whole = getLocalBounds().toFloat().reduced(2.0f);
    auto scale = whole.removeFromRight(15.0f);
    auto bar = whole.reduced(2.0f, 1.0f);
    const float db = juce::Decibels::gainToDecibels(level_, -60.0f);
    const float holdDb = juce::Decibels::gainToDecibels(hold_, -60.0f);
    const auto norm = [](float d) { return juce::jlimit(0.0f, 1.0f, (d + 60.0f) / 60.0f); };
    const float fill = bar.getHeight() * norm(db);

    g.setColour(juce::Colour(0xff080b0f));
    g.fillRoundedRectangle(bar, 2.0f);
    juce::ColourGradient grad(juce::Colour(0xffe43f4f), bar.getX(), bar.getY(),
                              juce::Colour(0xff3ed477), bar.getX(), bar.getBottom(), false);
    grad.addColour(0.28, kYellow);
    g.setGradientFill(grad);
    g.fillRect(bar.withTop(bar.getBottom() - fill));

    const float holdY = bar.getBottom() - bar.getHeight() * norm(holdDb);
    g.setColour(juce::Colours::white.withAlpha(0.9f));
    g.fillRect(bar.getX(), holdY, bar.getWidth(), 1.0f);

    g.setFont(6.5f);
    for (const float tick : {-48.0f, -36.0f, -24.0f, -12.0f, -6.0f, 0.0f}) {
        const float y = bar.getBottom() - bar.getHeight() * norm(tick);
        g.setColour(kMuted.withAlpha(0.42f));
        g.drawHorizontalLine(static_cast<int>(std::lround(y)), bar.getX(), bar.getRight());
        g.setColour(kMuted);
        g.drawText(juce::String(static_cast<int>(tick)), scale.withY(y - 4.0f).withHeight(8.0f), juce::Justification::centred);
    }
}

void HarmonyVoicePanel::setupKnob(juce::Slider& s, const juce::String& name, double defaultValue) {
    s.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
    s.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 56, 16);
    s.setName(name);
    s.setDoubleClickReturnValue(true, defaultValue);
    s.setTooltip(name + " — double click restores default; value box accepts numeric entry");
}

void HarmonyVoicePanel::setupSmallSlider(juce::Slider& s, double defaultValue) {
    s.setSliderStyle(juce::Slider::LinearHorizontal);
    s.setTextBoxStyle(juce::Slider::TextBoxRight, false, 48, 18);
    s.setDoubleClickReturnValue(true, defaultValue);
}

void HarmonyVoicePanel::addLabeledKnob(juce::Slider& s, juce::Label& l, const juce::String& text) {
    addAndMakeVisible(s);
    l.setText(text, juce::dontSendNotification);
    styleLabel(l, 8.8f);
    addAndMakeVisible(l);
}

HarmonyVoicePanel::HarmonyVoicePanel(HarmonyEngineAudioProcessor& p, int voiceIndex)
    : processor_(p), voiceIndex_(voiceIndex) {
    enable_.setButtonText("VOICE " + juce::String(voiceIndex_ + 1));
    addAndMakeVisible(enable_);

    mute_.setClickingTogglesState(true);
    solo_.setClickingTogglesState(true);
    styleTextButton(mute_, juce::Colour(0xff8c4a52));
    styleTextButton(solo_, kBlueDim);
    mute_.setTooltip("Mute this harmony voice");
    solo_.setTooltip("Solo this harmony voice; multiple voices can be soloed together");
    addAndMakeVisible(mute_);
    addAndMakeVisible(solo_);

    mode_.addItemList(harmonyplugin::voiceModeNames(), 1);
    choirVoices_.addItemList(harmonyplugin::choirSizeNames(), 1);
    styleCombo(mode_);
    styleCombo(choirVoices_);
    addAndMakeVisible(mode_);
    addAndMakeVisible(choirVoices_);

    choirL_.setText("CHOIR", juce::dontSendNotification);
    styleLabel(choirL_, 9.0f, juce::Justification::centredLeft);
    addAndMakeVisible(choirL_);

    targetCaption_.setText("TARGET", juce::dontSendNotification);
    styleLabel(targetCaption_, 7.5f, juce::Justification::centredRight);
    targetCaption_.setColour(juce::Label::textColourId, kMuted);
    addAndMakeVisible(targetCaption_);

    styleLabel(targetLabel_, 12.0f, juce::Justification::centredRight);
    targetLabel_.setColour(juce::Label::textColourId, kBlue);
    addAndMakeVisible(targetLabel_);
    addAndMakeVisible(meter_);

    const std::array<double, 14> defaults {{
        voiceIndex_ == 0 ? 2.0 : voiceIndex_ == 1 ? -2.0 : voiceIndex_ == 2 ? 4.0 : 0.0,
        voiceIndex_ == 3 ? 1.0 : 0.0,
        voiceIndex_ == 0 ? -8.0 : voiceIndex_ == 1 ? -9.0 : voiceIndex_ == 2 ? -12.0 : -14.0,
        voiceIndex_ == 0 ? -28.0 : voiceIndex_ == 1 ? 28.0 : voiceIndex_ == 2 ? -58.0 : 58.0,
        0.0, 0.0, 3.0,
        voiceIndex_ == 0 ? 5.0 : voiceIndex_ == 1 ? 9.0 : voiceIndex_ == 2 ? 13.0 : 17.0,
        0.0, 5.2, 0.0, 0.0,
        36.0, 96.0
    }};

    std::array<juce::Slider*, 14> sliders {{
        &interval_, &octave_, &level_, &pan_, &formant_, &detune_, &humanize_, &timing_,
        &vibratoDepth_, &vibratoRate_, &choirSpread_, &choirDepth_, &lowRange_, &highRange_
    }};
    std::array<juce::Label*, 14> labels {{
        &intervalL_, &octaveL_, &levelL_, &panL_, &formantL_, &detuneL_, &humanizeL_, &timingL_,
        &vibratoDepthL_, &vibratoRateL_, &choirSpreadL_, &choirDepthL_, &lowRangeL_, &highRangeL_
    }};
    const std::array<juce::String, 14> names {{
        "INTERVAL", "OCTAVE", "LEVEL", "PAN", "FORMANT", "DETUNE", "PITCH HUMAN", "TIMING",
        "VIB DEPTH", "VIB RATE", "CHOIR WIDTH", "CHOIR DEPTH", "LOW RANGE", "HIGH RANGE"
    }};

    for (std::size_t i = 0; i < 12; ++i) {
        setupKnob(*sliders[i], names[i], defaults[i]);
        addLabeledKnob(*sliders[i], *labels[i], names[i]);
    }
    for (std::size_t i = 12; i < 14; ++i) {
        setupSmallSlider(*sliders[i], defaults[i]);
        sliders[i]->setTooltip(names[i] + " — numeric MIDI-note range");
        addLabeledKnob(*sliders[i], *labels[i], names[i]);
    }

    auto& state = processor_.apvts;
    enableA_ = std::make_unique<BA>(state, harmonyplugin::voiceId(voiceIndex_, "enable"), enable_);
    muteA_ = std::make_unique<BA>(state, harmonyplugin::voiceId(voiceIndex_, "mute"), mute_);
    soloA_ = std::make_unique<BA>(state, harmonyplugin::voiceId(voiceIndex_, "solo"), solo_);
    modeA_ = std::make_unique<CA>(state, harmonyplugin::voiceId(voiceIndex_, "mode"), mode_);
    choirA_ = std::make_unique<CA>(state, harmonyplugin::voiceId(voiceIndex_, "choirVoices"), choirVoices_);
    const std::array<juce::String, 14> ids {{
        "interval","octave","level","pan","formant","detune","humanizeCents","delayMs",
        "vibratoCents","vibratoRate","choirSpread","choirDepth","minMidi","maxMidi"
    }};
    for (std::size_t i = 0; i < ids.size(); ++i)
        sliderA_[i] = std::make_unique<SA>(state, harmonyplugin::voiceId(voiceIndex_, ids[i]), *sliders[i]);

    setAdvanced(false);
}

void HarmonyVoicePanel::setAdvanced(bool advanced) {
    advanced_ = advanced;

    // MAIN keeps the controls used constantly while tracking. ADVANCED exposes
    // every additional DSP parameter; nothing is decorative or disconnected.
    std::array<juce::Component*, 16> advancedOnly {{
        &choirVoices_, &choirL_,
        &detune_, &detuneL_, &timing_, &timingL_,
        &vibratoDepth_, &vibratoDepthL_, &vibratoRate_, &vibratoRateL_,
        &choirSpread_, &choirSpreadL_, &choirDepth_, &choirDepthL_,
        &lowRange_, &lowRangeL_
    }};
    for (auto* component : advancedOnly) component->setVisible(advanced_);
    highRange_.setVisible(advanced_);
    highRangeL_.setVisible(advanced_);
    resized();
    repaint();
}

void HarmonyVoicePanel::paint(juce::Graphics& g) {
    auto r = getLocalBounds().toFloat().reduced(2.0f);
    g.setColour(kPanel);
    g.fillRoundedRectangle(r, 6.0f);
    g.setColour(kBlueDim.withAlpha(0.74f));
    g.drawRoundedRectangle(r, 6.0f, 1.0f);
}

void HarmonyVoicePanel::resized() {
    auto a = getLocalBounds().reduced(9);
    auto header = a.removeFromTop(31);
    enable_.setBounds(header.removeFromLeft(94));
    header.removeFromLeft(2);
    mute_.setBounds(header.removeFromLeft(29).reduced(1, 3));
    solo_.setBounds(header.removeFromLeft(29).reduced(1, 3));
    targetLabel_.setBounds(header.removeFromRight(48));
    targetCaption_.setBounds(header.removeFromRight(40));
    meter_.setBounds(header.removeFromRight(29).reduced(1, 0));
    a.removeFromTop(3);

    mode_.setBounds(a.removeFromTop(24));
    a.removeFromTop(5);

    if (!advanced_) {
        std::array<juce::Slider*, 6> sliders {{
            &interval_, &octave_, &level_, &pan_, &formant_, &humanize_
        }};
        std::array<juce::Label*, 6> labels {{
            &intervalL_, &octaveL_, &levelL_, &panL_, &formantL_, &humanizeL_
        }};

        for (int rowIndex = 0; rowIndex < 3; ++rowIndex) {
            auto row = a.removeFromTop(91);
            const int cellWidth = row.getWidth() / 2;
            for (int column = 0; column < 2; ++column) {
                const std::size_t idx = static_cast<std::size_t>(rowIndex * 2 + column);
                auto cell = row.removeFromLeft(cellWidth).reduced(3, 0);
                labels[idx]->setBounds(cell.removeFromTop(14));
                sliders[idx]->setBounds(cell);
            }
            a.removeFromTop(2);
        }
        return;
    }

    auto choirRow = a.removeFromTop(23);
    choirL_.setBounds(choirRow.removeFromLeft(42));
    choirVoices_.setBounds(choirRow.removeFromLeft(70));
    a.removeFromTop(4);

    std::array<juce::Slider*, 12> sliders {{
        &interval_, &octave_, &level_, &pan_, &formant_, &detune_, &humanize_, &timing_,
        &vibratoDepth_, &vibratoRate_, &choirSpread_, &choirDepth_
    }};
    std::array<juce::Label*, 12> labels {{
        &intervalL_, &octaveL_, &levelL_, &panL_, &formantL_, &detuneL_, &humanizeL_, &timingL_,
        &vibratoDepthL_, &vibratoRateL_, &choirSpreadL_, &choirDepthL_
    }};

    for (int rowIndex = 0; rowIndex < 4; ++rowIndex) {
        auto row = a.removeFromTop(72);
        const int cellWidth = row.getWidth() / 3;
        for (int column = 0; column < 3; ++column) {
            auto cell = row.removeFromLeft(cellWidth).reduced(2, 0);
            const std::size_t idx = static_cast<std::size_t>(rowIndex * 3 + column);
            labels[idx]->setBounds(cell.removeFromTop(13));
            sliders[idx]->setBounds(cell);
        }
        a.removeFromTop(1);
    }

    auto low = a.removeFromTop(22);
    lowRangeL_.setBounds(low.removeFromLeft(64));
    lowRange_.setBounds(low);
    a.removeFromTop(2);
    auto high = a.removeFromTop(22);
    highRangeL_.setBounds(high.removeFromLeft(64));
    highRange_.setBounds(high);
}

void HarmonyVoicePanel::updateRealtime() {
    targetLabel_.setText(midiName(processor_.targetNote(voiceIndex_)), juce::dontSendNotification);
    meter_.setLevel(processor_.meterVoice(voiceIndex_));
}

void HarmonyEngineAudioProcessorEditor::setupKnob(juce::Slider& s, double defaultValue) {
    s.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
    s.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 61, 16);
    s.setDoubleClickReturnValue(true, defaultValue);
}

void HarmonyEngineAudioProcessorEditor::addGlobalKnob(juce::Slider& s, juce::Label& l,
                                                        const juce::String& name, double defaultValue) {
    setupKnob(s, defaultValue);
    s.setTooltip(name + " — double click restores default; value box accepts numeric entry");
    addAndMakeVisible(s);
    l.setText(name, juce::dontSendNotification);
    styleLabel(l, 9.2f);
    addAndMakeVisible(l);
}

HarmonyEngineAudioProcessorEditor::HarmonyEngineAudioProcessorEditor(HarmonyEngineAudioProcessor& p)
    : AudioProcessorEditor(&p), processor_(p) {
    setLookAndFeel(&lookAndFeel_);
    setSize(1280, 800);
    setResizable(false, false);

    bypass_.setButtonText("BYPASS");
    bypass_.setTooltip("Latency-compensated internal bypass");
    addAndMakeVisible(bypass_);

    advancedButton_.setClickingTogglesState(true);
    advancedButton_.setTooltip("Show every advanced DSP control. Main view stays intentionally light.");
    styleTextButton(advancedButton_);
    addAndMakeVisible(advancedButton_);
    advancedButton_.onClick = [this] { setAdvancedView(advancedButton_.getToggleState()); };

    for (auto* b : {&aButton_, &bButton_, &copyButton_, &resetButton_}) {
        styleTextButton(*b);
        addAndMakeVisible(*b);
    }
    aButton_.onClick = [this] { switchAB(true); };
    bButton_.onClick = [this] { switchAB(false); };
    copyButton_.onClick = [this] { copyAB(); };
    resetButton_.onClick = [this] { resetParameters(); };

    mode_.addItemList(harmonyplugin::harmonyModeNames(), 1);
    key_.addItemList(harmonyplugin::keyNames(), 1);
    scale_.addItemList(harmonyplugin::scaleNames(), 1);
    chordRoot_.addItemList(harmonyplugin::keyNames(), 1);
    chordType_.addItemList(harmonyplugin::chordTypeNames(), 1);
    midiChannel_.addItemList(harmonyplugin::midiChannelNames(), 1);
    for (auto* c : {&mode_, &key_, &scale_, &chordRoot_, &chordType_, &midiChannel_}) {
        styleCombo(*c);
        addAndMakeVisible(*c);
    }

    midiHold_.setButtonText("MIDI HOLD");
    midiHold_.setTooltip("Hold the last MIDI chord until the next chord begins");
    addAndMakeVisible(midiHold_);

    modeL_.setText("MODE", juce::dontSendNotification);
    keyL_.setText("KEY", juce::dontSendNotification);
    scaleL_.setText("SCALE", juce::dontSendNotification);
    chordRootL_.setText("CHORD", juce::dontSendNotification);
    chordTypeL_.setText("TYPE", juce::dontSendNotification);
    midiChannelL_.setText("MIDI CH", juce::dontSendNotification);
    for (auto* l : {&modeL_, &keyL_, &scaleL_, &chordRootL_, &chordTypeL_, &midiChannelL_}) {
        styleLabel(*l, 9.5f, juce::Justification::centredLeft);
        addAndMakeVisible(*l);
    }

    styleLabel(detectedPitch_, 12.0f, juce::Justification::centredLeft);
    styleLabel(detectedKey_, 12.0f, juce::Justification::centredLeft);
    detectedPitch_.setColour(juce::Label::textColourId, kBlueBright);
    detectedKey_.setColour(juce::Label::textColourId, kBlueBright);
    addAndMakeVisible(detectedPitch_);
    addAndMakeVisible(detectedKey_);

    const std::array<double, 13> defaults {{
        0.0, -3.0, -3.0, 0.0, 100.0, 440.0,
        18.0, 9.0, 35.0, 100.0, 85.0, 92.0, 12.0
    }};
    std::array<juce::Slider*, 13> sliders {{
        &input_, &dry_, &wet_, &output_, &harmonyWidth_, &tuningHz_,
        &tightness_, &smoothing_, &humanize_, &formantPreserve_, &transientProtect_, &consonantProtect_, &autoKeyThreshold_
    }};
    std::array<juce::Label*, 13> labels {{
        &inputL_, &dryL_, &wetL_, &outputL_, &harmonyWidthL_, &tuningHzL_,
        &tightnessL_, &smoothingL_, &humanizeL_, &formantPreserveL_, &transientProtectL_, &consonantProtectL_, &autoKeyThresholdL_
    }};
    const std::array<juce::String, 13> names {{
        "INPUT", "DRY", "HARMONY", "OUTPUT", "WIDTH", "A4 TUNING",
        "TIGHTNESS", "PITCH GLIDE", "HUMANIZE", "FORMANT", "TRANSIENT", "CONSONANT", "AUTO KEY"
    }};
    const std::array<juce::String, 13> ids {{
        "inputDb", "dryDb", "wetDb", "outputDb", "harmonyWidth", "tuningHz",
        "tightness", "smoothingMs", "humanize", "formantPreserve", "transientProtect", "unvoicedPreserve", "autoKeyThreshold"
    }};
    for (std::size_t i = 0; i < sliders.size(); ++i) {
        addGlobalKnob(*sliders[i], *labels[i], names[i], defaults[i]);
        globalA_[i] = std::make_unique<SA>(processor_.apvts, ids[i], *sliders[i]);
    }

    bypassA_ = std::make_unique<BA>(processor_.apvts, "bypass", bypass_);
    midiHoldA_ = std::make_unique<BA>(processor_.apvts, "midiHold", midiHold_);
    modeA_ = std::make_unique<CA>(processor_.apvts, "mode", mode_);
    keyA_ = std::make_unique<CA>(processor_.apvts, "key", key_);
    scaleA_ = std::make_unique<CA>(processor_.apvts, "scale", scale_);
    chordRootA_ = std::make_unique<CA>(processor_.apvts, "chordRoot", chordRoot_);
    chordTypeA_ = std::make_unique<CA>(processor_.apvts, "chordType", chordType_);
    midiChannelA_ = std::make_unique<CA>(processor_.apvts, "midiChannel", midiChannel_);

    inputMeterL_.setText("IN", juce::dontSendNotification);
    outputMeterLL_.setText("L", juce::dontSendNotification);
    outputMeterRL_.setText("R", juce::dontSendNotification);
    for (auto* l : {&inputMeterL_, &outputMeterLL_, &outputMeterRL_}) {
        styleLabel(*l, 8.5f);
        addAndMakeVisible(*l);
    }
    addAndMakeVisible(inputMeter_);
    addAndMakeVisible(outputMeterL_);
    addAndMakeVisible(outputMeterR_);

    for (int v = 0; v < 4; ++v) {
        voices_[static_cast<std::size_t>(v)] = std::make_unique<HarmonyVoicePanel>(processor_, v);
        addAndMakeVisible(*voices_[static_cast<std::size_t>(v)]);
    }

    stateA_ = processor_.apvts.copyState();
    stateB_ = stateA_.createCopy();
    refreshABButtons();
    setAdvancedView(false);
    startTimerHz(20);
}

HarmonyEngineAudioProcessorEditor::~HarmonyEngineAudioProcessorEditor() {
    stopTimer();
    setLookAndFeel(nullptr);
}

void HarmonyEngineAudioProcessorEditor::paint(juce::Graphics& g) {
    g.fillAll(kBg);

    g.setColour(kText);
    g.setFont(juce::Font(22.0f, juce::Font::bold));
    g.drawText("HARMONY ENGINE", 20, 8, 280, 30, juce::Justification::centredLeft);
    g.setColour(kMuted);
    g.setFont(10.0f);
    g.drawText("LOW-LATENCY 4-VOICE VOCAL HARMONY", 22, 38, 360, 16, juce::Justification::centredLeft);
    g.setColour(kBlueDim);
    g.fillRect(18, 64, getWidth() - 36, 1);

    drawPanel(g, juce::Rectangle<float>(18.0f, 76.0f, 340.0f, 220.0f), "HARMONY SOURCE");
    drawPanel(g, juce::Rectangle<float>(366.0f, 76.0f, 720.0f, 220.0f),
              advancedView_ ? "VOICE ENGINE — ADVANCED" : "VOICE ENGINE — MAIN");
    drawPanel(g, juce::Rectangle<float>(1094.0f, 76.0f, 168.0f, 220.0f), "REAL METERS");
}

void HarmonyEngineAudioProcessorEditor::resized() {
    bypass_.setBounds(getWidth() - 118, 18, 96, 28);
    advancedButton_.setBounds(getWidth() - 230, 18, 104, 28);
    aButton_.setBounds(getWidth() - 486, 18, 38, 28);
    bButton_.setBounds(getWidth() - 444, 18, 38, 28);
    copyButton_.setBounds(getWidth() - 402, 18, 86, 28);
    resetButton_.setBounds(getWidth() - 310, 18, 72, 28);

    auto source = juce::Rectangle<int>(30, 98, 316, 186);
    auto row = source.removeFromTop(31);
    modeL_.setBounds(row.removeFromLeft(52));
    mode_.setBounds(row.reduced(1, 3));

    row = source.removeFromTop(31);
    keyL_.setBounds(row.removeFromLeft(34));
    key_.setBounds(row.removeFromLeft(66).reduced(1, 3));
    scaleL_.setBounds(row.removeFromLeft(48));
    scale_.setBounds(row.reduced(1, 3));

    row = source.removeFromTop(31);
    chordRootL_.setBounds(row.removeFromLeft(46));
    chordRoot_.setBounds(row.removeFromLeft(66).reduced(1, 3));
    chordTypeL_.setBounds(row.removeFromLeft(38));
    chordType_.setBounds(row.reduced(1, 3));

    row = source.removeFromTop(31);
    midiChannelL_.setBounds(row.removeFromLeft(52));
    midiChannel_.setBounds(row.removeFromLeft(80).reduced(1, 3));
    midiHold_.setBounds(row.removeFromLeft(116));

    source.removeFromTop(2);
    detectedPitch_.setBounds(source.removeFromTop(27));
    detectedKey_.setBounds(source.removeFromTop(27));

    auto engine = juce::Rectangle<int>(378, 96, 696, 188);
    std::array<juce::Slider*, 13> sliders {{
        &input_, &dry_, &wet_, &output_, &harmonyWidth_, &tuningHz_,
        &tightness_, &smoothing_, &humanize_, &formantPreserve_, &transientProtect_, &consonantProtect_, &autoKeyThreshold_
    }};
    std::array<juce::Label*, 13> labels {{
        &inputL_, &dryL_, &wetL_, &outputL_, &harmonyWidthL_, &tuningHzL_,
        &tightnessL_, &smoothingL_, &humanizeL_, &formantPreserveL_, &transientProtectL_, &consonantProtectL_, &autoKeyThresholdL_
    }};

    if (!advancedView_) {
        // Main view: the eight controls used most often while singing/tracking.
        const std::array<int, 8> visible {{0, 1, 2, 3, 4, 6, 7, 8}};
        const int columns = 4;
        const int cellWidth = engine.getWidth() / columns;
        for (std::size_t n = 0; n < visible.size(); ++n) {
            const int i = visible[n];
            const int rowIndex = static_cast<int>(n) / columns;
            const int column = static_cast<int>(n) % columns;
            auto cell = juce::Rectangle<int>(engine.getX() + column * cellWidth,
                                             engine.getY() + rowIndex * 92,
                                             cellWidth, 88).reduced(3);
            labels[static_cast<std::size_t>(i)]->setBounds(cell.removeFromTop(14));
            sliders[static_cast<std::size_t>(i)]->setBounds(cell);
        }
    } else {
        const int columns = 7;
        const int cellWidth = engine.getWidth() / columns;
        for (int i = 0; i < 13; ++i) {
            const int rowIndex = i / columns;
            const int column = i % columns;
            auto cell = juce::Rectangle<int>(engine.getX() + column * cellWidth,
                                             engine.getY() + rowIndex * 92,
                                             cellWidth, 88).reduced(2);
            labels[static_cast<std::size_t>(i)]->setBounds(cell.removeFromTop(13));
            sliders[static_cast<std::size_t>(i)]->setBounds(cell);
        }
    }

    auto meters = juce::Rectangle<int>(1104, 96, 146, 188);
    const int meterWidth = 46;
    inputMeterL_.setBounds(meters.getX(), meters.getY(), meterWidth, 14);
    outputMeterLL_.setBounds(meters.getX() + 49, meters.getY(), meterWidth, 14);
    outputMeterRL_.setBounds(meters.getX() + 98, meters.getY(), meterWidth, 14);
    inputMeter_.setBounds(meters.getX(), meters.getY() + 16, meterWidth, 172);
    outputMeterL_.setBounds(meters.getX() + 49, meters.getY() + 16, meterWidth, 172);
    outputMeterR_.setBounds(meters.getX() + 98, meters.getY() + 16, meterWidth, 172);

    auto bottom = juce::Rectangle<int>(18, 308, getWidth() - 36, getHeight() - 326);
    constexpr int gap = 8;
    const int voiceWidth = (bottom.getWidth() - gap * 3) / 4;
    for (int voice = 0; voice < 4; ++voice) {
        voices_[static_cast<std::size_t>(voice)]->setBounds(bottom.removeFromLeft(voiceWidth));
        if (voice != 3) bottom.removeFromLeft(gap);
    }
}

void HarmonyEngineAudioProcessorEditor::setAdvancedView(bool advanced) {
    advancedView_ = advanced;
    advancedButton_.setToggleState(advancedView_, juce::dontSendNotification);

    std::array<juce::Component*, 10> advancedGlobals {{
        &tuningHz_, &tuningHzL_,
        &formantPreserve_, &formantPreserveL_,
        &transientProtect_, &transientProtectL_,
        &consonantProtect_, &consonantProtectL_,
        &autoKeyThreshold_, &autoKeyThresholdL_
    }};
    for (auto* component : advancedGlobals) component->setVisible(advancedView_);

    for (auto& voice : voices_) {
        if (voice != nullptr) voice->setAdvanced(advancedView_);
    }

    resized();
    repaint();
}

void HarmonyEngineAudioProcessorEditor::switchAB(bool useA) {
    if (useA == usingA_) return;
    if (usingA_) stateA_ = processor_.apvts.copyState();
    else stateB_ = processor_.apvts.copyState();

    usingA_ = useA;
    const auto target = usingA_ ? stateA_ : stateB_;
    if (target.isValid()) processor_.apvts.replaceState(target.createCopy());
    refreshABButtons();
}

void HarmonyEngineAudioProcessorEditor::copyAB() {
    if (usingA_) stateB_ = processor_.apvts.copyState();
    else stateA_ = processor_.apvts.copyState();
    refreshABButtons();
}

void HarmonyEngineAudioProcessorEditor::resetParameters() {
    for (auto* parameter : processor_.getParameters()) {
        if (parameter == nullptr) continue;
        parameter->beginChangeGesture();
        parameter->setValueNotifyingHost(parameter->getDefaultValue());
        parameter->endChangeGesture();
    }
    if (usingA_) stateA_ = processor_.apvts.copyState();
    else stateB_ = processor_.apvts.copyState();
}

void HarmonyEngineAudioProcessorEditor::refreshABButtons() {
    aButton_.setToggleState(usingA_, juce::dontSendNotification);
    bButton_.setToggleState(!usingA_, juce::dontSendNotification);
    copyButton_.setButtonText(usingA_ ? "COPY A→B" : "COPY B→A");
}

void HarmonyEngineAudioProcessorEditor::timerCallback() {
    inputMeter_.setLevel(processor_.meterInput());
    outputMeterL_.setLevel(processor_.meterOutputL());
    outputMeterR_.setLevel(processor_.meterOutputR());
    for (auto& v : voices_) v->updateRealtime();

    const float midi = processor_.detectedPitchMidi();
    const float conf = processor_.detectedPitchConfidence();
    const int note = static_cast<int>(std::lround(midi));
    const juce::String pitchText = conf > 0.05f ? midiName(note) : "--";
    const float cents = conf > 0.05f ? (midi - static_cast<float>(note)) * 100.0f : 0.0f;
    detectedPitch_.setText("PITCH  " + pitchText + "   " + juce::String(cents, 1) + " ct   CONF " +
                               juce::String(conf * 100.0f, 0) + "%", juce::dontSendNotification);

    const int root = juce::jlimit(0, 11, processor_.detectedKeyRoot());
    const int scaleIndex = juce::jlimit(0, 8, processor_.detectedScaleIndex());
    const float keyConf = processor_.detectedKeyConfidence();
    detectedKey_.setText("AUTO KEY  " + harmonyplugin::keyNames()[root] + " " +
                             harmonyplugin::scaleNames()[scaleIndex] + "   CONF " +
                             juce::String(keyConf * 100.0f, 0) + "%", juce::dontSendNotification);

    const int modeIndex = mode_.getSelectedItemIndex();
    const bool manualChord = modeIndex == 1;
    const bool midiChord = modeIndex == 2;
    const bool autoKey = modeIndex == 3;
    const bool manualKey = modeIndex == 0 || midiChord;

    chordRoot_.setEnabled(manualChord);
    chordType_.setEnabled(manualChord);
    chordRootL_.setEnabled(manualChord);
    chordTypeL_.setEnabled(manualChord);

    key_.setEnabled(manualKey);
    scale_.setEnabled(manualKey);
    keyL_.setEnabled(manualKey);
    scaleL_.setEnabled(manualKey);

    midiChannel_.setEnabled(midiChord);
    midiChannelL_.setEnabled(midiChord);
    midiHold_.setEnabled(midiChord);

    autoKeyThreshold_.setEnabled(autoKey);
    autoKeyThresholdL_.setEnabled(autoKey);
}
