#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <algorithm>
#include <cmath>

namespace {
template <typename E>
constexpr std::size_t enumIndex(E value) noexcept {
    return static_cast<std::size_t>(value);
}
}

HarmonyEngineAudioProcessor::HarmonyEngineAudioProcessor()
    : juce::AudioProcessor(BusesProperties()
          .withInput("Input", juce::AudioChannelSet::stereo(), true)
          .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "STATE", harmonyplugin::createParameterLayout()) {
    cacheParameterPointers();
    for (auto& n : targetNotes_) n.store(-1, std::memory_order_relaxed);
}

void HarmonyEngineAudioProcessor::cacheParameterPointers() {
    static constexpr std::array<const char*, enumIndex(GlobalParam::Count)> globalIds {{
        "bypass", "inputDb", "outputDb", "dryDb", "wetDb", "harmonyWidth", "tuningHz",
        "mode", "key", "scale", "chordRoot", "chordType", "midiChannel", "midiHold",
        "autoKeyThreshold", "tightness", "smoothingMs", "humanize", "formantPreserve",
        "transientProtect", "unvoicedPreserve"
    }};

    for (std::size_t i = 0; i < globalIds.size(); ++i)
        globalParams_[i] = apvts.getRawParameterValue(globalIds[i]);

    static constexpr std::array<const char*, enumIndex(VoiceParam::Count)> voiceSuffixes {{
        "enable", "mute", "solo", "mode", "interval", "octave", "level", "pan", "formant",
        "detune", "humanizeCents", "delayMs", "vibratoCents", "vibratoRate", "choirVoices",
        "choirSpread", "choirDepth", "minMidi", "maxMidi"
    }};

    for (int voice = 0; voice < 4; ++voice) {
        for (std::size_t i = 0; i < voiceSuffixes.size(); ++i)
            voiceParams_[static_cast<std::size_t>(voice)][i] =
                apvts.getRawParameterValue(harmonyplugin::voiceId(voice, voiceSuffixes[i]));
    }
}

float HarmonyEngineAudioProcessor::globalValue(GlobalParam p) const noexcept {
    const auto* value = globalParams_[enumIndex(p)];
    return value != nullptr ? value->load(std::memory_order_relaxed) : 0.0f;
}

float HarmonyEngineAudioProcessor::voiceValue(std::size_t voice, VoiceParam p) const noexcept {
    if (voice >= voiceParams_.size()) return 0.0f;
    const auto* value = voiceParams_[voice][enumIndex(p)];
    return value != nullptr ? value->load(std::memory_order_relaxed) : 0.0f;
}

void HarmonyEngineAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock) {
    engine_.prepare(sampleRate);
    engine_.setParams(readParameters());
    setLatencySamples(engine_.latencySamples());

    // Fixed preallocated scratch area. processBlock() handles oversized host
    // blocks in chunks, so no vector resize/allocation happens on the audio thread.
    const std::size_t requested = static_cast<std::size_t>(std::max(1, samplesPerBlock));
    const std::size_t capacity = std::max(kScratchCapacity, requested);
    monoInput_.assign(capacity, 0.0f);
    outputL_.assign(capacity, 0.0f);
    outputR_.assign(capacity, 0.0f);

    activeMidiNotes_.fill(false);
    physicalMidiNotes_.fill(false);
    lastMidiHold_ = false;

    const std::size_t bypassSize = static_cast<std::size_t>(std::max(1, engine_.latencySamples()));
    bypassDelayL_.assign(bypassSize, 0.0f);
    bypassDelayR_.assign(bypassSize, 0.0f);
    bypassWrite_ = 0;
}

void HarmonyEngineAudioProcessor::releaseResources() {}

bool HarmonyEngineAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const {
    const auto in = layouts.getMainInputChannelSet();
    const auto out = layouts.getMainOutputChannelSet();
    const bool inputOk = in == juce::AudioChannelSet::mono() || in == juce::AudioChannelSet::stereo();
    const bool outputOk = out == juce::AudioChannelSet::mono() || out == juce::AudioChannelSet::stereo();
    return inputOk && outputOk;
}

harmony::ProcessorParams HarmonyEngineAudioProcessor::readParameters() const noexcept {
    harmony::ProcessorParams p;
    p.inputDb = globalValue(GlobalParam::InputDb);
    p.outputDb = globalValue(GlobalParam::OutputDb);
    p.dryDb = globalValue(GlobalParam::DryDb);
    p.wetDb = globalValue(GlobalParam::WetDb);
    p.harmonyWidth = globalValue(GlobalParam::HarmonyWidth) * 0.01f;
    p.tuningHz = globalValue(GlobalParam::TuningHz);
    p.tightness = globalValue(GlobalParam::Tightness) * 0.01f;
    p.pitchSmoothingMs = globalValue(GlobalParam::SmoothingMs);
    p.humanize = globalValue(GlobalParam::Humanize) * 0.01f;
    p.formantPreserve = globalValue(GlobalParam::FormantPreserve) * 0.01f;
    p.transientProtection = globalValue(GlobalParam::TransientProtect) * 0.01f;
    p.unvoicedPreserve = globalValue(GlobalParam::UnvoicedPreserve) * 0.01f;
    p.autoKeyThreshold = globalValue(GlobalParam::AutoKeyThreshold) * 0.01f;
    p.mode = static_cast<harmony::HarmonyMode>(juce::jlimit(0, 3, static_cast<int>(std::lround(globalValue(GlobalParam::Mode)))));
    p.keyRoot = juce::jlimit(0, 11, static_cast<int>(std::lround(globalValue(GlobalParam::Key))));
    p.scale = static_cast<harmony::ScaleType>(juce::jlimit(0, 8, static_cast<int>(std::lround(globalValue(GlobalParam::Scale)))));
    p.chordRoot = juce::jlimit(0, 11, static_cast<int>(std::lround(globalValue(GlobalParam::ChordRoot))));
    p.chordType = static_cast<harmony::ChordType>(juce::jlimit(0, 14, static_cast<int>(std::lround(globalValue(GlobalParam::ChordType)))));

    for (std::size_t v = 0; v < 4; ++v) {
        auto& vp = p.voices[v];
        vp.rule.enabled = voiceValue(v, VoiceParam::Enable) >= 0.5f;
        vp.mute = voiceValue(v, VoiceParam::Mute) >= 0.5f;
        vp.solo = voiceValue(v, VoiceParam::Solo) >= 0.5f;
        vp.rule.mode = static_cast<harmony::VoiceMode>(juce::jlimit(0, 2, static_cast<int>(std::lround(voiceValue(v, VoiceParam::Mode)))));
        vp.rule.interval = juce::jlimit(-12, 12, static_cast<int>(std::lround(voiceValue(v, VoiceParam::Interval))));
        vp.rule.octave = juce::jlimit(-2, 2, static_cast<int>(std::lround(voiceValue(v, VoiceParam::Octave))));
        vp.levelDb = voiceValue(v, VoiceParam::Level);
        vp.pan = voiceValue(v, VoiceParam::Pan) * 0.01f;
        vp.formantSemitones = voiceValue(v, VoiceParam::Formant);
        vp.detuneCents = voiceValue(v, VoiceParam::Detune);
        vp.humanizeCents = voiceValue(v, VoiceParam::HumanizeCents);
        vp.delayMs = voiceValue(v, VoiceParam::DelayMs);
        vp.vibratoCents = voiceValue(v, VoiceParam::VibratoCents);
        vp.vibratoRateHz = voiceValue(v, VoiceParam::VibratoRate);
        const int choirIndex = juce::jlimit(0, 3, static_cast<int>(std::lround(voiceValue(v, VoiceParam::ChoirVoices))));
        static constexpr int choirCounts[4] = {1, 2, 4, 8};
        vp.choirVoices = choirCounts[choirIndex];
        vp.choirSpread = voiceValue(v, VoiceParam::ChoirSpread) * 0.01f;
        vp.choirDepth = voiceValue(v, VoiceParam::ChoirDepth) * 0.01f;
        vp.minMidi = static_cast<int>(std::lround(voiceValue(v, VoiceParam::MinMidi)));
        vp.maxMidi = static_cast<int>(std::lround(voiceValue(v, VoiceParam::MaxMidi)));
        if (vp.minMidi > vp.maxMidi) std::swap(vp.minMidi, vp.maxMidi);
    }
    return p;
}

void HarmonyEngineAudioProcessor::updateMidiChord(const juce::MidiBuffer& midi) noexcept {
    const bool hold = globalValue(GlobalParam::MidiHold) >= 0.5f;
    const int channelChoice = juce::jlimit(0, 16, static_cast<int>(std::lround(globalValue(GlobalParam::MidiChannel))));

    if (!hold && lastMidiHold_) activeMidiNotes_ = physicalMidiNotes_;

    for (const auto metadata : midi) {
        const auto msg = metadata.getMessage();
        if (channelChoice != 0 && (msg.isNoteOnOrOff() || msg.isController()) &&
            !msg.isForChannel(channelChoice))
            continue;

        if (msg.isNoteOn()) {
            const int note = juce::jlimit(0, 127, msg.getNoteNumber());
            const bool hadPhysicalNotes = std::any_of(physicalMidiNotes_.begin(), physicalMidiNotes_.end(), [](bool value) { return value; });
            if (hold && !hadPhysicalNotes) activeMidiNotes_.fill(false);
            physicalMidiNotes_[static_cast<std::size_t>(note)] = true;
            activeMidiNotes_[static_cast<std::size_t>(note)] = true;
        } else if (msg.isNoteOff()) {
            const int note = juce::jlimit(0, 127, msg.getNoteNumber());
            physicalMidiNotes_[static_cast<std::size_t>(note)] = false;
            if (!hold) activeMidiNotes_[static_cast<std::size_t>(note)] = false;
        } else if (msg.isAllNotesOff() || msg.isAllSoundOff()) {
            physicalMidiNotes_.fill(false);
            if (!hold) activeMidiNotes_.fill(false);
        }
    }

    lastMidiHold_ = hold;

    std::array<int, 16> notes{};
    std::size_t count = 0;
    for (int note = 0; note < 128 && count < notes.size(); ++note) {
        if (activeMidiNotes_[static_cast<std::size_t>(note)]) notes[count++] = note;
    }
    engine_.setChordNotes(notes.data(), count);
}

void HarmonyEngineAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi) {
    juce::ScopedNoDenormals noDenormals;
    const int numSamples = buffer.getNumSamples();
    if (numSamples <= 0 || buffer.getNumChannels() < 1) return;

    engine_.setParams(readParameters());
    updateMidiChord(midi);

    const int inChannels = getTotalNumInputChannels();
    const int outChannels = getTotalNumOutputChannels();
    const float* in0 = buffer.getReadPointer(0);
    const float* in1 = (inChannels > 1 && buffer.getNumChannels() > 1) ? buffer.getReadPointer(1) : nullptr;
    float* out0 = buffer.getWritePointer(0);
    float* out1 = (outChannels > 1 && buffer.getNumChannels() > 1) ? buffer.getWritePointer(1) : nullptr;

    const bool bypass = globalValue(GlobalParam::Bypass) >= 0.5f;
    float bypassInPeak = 0.0f;
    float bypassOutLPeak = 0.0f;
    float bypassOutRPeak = 0.0f;
    const std::size_t delaySize = bypassDelayL_.size();
    const std::size_t scratchCapacity = std::min({monoInput_.size(), outputL_.size(), outputR_.size()});
    if (scratchCapacity == 0U) {
        buffer.clear();
        return;
    }

    int offset = 0;
    while (offset < numSamples) {
        const int chunk = std::min<int>(numSamples - offset, static_cast<int>(scratchCapacity));

        for (int i = 0; i < chunk; ++i) {
            const int sample = offset + i;
            const float srcL = in0[sample];
            const float srcR = in1 != nullptr ? in1[sample] : srcL;
            monoInput_[static_cast<std::size_t>(i)] = in1 != nullptr ? 0.5f * (srcL + srcR) : srcL;
        }

        engine_.processBlock(monoInput_.data(), outputL_.data(), outputR_.data(), static_cast<std::size_t>(chunk));

        for (int i = 0; i < chunk; ++i) {
            const int sample = offset + i;
            const float srcL = in0[sample];
            const float srcR = in1 != nullptr ? in1[sample] : srcL;
            bypassInPeak = std::max(bypassInPeak, std::max(std::abs(srcL), std::abs(srcR)));

            float delayedL = srcL;
            float delayedR = srcR;
            if (delaySize > 0U) {
                delayedL = bypassDelayL_[bypassWrite_];
                delayedR = bypassDelayR_[bypassWrite_];
                bypassDelayL_[bypassWrite_] = srcL;
                bypassDelayR_[bypassWrite_] = srcR;
                bypassWrite_ = (bypassWrite_ + 1U) % delaySize;
            }

            if (bypass) {
                if (out1 != nullptr) {
                    out0[sample] = delayedL;
                    out1[sample] = delayedR;
                    bypassOutLPeak = std::max(bypassOutLPeak, std::abs(delayedL));
                    bypassOutRPeak = std::max(bypassOutRPeak, std::abs(delayedR));
                } else {
                    const float mono = 0.5f * (delayedL + delayedR);
                    out0[sample] = mono;
                    bypassOutLPeak = std::max(bypassOutLPeak, std::abs(mono));
                    bypassOutRPeak = bypassOutLPeak;
                }
            } else if (out1 != nullptr) {
                out0[sample] = outputL_[static_cast<std::size_t>(i)];
                out1[sample] = outputR_[static_cast<std::size_t>(i)];
            } else {
                out0[sample] = 0.5f * (outputL_[static_cast<std::size_t>(i)] + outputR_[static_cast<std::size_t>(i)]);
            }
        }

        offset += chunk;
    }

    for (int ch = outChannels; ch < buffer.getNumChannels(); ++ch) buffer.clear(ch, 0, numSamples);

    publishMeters();
    if (bypass) {
        meterInput_.store(bypassInPeak, std::memory_order_relaxed);
        meterOutputL_.store(bypassOutLPeak, std::memory_order_relaxed);
        meterOutputR_.store(bypassOutRPeak, std::memory_order_relaxed);
        for (auto& meter : meterVoice_) meter.store(0.0f, std::memory_order_relaxed);
    }
}

void HarmonyEngineAudioProcessor::publishMeters() noexcept {
    const auto m = engine_.meters();
    meterInput_.store(m.inputPeak, std::memory_order_relaxed);
    meterOutputL_.store(m.outputPeakL, std::memory_order_relaxed);
    meterOutputR_.store(m.outputPeakR, std::memory_order_relaxed);
    for (std::size_t v = 0; v < 4; ++v) meterVoice_[v].store(m.voicePeak[v], std::memory_order_relaxed);
    pitchMidi_.store(m.pitchMidi, std::memory_order_relaxed);
    pitchConfidence_.store(m.pitchConfidence, std::memory_order_relaxed);
    detectedKeyRoot_.store(m.detectedKeyRoot, std::memory_order_relaxed);
    detectedScale_.store(static_cast<int>(m.detectedScale), std::memory_order_relaxed);
    detectedKeyConfidence_.store(m.keyConfidence, std::memory_order_relaxed);
    const auto targets = engine_.targetNotes();
    for (std::size_t v = 0; v < 4; ++v) targetNotes_[v].store(targets[v], std::memory_order_relaxed);
}

juce::AudioProcessorEditor* HarmonyEngineAudioProcessor::createEditor() {
    return new HarmonyEngineAudioProcessorEditor(*this);
}

void HarmonyEngineAudioProcessor::getStateInformation(juce::MemoryBlock& destData) {
    if (const auto xml = apvts.copyState().createXml()) copyXmlToBinary(*xml, destData);
}

void HarmonyEngineAudioProcessor::setStateInformation(const void* data, int sizeInBytes) {
    if (data == nullptr || sizeInBytes <= 0) return;
    if (const auto xml = getXmlFromBinary(data, sizeInBytes)) {
        if (xml->hasTagName(apvts.state.getType())) apvts.replaceState(juce::ValueTree::fromXml(*xml));
    }
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() {
    return new HarmonyEngineAudioProcessor();
}
