#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <algorithm>
#include <cmath>

HarmonyEngineAudioProcessor::HarmonyEngineAudioProcessor()
    : juce::AudioProcessor(BusesProperties()
          .withInput("Input", juce::AudioChannelSet::stereo(), true)
          .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "STATE", harmonyplugin::createParameterLayout()) {
    for (auto& n : targetNotes_) n.store(-1, std::memory_order_relaxed);
}

void HarmonyEngineAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock) {
    engine_.prepare(sampleRate);
    engine_.setParams(readParameters());
    setLatencySamples(engine_.latencySamples());
    const std::size_t capacity = static_cast<std::size_t>(std::max(1, samplesPerBlock));
    monoInput_.resize(capacity);
    outputL_.resize(capacity);
    outputR_.resize(capacity);
    activeMidiNotes_.fill(false);
    physicalMidiNotes_.fill(false);
    lastMidiHold_ = false;
    const std::size_t bypassSize = static_cast<std::size_t>(std::max(1, engine_.latencySamples()));
    bypassDelayL_.assign(bypassSize, 0.0f);
    bypassDelayR_.assign(bypassSize, 0.0f);
    bypassWrite_ = 0;
}

void HarmonyEngineAudioProcessor::releaseResources() {}

bool HarmonyEngineAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const {
    const auto in = layouts.getMainInputChannelSet();
    const auto out = layouts.getMainOutputChannelSet();
    if (out != juce::AudioChannelSet::stereo()) return false;
    return in == juce::AudioChannelSet::mono() || in == juce::AudioChannelSet::stereo();
}

harmony::ProcessorParams HarmonyEngineAudioProcessor::readParameters() const noexcept {
    const auto value = [this](const juce::String& id) noexcept -> float {
        if (const auto* p = apvts.getRawParameterValue(id)) return p->load(std::memory_order_relaxed);
        return 0.0f;
    };

    harmony::ProcessorParams p;
    p.inputDb = value("inputDb");
    p.outputDb = value("outputDb");
    p.dryDb = value("dryDb");
    p.wetDb = value("wetDb");
    p.harmonyWidth = value("harmonyWidth") * 0.01f;
    p.tuningHz = value("tuningHz");
    p.tightness = value("tightness") * 0.01f;
    p.pitchSmoothingMs = value("smoothingMs");
    p.humanize = value("humanize") * 0.01f;
    p.formantPreserve = value("formantPreserve") * 0.01f;
    p.transientProtection = value("transientProtect") * 0.01f;
    p.unvoicedPreserve = value("unvoicedPreserve") * 0.01f;
    p.autoKeyThreshold = value("autoKeyThreshold") * 0.01f;
    p.mode = static_cast<harmony::HarmonyMode>(juce::jlimit(0, 3, static_cast<int>(std::lround(value("mode")))));
    p.keyRoot = juce::jlimit(0, 11, static_cast<int>(std::lround(value("key"))));
    p.scale = static_cast<harmony::ScaleType>(juce::jlimit(0, 8, static_cast<int>(std::lround(value("scale")))));
    p.chordRoot = juce::jlimit(0, 11, static_cast<int>(std::lround(value("chordRoot"))));
    p.chordType = static_cast<harmony::ChordType>(juce::jlimit(0, 14, static_cast<int>(std::lround(value("chordType")))));

    for (int v = 0; v < 4; ++v) {
        auto& vp = p.voices[static_cast<std::size_t>(v)];
        vp.rule.enabled = value(harmonyplugin::voiceId(v, "enable")) >= 0.5f;
        vp.mute = value(harmonyplugin::voiceId(v, "mute")) >= 0.5f;
        vp.solo = value(harmonyplugin::voiceId(v, "solo")) >= 0.5f;
        vp.rule.mode = static_cast<harmony::VoiceMode>(juce::jlimit(0, 2, static_cast<int>(std::lround(value(harmonyplugin::voiceId(v, "mode"))))));
        vp.rule.interval = juce::jlimit(-12, 12, static_cast<int>(std::lround(value(harmonyplugin::voiceId(v, "interval")))));
        vp.rule.octave = juce::jlimit(-2, 2, static_cast<int>(std::lround(value(harmonyplugin::voiceId(v, "octave")))));
        vp.levelDb = value(harmonyplugin::voiceId(v, "level"));
        vp.pan = value(harmonyplugin::voiceId(v, "pan")) * 0.01f;
        vp.formantSemitones = value(harmonyplugin::voiceId(v, "formant"));
        vp.detuneCents = value(harmonyplugin::voiceId(v, "detune"));
        vp.humanizeCents = value(harmonyplugin::voiceId(v, "humanizeCents"));
        vp.delayMs = value(harmonyplugin::voiceId(v, "delayMs"));
        vp.vibratoCents = value(harmonyplugin::voiceId(v, "vibratoCents"));
        vp.vibratoRateHz = value(harmonyplugin::voiceId(v, "vibratoRate"));
        const int choirIndex = juce::jlimit(0, 3, static_cast<int>(std::lround(value(harmonyplugin::voiceId(v, "choirVoices")))));
        static constexpr int choirCounts[4] = {1, 2, 4, 8};
        vp.choirVoices = choirCounts[choirIndex];
        vp.choirSpread = value(harmonyplugin::voiceId(v, "choirSpread")) * 0.01f;
        vp.choirDepth = value(harmonyplugin::voiceId(v, "choirDepth")) * 0.01f;
        vp.minMidi = static_cast<int>(std::lround(value(harmonyplugin::voiceId(v, "minMidi"))));
        vp.maxMidi = static_cast<int>(std::lround(value(harmonyplugin::voiceId(v, "maxMidi"))));
        if (vp.minMidi > vp.maxMidi) std::swap(vp.minMidi, vp.maxMidi);
    }
    return p;
}

void HarmonyEngineAudioProcessor::updateMidiChord(const juce::MidiBuffer& midi) noexcept {
    const auto raw = [this](const juce::String& id) noexcept -> float {
        if (const auto* p = apvts.getRawParameterValue(id)) return p->load(std::memory_order_relaxed);
        return 0.0f;
    };

    const bool hold = raw("midiHold") >= 0.5f;
    const int channelChoice = juce::jlimit(0, 16, static_cast<int>(std::lround(raw("midiChannel"))));

    if (!hold && lastMidiHold_) activeMidiNotes_ = physicalMidiNotes_;

    for (const auto metadata : midi) {
        const auto msg = metadata.getMessage();
        if (msg.isForChannel(juce::jmax(1, channelChoice)) == false && channelChoice != 0 &&
            (msg.isNoteOnOrOff() || msg.isController()))
            continue;

        if (msg.isNoteOn()) {
            const int note = juce::jlimit(0, 127, msg.getNoteNumber());
            const bool hadPhysicalNotes = std::any_of(physicalMidiNotes_.begin(), physicalMidiNotes_.end(), [](bool v) { return v; });
            if (hold && !hadPhysicalNotes) activeMidiNotes_.fill(false);
            physicalMidiNotes_[static_cast<std::size_t>(note)] = true;
            activeMidiNotes_[static_cast<std::size_t>(note)] = true;
        } else if (msg.isNoteOff()) {
            const int note = juce::jlimit(0, 127, msg.getNoteNumber());
            physicalMidiNotes_[static_cast<std::size_t>(note)] = false;
            if (!hold) activeMidiNotes_[static_cast<std::size_t>(note)] = false;
        } else if (msg.isAllNotesOff() || msg.isAllSoundOff()) {
            physicalMidiNotes_.fill(false);
            if (!hold) activeMidiNotes_.fill(false);
        }
    }

    lastMidiHold_ = hold;

    std::array<int, 16> notes{};
    std::size_t count = 0;
    for (int note = 0; note < 128 && count < notes.size(); ++note) {
        if (activeMidiNotes_[static_cast<std::size_t>(note)]) notes[count++] = note;
    }
    engine_.setChordNotes(notes.data(), count);
}

void HarmonyEngineAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi) {
    juce::ScopedNoDenormals noDenormals;
    const int numSamples = buffer.getNumSamples();
    if (numSamples <= 0) return;

    if (monoInput_.size() < static_cast<std::size_t>(numSamples)) {
        monoInput_.resize(static_cast<std::size_t>(numSamples));
        outputL_.resize(static_cast<std::size_t>(numSamples));
        outputR_.resize(static_cast<std::size_t>(numSamples));
    }

    engine_.setParams(readParameters());
    updateMidiChord(midi);

    const int inChannels = getTotalNumInputChannels();
    const float* in0 = buffer.getReadPointer(0);
    const float* in1 = inChannels > 1 ? buffer.getReadPointer(1) : nullptr;
    for (int i = 0; i < numSamples; ++i) {
        monoInput_[static_cast<std::size_t>(i)] = in1 != nullptr
            ? 0.5f * (in0[i] + in1[i])
            : in0[i];
    }

    engine_.processBlock(monoInput_.data(), outputL_.data(), outputR_.data(), static_cast<std::size_t>(numSamples));

    const bool bypass = apvts.getRawParameterValue("bypass")->load(std::memory_order_relaxed) >= 0.5f;
    float bypassInPeak = 0.0f;
    float bypassOutLPeak = 0.0f;
    float bypassOutRPeak = 0.0f;
    const std::size_t delaySize = bypassDelayL_.size();
    for (int i = 0; i < numSamples; ++i) {
        const float srcL = in0[i];
        const float srcR = in1 != nullptr ? in1[i] : srcL;
        bypassInPeak = std::max(bypassInPeak, std::max(std::abs(srcL), std::abs(srcR)));

        float delayedL = srcL;
        float delayedR = srcR;
        if (delaySize > 0U) {
            delayedL = bypassDelayL_[bypassWrite_];
            delayedR = bypassDelayR_[bypassWrite_];
            bypassDelayL_[bypassWrite_] = srcL;
            bypassDelayR_[bypassWrite_] = srcR;
            bypassWrite_ = (bypassWrite_ + 1U) % delaySize;
        }

        if (bypass) {
            outputL_[static_cast<std::size_t>(i)] = delayedL;
            outputR_[static_cast<std::size_t>(i)] = delayedR;
            bypassOutLPeak = std::max(bypassOutLPeak, std::abs(delayedL));
            bypassOutRPeak = std::max(bypassOutRPeak, std::abs(delayedR));
        }
    }

    auto* l = buffer.getWritePointer(0);
    auto* r = buffer.getWritePointer(1);
    for (int i = 0; i < numSamples; ++i) {
        l[i] = outputL_[static_cast<std::size_t>(i)];
        r[i] = outputR_[static_cast<std::size_t>(i)];
    }
    for (int ch = 2; ch < buffer.getNumChannels(); ++ch) buffer.clear(ch, 0, numSamples);

    publishMeters();
    if (bypass) {
        meterInput_.store(bypassInPeak, std::memory_order_relaxed);
        meterOutputL_.store(bypassOutLPeak, std::memory_order_relaxed);
        meterOutputR_.store(bypassOutRPeak, std::memory_order_relaxed);
        for (auto& m : meterVoice_) m.store(0.0f, std::memory_order_relaxed);
    }
}

void HarmonyEngineAudioProcessor::publishMeters() noexcept {
    const auto m = engine_.meters();
    meterInput_.store(m.inputPeak, std::memory_order_relaxed);
    meterOutputL_.store(m.outputPeakL, std::memory_order_relaxed);
    meterOutputR_.store(m.outputPeakR, std::memory_order_relaxed);
    for (std::size_t v = 0; v < 4; ++v) meterVoice_[v].store(m.voicePeak[v], std::memory_order_relaxed);
    pitchMidi_.store(m.pitchMidi, std::memory_order_relaxed);
    pitchConfidence_.store(m.pitchConfidence, std::memory_order_relaxed);
    detectedKeyRoot_.store(m.detectedKeyRoot, std::memory_order_relaxed);
    detectedScale_.store(static_cast<int>(m.detectedScale), std::memory_order_relaxed);
    detectedKeyConfidence_.store(m.keyConfidence, std::memory_order_relaxed);
    const auto targets = engine_.targetNotes();
    for (std::size_t v = 0; v < 4; ++v) targetNotes_[v].store(targets[v], std::memory_order_relaxed);
}

juce::AudioProcessorEditor* HarmonyEngineAudioProcessor::createEditor() {
    return new HarmonyEngineAudioProcessorEditor(*this);
}

void HarmonyEngineAudioProcessor::getStateInformation(juce::MemoryBlock& destData) {
    if (const auto xml = apvts.copyState().createXml()) copyXmlToBinary(*xml, destData);
}

void HarmonyEngineAudioProcessor::setStateInformation(const void* data, int sizeInBytes) {
    if (const auto xml = getXmlFromBinary(data, sizeInBytes)) {
        if (xml->hasTagName(apvts.state.getType())) apvts.replaceState(juce::ValueTree::fromXml(*xml));
    }
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() {
    return new HarmonyEngineAudioProcessor();
}
