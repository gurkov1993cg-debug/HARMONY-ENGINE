#include "harmony/AudioMath.h"
#include "harmony/AutoKeyDetector.h"
#include "harmony/FFT.h"
#include "harmony/HarmonyPlanner.h"
#include "harmony/HarmonyProcessor.h"
#include "harmony/MultiVoiceVocoder.h"
#include "harmony/PitchTracker.h"
#include <algorithm>
#include <cmath>
#include <complex>
#include <cstdlib>
#include <iostream>
#include <vector>

using namespace harmony;

static void require(bool ok, const char* msg) {
    if (!ok) { std::cerr << "FAIL: " << msg << '\n'; std::exit(1); }
}

static double rms(const std::vector<float>& x, std::size_t start = 0) {
    double e = 0.0;
    std::size_t count = 0;
    for (std::size_t i = std::min(start, x.size()); i < x.size(); ++i) { e += static_cast<double>(x[i]) * x[i]; ++count; }
    return count == 0 ? 0.0 : std::sqrt(e / static_cast<double>(count));
}

static double estimateFrequencyZeroCross(const std::vector<float>& x, double sr, std::size_t start) {
    std::vector<std::size_t> crossings;
    for (std::size_t i = std::max<std::size_t>(1U, start); i < x.size(); ++i) {
        if (x[i - 1U] <= 0.0f && x[i] > 0.0f) crossings.push_back(i);
    }
    if (crossings.size() < 4U) return 0.0;
    const double periods = static_cast<double>(crossings.size() - 1U);
    const double samples = static_cast<double>(crossings.back() - crossings.front());
    return periods * sr / samples;
}

static PitchEstimate runPitch(double hz) {
    constexpr double sr = 48000.0;
    PitchTracker tr;
    tr.prepare(sr);
    PitchEstimate e{};
    for (int n = 0; n < static_cast<int>(sr * 0.36); ++n) {
        const float fundamental = 0.28f * std::sin(static_cast<float>(kTwoPi * hz * n / sr));
        const float harmonic2 = 0.08f * std::sin(static_cast<float>(kTwoPi * hz * 2.0 * n / sr + 0.3));
        e = tr.processSample(fundamental + harmonic2);
    }
    return e;
}

int main() {
    {
        FFT fft(1024);
        std::vector<std::complex<float>> x(1024);
        for (std::size_t i = 0; i < x.size(); ++i) x[i] = {std::sin(kTwoPi * 13.0f * static_cast<float>(i) / 1024.0f), 0.0f};
        const auto original = x;
        fft.forward(x);
        fft.inverse(x);
        float maxErr = 0.0f;
        for (std::size_t i = 0; i < x.size(); ++i) maxErr = std::max(maxErr, std::abs(x[i].real() - original[i].real()));
        require(maxErr < 1.0e-4f, "custom FFT roundtrip");
    }

    {
        HarmonyPlanner p;
        p.setKey(0, ScaleType::Major);
        require(p.quantizeLeadMidi(60.4f) == 60, "C major quantizer");
        HarmonyVoiceRule third{true, VoiceMode::ScaleDegree, 2, 0};
        require(p.targetMidi(60.0f, third, -1) == 64, "C major diatonic third");
        require(p.targetMidi(62.0f, third, -1) == 65, "D major-scale diatonic third");
        p.setKey(0, ScaleType::Lydian);
        require(p.quantizeLeadMidi(66.0f) == 66, "Lydian raised fourth");

        p.setKey(7, ScaleType::Major);
        require(p.targetMidi(67.0f, third, -1) == 71, "G major scale third from G must be B");
        require(p.targetMidi(69.0f, third, -1) == 72, "G major scale third from A must be C");

        const HarmonyVoiceRule custom{true, VoiceMode::ScaleDegree, 0, 0};
        auto presetRule = HarmonyPlanner::ruleForPreset(HarmonyIntervalPreset::MinorThirdUp, custom);
        require(presetRule.mode == VoiceMode::ChromaticSemitone && presetRule.interval == 3 && presetRule.octave == 0, "minor-third preset mapping");
        require(p.targetMidi(67.0f, presetRule, -1) == 70, "minor third up must be +3 semitones");
        presetRule = HarmonyPlanner::ruleForPreset(HarmonyIntervalPreset::MajorThirdUp, custom);
        require(p.targetMidi(67.0f, presetRule, -1) == 71, "major third up must be +4 semitones");
        presetRule = HarmonyPlanner::ruleForPreset(HarmonyIntervalPreset::PerfectFourthUp, custom);
        require(p.targetMidi(67.0f, presetRule, -1) == 72, "perfect fourth up must be +5 semitones");
        presetRule = HarmonyPlanner::ruleForPreset(HarmonyIntervalPreset::PerfectFifthUp, custom);
        require(p.targetMidi(67.0f, presetRule, -1) == 74, "perfect fifth up must be +7 semitones");
        presetRule = HarmonyPlanner::ruleForPreset(HarmonyIntervalPreset::OctaveUp, custom);
        require(p.targetMidi(67.0f, presetRule, -1) == 79, "octave up must be +12 semitones");
        presetRule = HarmonyPlanner::ruleForPreset(HarmonyIntervalPreset::OctaveDown, custom);
        require(p.targetMidi(67.0f, presetRule, -1) == 55, "octave down must be -12 semitones");

        const int chord[] = {60, 64, 67};
        p.setKey(0, ScaleType::Major);
        p.setChordNotes(chord, 3);
        std::array<HarmonyVoiceRule, 4> rules {{
            {true, VoiceMode::ScaleDegree, 2, 0},
            {true, VoiceMode::ScaleDegree, -2, 0},
            {true, VoiceMode::ScaleDegree, 4, 0},
            {true, VoiceMode::ScaleDegree, 0, 1}
        }};
        std::array<int, 4> previous {{64, 55, 67, 72}};
        std::array<VoiceRange, 4> ranges {{{48,84},{43,79},{48,91},{60,108}}};
        const auto plan = p.planTargets(62.0f, rules, previous, ranges);
        for (int note : plan) {
            require(note >= 0 && note <= 127, "planned chord target range");
            const int pc = note % 12;
            require(pc == 0 || pc == 4 || pc == 7, "MIDI chord planner must choose chord tones");
        }
        require(!(plan[0] == plan[1] && plan[1] == plan[2]), "planner must avoid collapsing voices to one note");

        std::array<int, 8> manualChord{};
        const std::size_t manualCount = HarmonyPlanner::buildChordNotes(9, ChordType::Minor7, manualChord);
        require(manualCount == 4, "manual minor-7 chord size");
        const std::array<int, 4> expectedPc {{9, 0, 4, 7}};
        for (std::size_t i = 0; i < manualCount; ++i)
            require(manualChord[i] % 12 == expectedPc[i], "manual chord note construction");
    }

    {
        const auto a3 = runPitch(220.0);
        require(a3.voiced, "220 Hz harmonic signal must be voiced");
        require(std::abs(a3.frequencyHz - 220.0f) < 2.5f, "FFT-YIN accuracy at A3");
        const auto e4 = runPitch(329.627556);
        require(e4.voiced, "E4 harmonic signal must be voiced");
        require(std::abs(e4.frequencyHz - 329.627556f) < 3.0f, "FFT-YIN accuracy at E4");
    }

    {
        AutoKeyDetector detector;
        detector.prepare(48000.0);
        const std::array<float, 9> phrase {{60.0f, 60.0f, 67.0f, 60.0f, 64.0f, 67.0f, 65.0f, 67.0f, 60.0f}};
        for (int repeat = 0; repeat < 20; ++repeat)
            for (float note : phrase) detector.observe(note, 0.95f);
        const auto k = detector.estimate();
        require(k.root == 0, "auto-key C major root");
        require(k.scale == ScaleType::Major, "auto-key major/minor classification");
        require(k.confidence > 0.01f, "auto-key confidence must be live");
    }


    {
        constexpr double sr = 48000.0;
        PitchTracker tr;
        tr.prepare(sr);
        tr.setReferenceA4(442.0f);
        PitchEstimate e{};
        for (int n = 0; n < static_cast<int>(sr * 0.36); ++n) {
            const float x = 0.30f * std::sin(static_cast<float>(kTwoPi * 442.0 * n / sr));
            e = tr.processSample(x);
        }
        require(e.voiced, "442 Hz tuned A4 must be voiced");
        require(std::abs(e.midiNote - 69.0f) < 0.12f, "A4 tuning reference must affect pitch mapping");
    }

    {
        constexpr double sr = 48000.0;
        MultiVoiceVocoder v;
        v.prepare(sr, 2048, 512);
        v.setVoicePitchRatio(0, 1.0f);
        v.setFormantPreserve(1.0f);
        v.setTransientProtection(0.85f);
        v.setUnvoicedPreserve(0.92f);
        std::vector<float> out(static_cast<std::size_t>(sr * 0.50), 0.0f);
        for (std::size_t n = 0; n < out.size(); ++n) {
            const float in = 0.2f * std::sin(static_cast<float>(kTwoPi * 220.0 * static_cast<double>(n) / sr));
            out[n] = v.processSample(in)[0];
        }
        require(rms(out, 6000) > 0.02, "vocoder unity ratio must produce audio");
        const double f = estimateFrequencyZeroCross(out, sr, 9000);
        require(f > 205.0 && f < 235.0, "vocoder unity ratio pitch must remain near 220 Hz");
    }

    {
        constexpr double sr = 48000.0;
        // Full visible interval/octave range requires the pitch engine to accept
        // ratios well beyond one octave. These checks prevent a hidden clamp
        // from making the extreme GUI settings dead.
        MultiVoiceVocoder up;
        up.prepare(sr, 2048, 512);
        up.setVoicePitchRatio(0, 4.0f); // +24 semitones
        up.setFormantPreserve(0.0f);
        std::vector<float> upOut(static_cast<std::size_t>(sr * 0.45), 0.0f);
        for (std::size_t n = 0; n < upOut.size(); ++n) {
            const float in = 0.18f * std::sin(static_cast<float>(kTwoPi * 220.0 * static_cast<double>(n) / sr));
            upOut[n] = up.processSample(in)[0];
        }
        require(rms(upOut, 9000) > 0.001, "multi-octave upward ratio must produce audio");

        MultiVoiceVocoder down;
        down.prepare(sr, 2048, 512);
        down.setVoicePitchRatio(0, 0.25f); // -24 semitones
        down.setFormantPreserve(0.0f);
        std::vector<float> downOut(static_cast<std::size_t>(sr * 0.45), 0.0f);
        for (std::size_t n = 0; n < downOut.size(); ++n) {
            const float in = 0.18f * std::sin(static_cast<float>(kTwoPi * 440.0 * static_cast<double>(n) / sr));
            downOut[n] = down.processSample(in)[0];
        }
        require(rms(downOut, 9000) > 0.001, "multi-octave downward ratio must produce audio");
    }

    {
        constexpr double sr = 48000.0;
        HarmonyProcessor hp;
        hp.prepare(sr);
        ProcessorParams pp;
        pp.mode = HarmonyMode::MidiChord;
        pp.keyRoot = 0;
        pp.scale = ScaleType::Major;
        pp.tightness = 0.1f;
        pp.dryDb = -60.0f;
        pp.wetDb = -3.0f;
        pp.humanize = 0.25f;
        pp.voices[0].rule = {true, VoiceMode::ScaleDegree, 2, 0};
        pp.voices[0].levelDb = -3.0f;
        pp.voices[0].pan = -0.4f;
        pp.voices[0].delayMs = 6.0f;
        pp.voices[0].choirVoices = 4;
        pp.voices[0].choirSpread = 0.8f;
        pp.voices[0].choirDepth = 0.55f;
        pp.voices[0].vibratoCents = 7.0f;
        pp.voices[0].vibratoRateHz = 5.1f;
        pp.voices[1].rule = {true, VoiceMode::ScaleDegree, -2, 0};
        pp.voices[1].levelDb = -5.0f;
        pp.voices[1].pan = 0.4f;
        hp.setParams(pp);
        const int chord[] = {60, 64, 67};
        hp.setChordNotes(chord, 3);
        std::vector<float> in(26000), l(26000), r(26000);
        for (std::size_t n = 0; n < in.size(); ++n)
            in[n] = 0.2f * std::sin(static_cast<float>(kTwoPi * 261.625565 * static_cast<double>(n) / sr));
        hp.processBlock(in.data(), l.data(), r.data(), in.size());
        require(rms(l, 9000) > 0.002, "harmony processor must produce wet audio");
        require(rms(r, 9000) > 0.002, "stereo harmony processor must produce right audio");
        require(hp.latencySamples() == 512, "48 kHz low-latency vocal STFT must be 512 samples");
        require(hp.pitchEstimate().voiced, "processor pitch tracker must be active");
        const auto targets = hp.targetNotes();
        require(targets[0] >= 0 && targets[1] >= 0, "enabled voices must have target notes");
        const auto meters = hp.meters();
        require(meters.inputPeak > 0.05f, "input meter must report real signal");
        require(meters.outputPeakL > 0.001f && meters.outputPeakR > 0.001f, "output meters must report real signal");
        require(meters.voicePeak[0] > 0.001f, "voice meter must report real generated audio");
    }

    {
        constexpr double sr = 48000.0;
        HarmonyProcessor hp;
        hp.prepare(sr);
        ProcessorParams pp;
        pp.mode = HarmonyMode::KeyScale;
        pp.keyRoot = 0;
        pp.scale = ScaleType::Major;
        pp.dryDb = -60.0f;
        pp.wetDb = -3.0f;
        pp.voices[0].rule.enabled = true;
        pp.voices[0].preset = HarmonyIntervalPreset::ScaleThirdUp;
        hp.setParams(pp);

        std::vector<float> in(22000), l(22000), r(22000);
        for (std::size_t n = 0; n < in.size(); ++n)
            in[n] = 0.2f * std::sin(static_cast<float>(kTwoPi * 261.625565 * static_cast<double>(n) / sr));
        hp.processBlock(in.data(), l.data(), r.data(), in.size());
        const int thirdTarget = hp.targetNotes()[0];
        require(thirdTarget == 64, "scale-third preset must target E over C in C major");

        pp.voices[0].preset = HarmonyIntervalPreset::PerfectFifthUp;
        hp.setParams(pp);
        hp.processBlock(in.data(), l.data(), r.data(), in.size());
        const int fifthTarget = hp.targetNotes()[0];
        require(fifthTarget == 67, "preset parameter change must immediately replan to perfect fifth");
    }

    {
        constexpr double sr = 48000.0;
        HarmonyProcessor hp;
        hp.prepare(sr);
        ProcessorParams pp;
        pp.dryDb = -60.0f;
        pp.wetDb = 0.0f;
        pp.voices[0].rule = {true, VoiceMode::ScaleDegree, 2, 0};
        pp.voices[0].levelDb = 0.0f;
        pp.voices[0].mute = true;
        hp.setParams(pp);
        std::vector<float> in(18000), l(18000), r(18000);
        for (std::size_t n = 0; n < in.size(); ++n)
            in[n] = 0.2f * std::sin(static_cast<float>(kTwoPi * 220.0 * static_cast<double>(n) / sr));
        hp.processBlock(in.data(), l.data(), r.data(), in.size());
        require(hp.meters().voicePeak[0] < 1.0e-5f, "muted voice meter must not report inaudible signal");
    }

    {
        const float loose = harmonyExpressionFollow(0.0f);
        const float musical = harmonyExpressionFollow(0.55f);
        const float independent = harmonyExpressionFollow(1.0f);
        require(loose < 0.45f, "even loose harmony must not clone lead bends one-to-one");
        require(musical < 0.30f, "default harmony must follow less than 30 percent of lead micro-pitch");
        require(independent < musical, "higher independence must reduce bend/vibrato following");
        require(harmonyExpressionTimeMs(0.55f) > 90.0f, "default harmony expression must be musically smoothed");
    }

    {
        constexpr double sr = 48000.0;
        HarmonyProcessor hp;
        hp.prepare(sr);
        ProcessorParams pp;
        pp.inputDb = 0.0f;
        pp.outputDb = 0.0f;
        pp.dryDb = 0.0f;
        pp.wetDb = 0.0f;
        for (auto& voice : pp.voices) voice.rule.enabled = false;
        hp.setParams(pp);

        std::vector<float> in(12000), l(12000), r(12000);
        for (std::size_t n = 0; n < in.size(); ++n)
            in[n] = 0.21f * std::sin(static_cast<float>(kTwoPi * 311.126984 * static_cast<double>(n) / sr));
        hp.processBlock(in.data(), l.data(), r.data(), in.size());

        const std::size_t latency = static_cast<std::size_t>(hp.latencySamples());
        float maxError = 0.0f;
        for (std::size_t n = latency + 64; n < in.size(); ++n) {
            const float expected = in[n - latency];
            maxError = std::max(maxError, std::abs(l[n] - expected));
            maxError = std::max(maxError, std::abs(r[n] - expected));
        }
        require(maxError < 1.0e-5f, "inactive harmony dry path must remain unity gain");
    }

    {
        HarmonyProcessor hp;
        hp.prepare(48000.0);
        require(hp.latencySamples() == 512, "48 kHz low-latency vocal window");
        hp.prepare(96000.0);
        require(hp.latencySamples() == 1024, "96 kHz low-latency vocal window");
        hp.prepare(192000.0);
        require(hp.latencySamples() == 2048, "192 kHz low-latency vocal window");
    }

    std::cout << "HarmonyEngine DSP tests: PASS\n";
    return 0;
}
