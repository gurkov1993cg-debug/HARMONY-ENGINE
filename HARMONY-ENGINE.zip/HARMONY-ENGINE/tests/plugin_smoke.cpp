#include "PluginProcessor.h"
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <memory>

namespace {
void require(bool ok, const char* message) {
    if (!ok) {
        std::cerr << "FAIL: " << message << '\n';
        std::exit(1);
    }
}
}

int main() {
    juce::ScopedJuceInitialiser_GUI initialiseJuce;

    HarmonyEngineAudioProcessor processor;
    processor.setPlayConfigDetails(2, 2, 48000.0, 512);
    processor.prepareToPlay(48000.0, 512);
    require(processor.getLatencySamples() == 1024, "reported latency must match the 48 kHz live engine");

    juce::AudioBuffer<float> buffer(2, 512);
    juce::MidiBuffer midi;
    double phase = 0.0;
    const double phaseStep = 2.0 * juce::MathConstants<double>::pi * 220.0 / 48000.0;

    for (int block = 0; block < 120; ++block) {
        for (int sample = 0; sample < buffer.getNumSamples(); ++sample) {
            const float x = 0.15f * static_cast<float>(std::sin(phase));
            phase += phaseStep;
            if (phase >= 2.0 * juce::MathConstants<double>::pi)
                phase -= 2.0 * juce::MathConstants<double>::pi;
            buffer.setSample(0, sample, x);
            buffer.setSample(1, sample, x);
        }
        processor.processBlock(buffer, midi);
        for (int channel = 0; channel < buffer.getNumChannels(); ++channel) {
            const float* samples = buffer.getReadPointer(channel);
            for (int sample = 0; sample < buffer.getNumSamples(); ++sample)
                require(std::isfinite(samples[sample]), "processor output must remain finite");
        }
    }

    juce::MemoryBlock state;
    processor.getStateInformation(state);
    require(state.getSize() > 0, "plugin state must serialize");
    processor.setStateInformation(state.getData(), static_cast<int>(state.getSize()));

    for (int cycle = 0; cycle < 3; ++cycle) {
        std::unique_ptr<juce::AudioProcessorEditor> editor(processor.createEditor());
        require(editor != nullptr, "editor must construct");
        require(editor->getWidth() == 1280 && editor->getHeight() == 800,
                "editor must use the production lightweight size");
    }

    processor.releaseResources();
    std::cout << "HarmonyEngine plugin smoke test: PASS\n";
    return 0;
}
