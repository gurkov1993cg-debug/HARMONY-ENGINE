#include "Parameters.h"
#include "AuditionLogic.h"
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <set>

using namespace harmonyplugin;

static void require(bool ok, const char* message) {
    if (!ok) {
        std::cerr << "FAIL: " << message << '\n';
        std::exit(1);
    }
}

int main() {
    const auto& specs = parameterSpecs();
    require(!specs.empty(), "parameter list must not be empty");

    std::set<std::uint32_t> ids;
    int editable = 0;
    int meters = 0;
    for (const auto& s : specs) {
        require(s.id < kParamStorageSize, "parameter id must fit storage");
        require(ids.insert(s.id).second, "parameter IDs must be unique");
        require(s.maxPlain >= s.minPlain, "parameter range must be valid");
        require(s.defaultPlain >= s.minPlain && s.defaultPlain <= s.maxPlain, "default must be in range");
        const double n = defaultNormalized(s);
        require(n >= 0.0 && n <= 1.0, "normalized default must be valid");
        const double roundtrip = denormalize(s, normalizePlain(s, s.defaultPlain));
        require(std::abs(roundtrip - s.defaultPlain) < 0.051, "default roundtrip");
        if (s.readOnly) ++meters; else ++editable;
    }

    require(editable == 102, "expected 102 real editable parameters");
    require(meters == 16, "expected 16 real read-only signal/status parameters");

    const std::uint32_t globals[] = {
        kBypass,kInputDb,kOutputDb,kDryDb,kWetDb,kHarmonyWidth,kTuningHz,kMode,kKey,kScale,
        kChordRoot,kChordType,kMidiChannel,kMidiHold,kAutoKeyThreshold,kTightness,kSmoothingMs,
        kHumanize,kFormantPreserve,kTransientProtect,kUnvoicedPreserve
    };
    for (auto id : globals) require(findSpec(id) != nullptr, "global parameter missing");

    for (int v = 0; v < 4; ++v) {
        for (int o = static_cast<int>(kVoiceEnable); o <= static_cast<int>(kVoiceHarmonyPreset); ++o)
            require(findSpec(voiceParamId(v, static_cast<VoiceParamOffset>(o))) != nullptr, "voice parameter missing");
    }

    const auto* keySpec = findSpec(kKey);
    require(keySpec && keySpec->choiceCount == 12, "key selector must expose all 12 tonalities");
    require(std::string(keySpec->choices[7]) == "G", "G must be directly available in key selector");

    const auto* scaleSpec = findSpec(kScale);
    require(scaleSpec && scaleSpec->choiceCount == 9, "scale selector must expose all supported modes");
    require(std::string(scaleSpec->choices[0]) == "Major", "major scale choice missing");
    require(std::string(scaleSpec->choices[1]) == "Natural Minor", "minor scale choice missing");

    const auto* presetSpec = findSpec(voiceParamId(0, kVoiceHarmonyPreset));
    require(presetSpec && presetSpec->choiceCount == 17, "harmony interval selector must expose all interval presets");

    {
        const auto* dry = findSpec(kDryDb);
        const auto* wet = findSpec(kWetDb);
        const auto* tight = findSpec(kTightness);
        const auto* glide = findSpec(kSmoothingMs);
        require(dry && dry->defaultPlain == 0.0, "inactive plug-in must default to unity dry");
        require(wet && wet->defaultPlain == 0.0, "harmony bus master default must be unity");
        require(tight && tight->defaultPlain == 55.0, "harmony independence default");
        require(glide && glide->defaultPlain == 28.0, "musical pitch glide default");
        for (int v = 0; v < 4; ++v) {
            const auto* enabled = findSpec(voiceParamId(v, kVoiceEnable));
            require(enabled && enabled->defaultPlain == 0.0, "all harmony voices must default off");
        }
    }



    {
        std::array<VoiceAuditionState, 4> voices{};
        auto d = decideAudition(voices, false);
        require(d.leadAudible && !d.harmonyActive, "with all harmonies off the lead must remain audible");

        voices[0].enabled = true;
        d = decideAudition(voices, false);
        require(d.voiceAudible[0] && d.harmonyActive, "enabled Voice 1 must be audible");

        voices[0].mute = true;
        d = decideAudition(voices, false);
        require(!d.voiceAudible[0] && !d.harmonyActive, "MUTE must silence its harmony voice");

        voices = {};
        voices[0].solo = true;
        d = decideAudition(voices, false);
        require(d.voiceAudible[0], "SOLO must audition a voice even when ON was off");
        require(!d.leadAudible, "SOLO must mute the original lead");

        voices[1].enabled = true;
        d = decideAudition(voices, false);
        require(d.voiceAudible[0] && !d.voiceAudible[1], "SOLO must isolate soloed harmony voices");

        voices = {};
        voices[0].enabled = true;
        d = decideAudition(voices, true);
        require(!d.leadAudible && d.voiceAudible[0], "LEAD MUTE must produce harmony-only output");
    }

    {
        const auto* leadMute = findSpec(kLeadMute);
        require(leadMute != nullptr, "Lead Mute parameter must exist");
        require(leadMute->kind == ParamKind::Toggle, "Lead Mute must be a toggle");
        require(leadMute->defaultPlain == 0.0, "Lead Mute must default off");
    }
    std::cout << "HarmonyEngine parameter contract: PASS (102 editable + 16 real meters/status)\n";

    {
        const auto* width = findSpec(kHarmonyWidth);
        require(width != nullptr, "Harmony Width parameter must exist");
        require(std::abs(width->defaultPlain - 0.0) < 1.0e-12,
                "fresh plug-in must not stereo-widen a mono harmony by default");

        for (int v = 0; v < 4; ++v) {
            const auto* pan = findSpec(voiceParamId(v, kVoicePan));
            const auto* choir = findSpec(voiceParamId(v, kVoiceChoirVoices));
            const auto* spread = findSpec(voiceParamId(v, kVoiceChoirSpread));
            const auto* depth = findSpec(voiceParamId(v, kVoiceChoirDepth));
            require(pan && std::abs(pan->defaultPlain) < 1.0e-12,
                    "every fresh harmony voice must default to center pan");
            require(choir && std::abs(choir->defaultPlain) < 1.0e-12,
                    "every fresh harmony voice must default to one choir voice");
            require(spread && std::abs(spread->defaultPlain) < 1.0e-12,
                    "every fresh harmony voice must default to zero choir spread");
            require(depth && std::abs(depth->defaultPlain) < 1.0e-12,
                    "every fresh harmony voice must default to zero choir depth");
        }
    }

    return 0;
}
