#include "Parameters.h"
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <set>

using namespace harmonyplugin;

static void require(bool ok, const char* message) {
    if (!ok) {
        std::cerr << "FAIL: " << message << '\n';
        std::exit(1);
    }
}

int main() {
    const auto& specs = parameterSpecs();
    require(!specs.empty(), "parameter list must not be empty");

    std::set<std::uint32_t> ids;
    int editable = 0;
    int meters = 0;
    for (const auto& s : specs) {
        require(s.id < kParamStorageSize, "parameter id must fit storage");
        require(ids.insert(s.id).second, "parameter IDs must be unique");
        require(s.maxPlain >= s.minPlain, "parameter range must be valid");
        require(s.defaultPlain >= s.minPlain && s.defaultPlain <= s.maxPlain, "default must be in range");
        const double n = defaultNormalized(s);
        require(n >= 0.0 && n <= 1.0, "normalized default must be valid");
        const double roundtrip = denormalize(s, normalizePlain(s, s.defaultPlain));
        require(std::abs(roundtrip - s.defaultPlain) < 0.051, "default roundtrip");
        if (s.readOnly) ++meters; else ++editable;
    }

    require(editable == 101, "expected 101 real editable parameters");
    require(meters == 16, "expected 16 real read-only signal/status parameters");

    const std::uint32_t globals[] = {
        kBypass,kInputDb,kOutputDb,kDryDb,kWetDb,kHarmonyWidth,kTuningHz,kMode,kKey,kScale,
        kChordRoot,kChordType,kMidiChannel,kMidiHold,kAutoKeyThreshold,kTightness,kSmoothingMs,
        kHumanize,kFormantPreserve,kTransientProtect,kUnvoicedPreserve
    };
    for (auto id : globals) require(findSpec(id) != nullptr, "global parameter missing");

    for (int v = 0; v < 4; ++v) {
        for (int o = static_cast<int>(kVoiceEnable); o <= static_cast<int>(kVoiceHarmonyPreset); ++o)
            require(findSpec(voiceParamId(v, static_cast<VoiceParamOffset>(o))) != nullptr, "voice parameter missing");
    }

    const auto* keySpec = findSpec(kKey);
    require(keySpec && keySpec->choiceCount == 12, "key selector must expose all 12 tonalities");
    require(std::string(keySpec->choices[7]) == "G", "G must be directly available in key selector");

    const auto* scaleSpec = findSpec(kScale);
    require(scaleSpec && scaleSpec->choiceCount == 9, "scale selector must expose all supported modes");
    require(std::string(scaleSpec->choices[0]) == "Major", "major scale choice missing");
    require(std::string(scaleSpec->choices[1]) == "Natural Minor", "minor scale choice missing");

    const auto* presetSpec = findSpec(voiceParamId(0, kVoiceHarmonyPreset));
    require(presetSpec && presetSpec->choiceCount == 17, "harmony interval selector must expose all interval presets");

    std::cout << "HarmonyEngine parameter contract: PASS (101 editable + 16 real meters/status)\n";
    return 0;
}
