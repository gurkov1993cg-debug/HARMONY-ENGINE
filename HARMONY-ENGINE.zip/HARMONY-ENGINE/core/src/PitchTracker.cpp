#include "harmony/PitchTracker.h"
#include "harmony/AudioMath.h"
#include <algorithm>
#include <cmath>
#include <limits>

namespace harmony {
namespace {
std::size_t nextPowerOfTwo(std::size_t n) noexcept {
    std::size_t p = 1U;
    while (p < n) p <<= 1U;
    return p;
}
}

void PitchTracker::prepare(double sampleRate, float minHz, float maxHz) {
    sampleRate_ = std::max(8000.0, sampleRate);
    minHz_ = std::clamp(minHz, 40.0f, 300.0f);
    maxHz_ = std::clamp(maxHz, minHz_ + 1.0f, 2000.0f);

    const std::size_t minNeeded = static_cast<std::size_t>(std::ceil(2.75 * sampleRate_ / minHz_));
    windowSize_ = nextPowerOfTwo(minNeeded);
    windowSize_ = std::clamp<std::size_t>(windowSize_, 1024U, 4096U);
    fftSize_ = nextPowerOfTwo(windowSize_ * 2U);
    fft_.setSize(fftSize_);

    ring_.assign(windowSize_, 0.0f);
    frame_.assign(windowSize_, 0.0f);
    prefixEnergy_.assign(windowSize_ + 1U, 0.0);
    const std::size_t tauMax = static_cast<std::size_t>(std::ceil(sampleRate_ / minHz_)) + 4U;
    difference_.assign(tauMax + 2U, 0.0f);
    cmnd_.assign(tauMax + 2U, 1.0f);
    fftBuffer_.assign(fftSize_, {});

    analysisHop_ = std::max<std::size_t>(128U, static_cast<std::size_t>(std::lround(sampleRate_ * 0.005))); // ~5 ms
    reset();
}

void PitchTracker::reset() {
    std::fill(ring_.begin(), ring_.end(), 0.0f);
    std::fill(frame_.begin(), frame_.end(), 0.0f);
    std::fill(prefixEnergy_.begin(), prefixEnergy_.end(), 0.0);
    std::fill(difference_.begin(), difference_.end(), 0.0f);
    std::fill(cmnd_.begin(), cmnd_.end(), 1.0f);
    std::fill(fftBuffer_.begin(), fftBuffer_.end(), std::complex<float>{});
    writePos_ = 0;
    samplesSinceAnalysis_ = 0;
    latest_ = {};
    smoothedMidi_ = 69.0f;
    previousRawMidi_ = 69.0f;
    haveSmoothed_ = false;
    unvoicedAnalyses_ = 0;
    rawMidiHistory_.fill(69.0f);
    rawMidiHistoryCount_ = 0;
    rawMidiHistoryWrite_ = 0;
    serial_ = 0;
}

PitchEstimate PitchTracker::processSample(float x) {
    if (ring_.empty()) return latest_;
    ring_[writePos_] = x;
    writePos_ = (writePos_ + 1U) % ring_.size();
    if (++samplesSinceAnalysis_ >= analysisHop_) {
        samplesSinceAnalysis_ = 0;
        latest_ = analyse();
    }
    return latest_;
}

PitchEstimate PitchTracker::analyse() {
    PitchEstimate out{};
    out.analysisSerial = ++serial_;
    const std::size_t n = windowSize_;
    if (n < 64U || fftBuffer_.size() != fftSize_) return out;

    // Reconstruct chronological frame from the circular buffer.
    for (std::size_t i = 0; i < n; ++i) frame_[i] = ring_[(writePos_ + i) % n];

    prefixEnergy_[0] = 0.0;
    for (std::size_t i = 0; i < n; ++i) {
        const double s = static_cast<double>(frame_[i]);
        prefixEnergy_[i + 1U] = prefixEnergy_[i] + s * s;
    }
    out.rms = static_cast<float>(std::sqrt(prefixEnergy_[n] / static_cast<double>(n)));
    if (out.rms < 1.2e-4f) return out;

    // FFT autocorrelation. This replaces the O(N*tau) YIN difference loop,
    // which is important for the 2011 Intel target.
    std::fill(fftBuffer_.begin(), fftBuffer_.end(), std::complex<float>{});
    for (std::size_t i = 0; i < n; ++i) fftBuffer_[i] = {frame_[i], 0.0f};
    fft_.forward(fftBuffer_);
    for (auto& z : fftBuffer_) z = {std::norm(z), 0.0f};
    fft_.inverse(fftBuffer_);

    const int tauMin = std::max(2, static_cast<int>(std::floor(sampleRate_ / maxHz_)));
    const int tauMax = std::min(static_cast<int>(n / 2U - 2U),
                                static_cast<int>(std::ceil(sampleRate_ / minHz_)));
    if (tauMax <= tauMin + 2 || difference_.size() <= static_cast<std::size_t>(tauMax + 1)) return out;

    difference_[0] = 0.0f;
    cmnd_[0] = 1.0f;
    double running = 0.0;
    for (int tau = 1; tau <= tauMax + 1; ++tau) {
        const std::size_t t = static_cast<std::size_t>(tau);
        const double e0 = prefixEnergy_[n - t] - prefixEnergy_[0];
        const double e1 = prefixEnergy_[n] - prefixEnergy_[t];
        const double corr = static_cast<double>(fftBuffer_[t].real());
        const double d = std::max(0.0, e0 + e1 - 2.0 * corr);
        difference_[t] = static_cast<float>(d);
        running += d;
        cmnd_[t] = running > 1.0e-20
            ? static_cast<float>(d * static_cast<double>(tau) / running)
            : 1.0f;
    }

    constexpr float threshold = 0.11f;
    int bestTau = -1;
    for (int tau = tauMin; tau <= tauMax; ++tau) {
        if (cmnd_[static_cast<std::size_t>(tau)] < threshold) {
            bestTau = tau;
            while (bestTau + 1 <= tauMax &&
                   cmnd_[static_cast<std::size_t>(bestTau + 1)] < cmnd_[static_cast<std::size_t>(bestTau)]) {
                ++bestTau;
            }
            break;
        }
    }

    if (bestTau < 0) {
        float best = std::numeric_limits<float>::max();
        for (int tau = tauMin; tau <= tauMax; ++tau) {
            const float v = cmnd_[static_cast<std::size_t>(tau)];
            if (v < best) { best = v; bestTau = tau; }
        }
    }
    if (bestTau <= 1) return out;

    float refinedTau = static_cast<float>(bestTau);
    if (bestTau > tauMin && bestTau < tauMax) {
        const float y0 = cmnd_[static_cast<std::size_t>(bestTau - 1)];
        const float y1 = cmnd_[static_cast<std::size_t>(bestTau)];
        const float y2 = cmnd_[static_cast<std::size_t>(bestTau + 1)];
        const float denom = y0 - 2.0f * y1 + y2;
        if (std::abs(denom) > 1.0e-9f) refinedTau += 0.5f * (y0 - y2) / denom;
    }

    const float hz = static_cast<float>(sampleRate_) / std::max(refinedTau, 1.0f);
    if (!(hz >= minHz_ && hz <= maxHz_)) return out;

    float midi = 69.0f + 12.0f * std::log2(hz / std::max(referenceA4Hz_, 1.0f));
    const float yinConfidence = std::clamp(1.0f - cmnd_[static_cast<std::size_t>(bestTau)], 0.0f, 1.0f);
    const float levelConfidence = clamp01((out.rms - 0.001f) / 0.012f);
    out.confidence = yinConfidence * (0.65f + 0.35f * levelConfidence);
    out.voiced = out.confidence >= 0.58f && out.rms >= 0.0012f;

    // Phrase-safe tracking: never force a new phrase back into the register
    // of stale history. A short unvoiced gap resets the melodic trajectory.
    // A median-of-3 removes isolated raw glitches without locking octaves.
    const std::size_t resetAfterUnvoiced =
        std::max<std::size_t>(1U, static_cast<std::size_t>(
            std::lround(0.080 * sampleRate_ / static_cast<double>(analysisHop_))));

    if (!out.voiced) {
        ++unvoicedAnalyses_;
        if (unvoicedAnalyses_ >= resetAfterUnvoiced) {
            haveSmoothed_ = false;
            rawMidiHistoryCount_ = 0;
            rawMidiHistoryWrite_ = 0;
        }
        out.midiNote = midi;
        out.frequencyHz = hz;
        return out;
    }

    if (unvoicedAnalyses_ >= resetAfterUnvoiced) {
        haveSmoothed_ = false;
        rawMidiHistoryCount_ = 0;
        rawMidiHistoryWrite_ = 0;
    }
    unvoicedAnalyses_ = 0;

    rawMidiHistory_[rawMidiHistoryWrite_] = midi;
    rawMidiHistoryWrite_ = (rawMidiHistoryWrite_ + 1U) % rawMidiHistory_.size();
    rawMidiHistoryCount_ = std::min<std::size_t>(rawMidiHistoryCount_ + 1U, rawMidiHistory_.size());

    float stableMidi = midi;
    if (rawMidiHistoryCount_ == rawMidiHistory_.size()) {
        std::array<float, 3> m = rawMidiHistory_;
        std::sort(m.begin(), m.end());
        stableMidi = m[1];
    }

    if (!haveSmoothed_) {
        smoothedMidi_ = stableMidi;
        previousRawMidi_ = stableMidi;
        haveSmoothed_ = true;
    } else {
        const float jump = std::abs(stableMidi - smoothedMidi_);
        const float rawVelocity = std::abs(stableMidi - previousRawMidi_);
        float alpha = 0.52f;
        if (jump > 7.0f) alpha = 0.72f;
        else if (jump > 3.0f) alpha = 0.60f;
        else if (rawVelocity < 0.25f) alpha = 0.42f;
        smoothedMidi_ += alpha * (stableMidi - smoothedMidi_);
        previousRawMidi_ = stableMidi;
    }

    out.midiNote = smoothedMidi_;
    out.frequencyHz = referenceA4Hz_ * std::pow(2.0f, (smoothedMidi_ - 69.0f) / 12.0f);
    return out;
}
}
