#include "harmony/FFT.h"
#include "harmony/AudioMath.h"
#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace harmony {
FFT::FFT(std::size_t size) { setSize(size); }

void FFT::setSize(std::size_t size) {
    if (size < 2 || (size & (size - 1U)) != 0U) throw std::invalid_argument("FFT size must be power of two");
    size_ = size;
    bitReverse_.resize(size_);
    std::size_t bits = 0;
    for (std::size_t n = size_; n > 1U; n >>= 1U) ++bits;
    for (std::size_t i = 0; i < size_; ++i) {
        std::size_t x = i;
        std::size_t r = 0;
        for (std::size_t b = 0; b < bits; ++b) { r = (r << 1U) | (x & 1U); x >>= 1U; }
        bitReverse_[i] = r;
    }
}

void FFT::forward(std::vector<std::complex<float>>& data) const { transform(data, false); }
void FFT::inverse(std::vector<std::complex<float>>& data) const { transform(data, true); }

void FFT::transform(std::vector<std::complex<float>>& data, bool inverse) const {
    if (data.size() != size_) data.resize(size_);
    for (std::size_t i = 0; i < size_; ++i) {
        const std::size_t j = bitReverse_[i];
        if (j > i) std::swap(data[i], data[j]);
    }
    for (std::size_t len = 2; len <= size_; len <<= 1U) {
        const float angle = (inverse ? 1.0f : -1.0f) * kTwoPi / static_cast<float>(len);
        const std::complex<float> wLen(std::cos(angle), std::sin(angle));
        for (std::size_t i = 0; i < size_; i += len) {
            std::complex<float> w(1.0f, 0.0f);
            const std::size_t half = len >> 1U;
            for (std::size_t j = 0; j < half; ++j) {
                const std::complex<float> u = data[i + j];
                const std::complex<float> v = data[i + j + half] * w;
                data[i + j] = u + v;
                data[i + j + half] = u - v;
                w *= wLen;
            }
        }
    }
    if (inverse) {
        const float inv = 1.0f / static_cast<float>(size_);
        for (auto& x : data) x *= inv;
    }
}
}
