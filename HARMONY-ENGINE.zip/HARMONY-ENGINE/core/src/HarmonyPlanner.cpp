#include "harmony/HarmonyPlanner.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <limits>

namespace harmony {
std::array<int, 7> HarmonyPlanner::intervalsFor(ScaleType type) noexcept {
    switch (type) {
        case ScaleType::Major:         return {0,2,4,5,7,9,11};
        case ScaleType::NaturalMinor:  return {0,2,3,5,7,8,10};
        case ScaleType::HarmonicMinor: return {0,2,3,5,7,8,11};
        case ScaleType::MelodicMinor:  return {0,2,3,5,7,9,11};
        case ScaleType::Dorian:        return {0,2,3,5,7,9,10};
        case ScaleType::Phrygian:      return {0,1,3,5,7,8,10};
        case ScaleType::Lydian:        return {0,2,4,6,7,9,11};
        case ScaleType::Mixolydian:    return {0,2,4,5,7,9,10};
        case ScaleType::Locrian:       return {0,1,3,5,6,8,10};
    }
    return {0,2,4,5,7,9,11};
}


std::size_t HarmonyPlanner::buildChordNotes(int rootPitchClass, ChordType type, std::array<int, 8>& notes) noexcept {
    const int root = ((rootPitchClass % 12) + 12) % 12;
    std::array<int, 5> intervals{};
    std::size_t count = 0;
    switch (type) {
        case ChordType::Major:           intervals = {0,4,7,0,0}; count = 3; break;
        case ChordType::Minor:           intervals = {0,3,7,0,0}; count = 3; break;
        case ChordType::Diminished:      intervals = {0,3,6,0,0}; count = 3; break;
        case ChordType::Augmented:       intervals = {0,4,8,0,0}; count = 3; break;
        case ChordType::Sus2:            intervals = {0,2,7,0,0}; count = 3; break;
        case ChordType::Sus4:            intervals = {0,5,7,0,0}; count = 3; break;
        case ChordType::Major7:          intervals = {0,4,7,11,0}; count = 4; break;
        case ChordType::Minor7:          intervals = {0,3,7,10,0}; count = 4; break;
        case ChordType::Dominant7:       intervals = {0,4,7,10,0}; count = 4; break;
        case ChordType::HalfDiminished7: intervals = {0,3,6,10,0}; count = 4; break;
        case ChordType::Diminished7:     intervals = {0,3,6,9,0}; count = 4; break;
        case ChordType::Add9:            intervals = {0,4,7,14,0}; count = 4; break;
        case ChordType::MinorAdd9:       intervals = {0,3,7,14,0}; count = 4; break;
        case ChordType::Major6:          intervals = {0,4,7,9,0}; count = 4; break;
        case ChordType::Minor6:          intervals = {0,3,7,9,0}; count = 4; break;
    }
    notes.fill(0);
    for (std::size_t i = 0; i < count; ++i) notes[i] = 60 + root + intervals[i];
    return count;
}

void HarmonyPlanner::setKey(int rootPitchClass, ScaleType scale) noexcept {
    root_ = ((rootPitchClass % 12) + 12) % 12;
    scale_ = intervalsFor(scale);
}

void HarmonyPlanner::setChordNotes(const int* notes, std::size_t count) noexcept {
    chordCount_ = std::min<std::size_t>(count, chordNotes_.size());
    for (std::size_t i = 0; i < chordCount_; ++i) chordNotes_[i] = std::clamp(notes[i], 0, 127);
    std::sort(chordNotes_.begin(), chordNotes_.begin() + static_cast<std::ptrdiff_t>(chordCount_));

    chordPitchClassCount_ = 0;
    std::array<bool, 12> used{};
    for (std::size_t i = 0; i < chordCount_; ++i) {
        const int pc = chordNotes_[i] % 12;
        if (!used[static_cast<std::size_t>(pc)]) {
            used[static_cast<std::size_t>(pc)] = true;
            chordPitchClasses_[chordPitchClassCount_++] = pc;
        }
    }
}

int HarmonyPlanner::quantizeLeadMidi(float inputMidi) const noexcept {
    const int centre = static_cast<int>(std::lround(inputMidi));
    int bestMidi = centre;
    float bestDist = std::numeric_limits<float>::max();
    for (int m = centre - 12; m <= centre + 12; ++m) {
        const int pc = ((m - root_) % 12 + 12) % 12;
        bool allowed = false;
        for (int x : scale_) if (x == pc) { allowed = true; break; }
        if (!allowed) continue;
        const float d = std::abs(static_cast<float>(m) - inputMidi);
        if (d < bestDist) { bestDist = d; bestMidi = m; }
    }
    return bestMidi;
}

int HarmonyPlanner::degreeIndexForMidi(int midi) const noexcept {
    const int quant = quantizeLeadMidi(static_cast<float>(midi));
    const int rel = quant - root_;
    const int oct = static_cast<int>(std::floor(static_cast<double>(rel) / 12.0));
    const int pc = ((rel % 12) + 12) % 12;
    int degree = 0;
    int best = 99;
    for (int i = 0; i < 7; ++i) {
        const int d = std::abs(scale_[static_cast<std::size_t>(i)] - pc);
        if (d < best) { best = d; degree = i; }
    }
    return oct * 7 + degree;
}

int HarmonyPlanner::midiForScaleIndex(int scaleIndex) const noexcept {
    int oct = scaleIndex / 7;
    int deg = scaleIndex % 7;
    if (deg < 0) { deg += 7; --oct; }
    return root_ + oct * 12 + scale_[static_cast<std::size_t>(deg)];
}

int HarmonyPlanner::desiredTarget(float inputMidi, const HarmonyVoiceRule& rule) const noexcept {
    const int lead = quantizeLeadMidi(inputMidi);
    if (rule.mode == VoiceMode::ChromaticSemitone)
        return lead + rule.interval + rule.octave * 12;
    if (rule.mode == VoiceMode::ChordTone && chordPitchClassCount_ > 0) {
        // In chord-tone mode interval means ordered chord-tone offset relative
        // to the nearest chord tone above/below the lead.
        int nearestIndex = 0;
        int nearestDistance = 999;
        for (std::size_t i = 0; i < chordPitchClassCount_; ++i) {
            const int pc = chordPitchClasses_[i];
            for (int oct = -1; oct <= 1; ++oct) {
                const int candidate = (lead / 12 + oct) * 12 + pc;
                const int d = std::abs(candidate - lead);
                if (d < nearestDistance) { nearestDistance = d; nearestIndex = static_cast<int>(i); }
            }
        }
        const int n = static_cast<int>(chordPitchClassCount_);
        int index = nearestIndex + rule.interval;
        int octaveCarry = 0;
        while (index < 0) { index += n; --octaveCarry; }
        while (index >= n) { index -= n; ++octaveCarry; }
        const int pc = chordPitchClasses_[static_cast<std::size_t>(index)];
        int target = (lead / 12) * 12 + pc;
        while (target - lead > 6) target -= 12;
        while (lead - target > 6) target += 12;
        return target + (octaveCarry + rule.octave) * 12;
    }
    return midiForScaleIndex(degreeIndexForMidi(lead) + rule.interval) + rule.octave * 12;
}

int HarmonyPlanner::clampToRangeByOctave(int target, VoiceRange range, int reference) const noexcept {
    if (range.minMidi > range.maxMidi) std::swap(range.minMidi, range.maxMidi);
    range.minMidi = std::clamp(range.minMidi, 0, 127);
    range.maxMidi = std::clamp(range.maxMidi, 0, 127);
    int best = std::clamp(target, range.minMidi, range.maxMidi);
    int bestCost = std::numeric_limits<int>::max();
    for (int k = -6; k <= 6; ++k) {
        const int candidate = target + 12 * k;
        if (candidate < range.minMidi || candidate > range.maxMidi) continue;
        const int cost = std::abs(candidate - reference);
        if (cost < bestCost) { bestCost = cost; best = candidate; }
    }
    return best;
}

int HarmonyPlanner::targetMidi(float inputMidi,
                               const HarmonyVoiceRule& rule,
                               int previousTarget,
                               VoiceRange range) const noexcept {
    if (!rule.enabled) return -1;
    const int desired = desiredTarget(inputMidi, rule);

    if (chordPitchClassCount_ == 0 || rule.mode == VoiceMode::ChromaticSemitone) {
        const int reference = previousTarget >= 0 ? previousTarget : desired;
        return clampToRangeByOctave(desired, range, reference);
    }

    int best = desired;
    float bestCost = std::numeric_limits<float>::max();
    for (std::size_t i = 0; i < chordPitchClassCount_; ++i) {
        const int pc = chordPitchClasses_[i];
        for (int m = range.minMidi; m <= range.maxMidi; ++m) {
            if ((m % 12 + 12) % 12 != pc) continue;
            float cost = 4.0f * static_cast<float>(std::abs(m - desired));
            if (previousTarget >= 0) {
                const int move = std::abs(m - previousTarget);
                cost += 1.6f * static_cast<float>(move);
                if (move > 7) cost += 1.4f * static_cast<float>((move - 7) * (move - 7));
            }
            if (cost < bestCost) { bestCost = cost; best = m; }
        }
    }
    return std::clamp(best, range.minMidi, range.maxMidi);
}

std::array<int, HarmonyPlanner::kVoices> HarmonyPlanner::planTargets(
    float inputMidi,
    const std::array<HarmonyVoiceRule, kVoices>& rules,
    const std::array<int, kVoices>& previousTargets,
    const std::array<VoiceRange, kVoices>& ranges) const noexcept {

    std::array<int, kVoices> desired{};
    std::array<int, kVoices> result{};
    result.fill(-1);
    for (std::size_t v = 0; v < kVoices; ++v) {
        desired[v] = rules[v].enabled ? desiredTarget(inputMidi, rules[v]) : -1;
    }

    // Without a MIDI chord, independent diatonic planning plus octave-aware
    // continuity is the musically correct behaviour.
    if (chordPitchClassCount_ == 0) {
        for (std::size_t v = 0; v < kVoices; ++v)
            result[v] = targetMidi(inputMidi, rules[v], previousTargets[v], ranges[v]);
        return result;
    }

    // Build a small candidate set for every voice: nearest chord tones to the
    // intended diatonic/chromatic target and to its previous register.
    constexpr std::size_t kMaxCandidates = 10;
    std::array<std::array<int, kMaxCandidates>, kVoices> candidates{};
    std::array<std::size_t, kVoices> candidateCount{};

    for (std::size_t v = 0; v < kVoices; ++v) {
        if (!rules[v].enabled) continue;
        const VoiceRange range = ranges[v];
        std::array<std::pair<int, int>, 128> ranked{};
        std::size_t rankedCount = 0;
        for (int m = std::max(0, range.minMidi); m <= std::min(127, range.maxMidi); ++m) {
            bool isChord = false;
            const int pc = (m % 12 + 12) % 12;
            for (std::size_t c = 0; c < chordPitchClassCount_; ++c)
                if (pc == chordPitchClasses_[c]) { isChord = true; break; }
            if (!isChord) continue;
            int cost = std::abs(m - desired[v]) * 8;
            if (previousTargets[v] >= 0) cost += std::abs(m - previousTargets[v]) * 3;
            ranked[rankedCount++] = {cost, m};
        }
        std::sort(ranked.begin(), ranked.begin() + static_cast<std::ptrdiff_t>(rankedCount),
                  [](const auto& a, const auto& b) { return a.first < b.first; });
        candidateCount[v] = std::min<std::size_t>(rankedCount, kMaxCandidates);
        for (std::size_t i = 0; i < candidateCount[v]; ++i) candidates[v][i] = ranked[i].second;
    }

    std::array<int, kVoices> current{};
    current.fill(-1);
    float bestCost = std::numeric_limits<float>::max();

    // Four voices and at most ten candidates each -> <= 10,000 combinations.
    // This is called only when the detected lead centre/chord changes, not per
    // sample, so the exhaustive search remains cheap and avoids greedy errors.
    const auto search = [&](auto&& self, std::size_t voice, float costSoFar) -> void {
        if (costSoFar >= bestCost) return;
        if (voice == kVoices) {
            bestCost = costSoFar;
            result = current;
            return;
        }
        if (!rules[voice].enabled) {
            current[voice] = -1;
            self(self, voice + 1U, costSoFar);
            return;
        }
        if (candidateCount[voice] == 0U) {
            current[voice] = targetMidi(inputMidi, rules[voice], previousTargets[voice], ranges[voice]);
            self(self, voice + 1U, costSoFar + 20.0f);
            return;
        }

        for (std::size_t ci = 0; ci < candidateCount[voice]; ++ci) {
            const int cand = candidates[voice][ci];
            float cost = costSoFar + 4.0f * static_cast<float>(std::abs(cand - desired[voice]));
            if (previousTargets[voice] >= 0) {
                const int movement = std::abs(cand - previousTargets[voice]);
                cost += 1.45f * static_cast<float>(movement);
                if (movement > 7) cost += 0.85f * static_cast<float>((movement - 7) * (movement - 7));
            }

            for (std::size_t p = 0; p < voice; ++p) {
                if (current[p] < 0) continue;
                if (cand == current[p]) cost += 80.0f; // avoid exact unison duplication
                else if ((cand % 12) == (current[p] % 12)) cost += 5.0f;

                const int desiredOrder = desired[voice] - desired[p];
                const int actualOrder = cand - current[p];
                if ((desiredOrder > 0 && actualOrder <= 0) ||
                    (desiredOrder < 0 && actualOrder >= 0)) {
                    cost += 26.0f + static_cast<float>(std::abs(actualOrder));
                }
                if (std::abs(actualOrder) < 3) cost += 8.0f;
            }

            current[voice] = cand;
            self(self, voice + 1U, cost);
        }
    };
    search(search, 0U, 0.0f);

    return result;
}
}
