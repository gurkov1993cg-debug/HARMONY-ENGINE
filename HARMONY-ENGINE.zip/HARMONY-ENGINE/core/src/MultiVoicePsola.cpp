#include "harmony/MultiVoicePsola.h"
#include "harmony/AudioMath.h"
#include <algorithm>
#include <cmath>

namespace harmony {

void MultiVoicePsola::prepare(double sampleRate) {
    sampleRate_ = std::max(8000.0, sampleRate);
    // Keep roughly the same analysis time in milliseconds at all rates while
    // avoiding the old 2048-sample synthesis delay.
    analysisSize_ = sampleRate_ <= 56000.0 ? 1024U
                  : sampleRate_ <= 112000.0 ? 2048U
                                           : 4096U;
    analysisHop_ = analysisSize_ / 4U;
    halfSize_ = analysisSize_ / 2U;
    fft_.setSize(analysisSize_);
    tableFft_.setSize(kTableSize);

    inputRing_.assign(analysisSize_, 0.0f);
    window_.resize(analysisSize_);
    windowSum_ = 0.0f;
    for (std::size_t n = 0; n < analysisSize_; ++n) {
        const float w = 0.5f - 0.5f * std::cos(kTwoPi * static_cast<float>(n) /
                                               static_cast<float>(analysisSize_));
        window_[n] = w;
        windowSum_ += w;
    }
    spectrum_.assign(analysisSize_, {});
    magnitude_.assign(halfSize_ + 1U, 0.0f);
    envelope_.assign(halfSize_ + 1U, 1.0e-7f);
    prefixLog_.assign(halfSize_ + 2U, 0.0);
    tableSpectrum_.assign(kTableSize, {});
    tableBlendStep_ = 1.0f / static_cast<float>(std::max<std::size_t>(1U, analysisHop_));
    reset();
}

void MultiVoicePsola::reset() {
    std::fill(inputRing_.begin(), inputRing_.end(), 0.0f);
    for (auto& t : tableCurrent_) t.fill(0.0f);
    for (auto& t : tableNext_) t.fill(0.0f);
    tableValid_.fill(false);
    inputWrite_ = 0;
    hopCounter_ = 0;
    tableBlend_ = 1.0f;
    phase_ = {{0.0f,0.17f,0.37f,0.61f}};
    frequencySmooth_.fill(220.0f);
    gainSmooth_.fill(1.0f);
    pitchHzTarget_ = 220.0f;
    pitchHzSmooth_ = 220.0f;
    pitchConfidenceTarget_ = 0.0f;
    confidenceSmooth_ = 0.0f;
    voicedTarget_ = false;
    voicedMix_ = 0.0f;
    analysedRms_ = 0.0f;
    fastEnergy_ = slowEnergy_ = 0.0f;
    highPassState_ = 0.0f;
    previousInput_ = 0.0f;
}

void MultiVoicePsola::setInputPitch(float frequencyHz, float confidence, bool voiced) noexcept {
    if (std::isfinite(frequencyHz) && frequencyHz > 20.0f)
        pitchHzTarget_ = std::clamp(frequencyHz, 65.0f, 1200.0f);
    pitchConfidenceTarget_ = std::clamp(confidence, 0.0f, 1.0f);
    voicedTarget_ = voiced;
}

void MultiVoicePsola::setVoiceActive(std::size_t voice, bool active) noexcept {
    if (voice >= kVoices) return;
    voiceActive_[voice] = active;
    if (!active) gainSmooth_[voice] = 0.0f;
}

void MultiVoicePsola::setVoicePitchRatio(std::size_t voice, float ratio) noexcept {
    if (voice >= kVoices || !std::isfinite(ratio)) return;
    pitchRatio_[voice] = std::clamp(ratio, 0.25f, 4.0f);
}

void MultiVoicePsola::setVoiceFormantSemitones(std::size_t voice, float semitones) noexcept {
    if (voice >= kVoices) return;
    formantRatio_[voice] = std::pow(2.0f, std::clamp(semitones, -12.0f, 12.0f) / 12.0f);
}

void MultiVoicePsola::setFormantPreserve(float amount) noexcept { formantPreserve_ = clamp01(amount); }
void MultiVoicePsola::setTransientProtection(float amount) noexcept { transientProtection_ = clamp01(amount); }
void MultiVoicePsola::setUnvoicedPreserve(float amount) noexcept { unvoicedPreserve_ = clamp01(amount); }

std::complex<float> MultiVoicePsola::spectrumAt(float bin) const noexcept {
    if (spectrum_.empty()) return {};
    bin = std::clamp(bin, 0.0f, static_cast<float>(halfSize_));
    const std::size_t i0 = static_cast<std::size_t>(std::floor(bin));
    const std::size_t i1 = std::min(i0 + 1U, halfSize_);
    const float f = bin - static_cast<float>(i0);
    return spectrum_[i0] * (1.0f - f) + spectrum_[i1] * f;
}


float MultiVoicePsola::magnitudeAt(float bin) const noexcept {
    if (magnitude_.empty()) return 0.0f;
    bin = std::clamp(bin, 0.0f, static_cast<float>(halfSize_));
    const std::size_t i0 = static_cast<std::size_t>(std::floor(bin));
    const std::size_t i1 = std::min(i0 + 1U, halfSize_);
    const float f = bin - static_cast<float>(i0);
    return magnitude_[i0] * (1.0f - f) + magnitude_[i1] * f;
}

float MultiVoicePsola::phaseAt(float bin) const noexcept {
    if (spectrum_.empty()) return 0.0f;
    bin = std::clamp(bin, 0.0f, static_cast<float>(halfSize_));
    const std::size_t i0 = static_cast<std::size_t>(std::floor(bin));
    const std::size_t i1 = std::min(i0 + 1U, halfSize_);
    // Pick the stronger adjacent FFT bin. Linear interpolation of complex FFT
    // bins can cancel badly for a sinusoid that lies between bins.
    const std::size_t i = magnitude_[i1] > magnitude_[i0] ? i1 : i0;
    return std::arg(spectrum_[i]);
}

float MultiVoicePsola::envelopeAt(float bin) const noexcept {
    if (envelope_.empty()) return 1.0e-7f;
    bin = std::clamp(bin, 0.0f, static_cast<float>(halfSize_));
    const std::size_t i0 = static_cast<std::size_t>(std::floor(bin));
    const std::size_t i1 = std::min(i0 + 1U, halfSize_);
    const float f = bin - static_cast<float>(i0);
    return envelope_[i0] * (1.0f - f) + envelope_[i1] * f;
}

float MultiVoicePsola::tableRead(const std::array<float, kTableSize>& table, float phase) const noexcept {
    phase -= std::floor(phase);
    const float pos = phase * static_cast<float>(kTableSize);
    const std::size_t i0 = static_cast<std::size_t>(pos) % kTableSize;
    const std::size_t i1 = (i0 + 1U) % kTableSize;
    const float f = pos - std::floor(pos);
    return table[i0] * (1.0f - f) + table[i1] * f;
}

void MultiVoicePsola::buildVoiceTable(std::size_t voice, float f0, float fundamentalPhase) noexcept {
    if (voice >= kVoices || !voiceActive_[voice] || f0 < 20.0f || windowSum_ <= 1.0f) return;

    std::fill(tableSpectrum_.begin(), tableSpectrum_.end(), std::complex<float>{});
    const float ratio = std::clamp(pitchRatio_[voice], 0.25f, 4.0f);
    const float targetF0 = std::clamp(f0 * ratio, 32.0f, static_cast<float>(sampleRate_ * 0.42));
    const float binScale = static_cast<float>(analysisSize_ / sampleRate_);
    const float sourceNyquist = static_cast<float>(sampleRate_ * 0.48);
    const float targetNyquist = static_cast<float>(sampleRate_ * 0.46);
    const int sourceHarmonics = std::max(1, static_cast<int>(std::floor(sourceNyquist / f0)));
    const int targetHarmonics = std::max(1, static_cast<int>(std::floor(targetNyquist / targetF0)));
    const int maxH = std::min<int>({sourceHarmonics, targetHarmonics,
                                    static_cast<int>(kTableSize / 2U - 1U)});

    const float explicitFormant = std::clamp(formantRatio_[voice], 0.5f, 2.0f);
    double tableEnergyEstimate = 0.0;

    for (int h = 1; h <= maxH; ++h) {
        const float sourceFreq = f0 * static_cast<float>(h);
        const float targetFreq = targetF0 * static_cast<float>(h);
        const float sourceBin = sourceFreq * binScale;
        const float sourceMag = std::max(1.0e-8f, magnitudeAt(sourceBin));
        const float sourceEnv = std::max(1.0e-8f, envelopeAt(sourceBin));
        const float residual = std::clamp(sourceMag / sourceEnv, 0.01f, 64.0f);

        // 0% formant preserve follows harmonic number (natural tape/resample
        // behaviour). 100% samples the lead vocal envelope at the target
        // absolute frequency. The explicit formant knob shifts that envelope
        // in either mode, so it can never become a dead control.
        const float mappedEnvelopeFreq = ((1.0f - formantPreserve_) * sourceFreq +
                                          formantPreserve_ * targetFreq) / explicitFormant;
        const float envBin = std::clamp(mappedEnvelopeFreq * binScale,
                                        0.0f, static_cast<float>(halfSize_));
        const float targetMag = residual * std::max(1.0e-8f, envelopeAt(envBin));
        const float amplitude = 2.0f * targetMag / windowSum_;
        if (amplitude < 1.0e-6f) continue;

        const float phase = wrapPhase(phaseAt(sourceBin) - static_cast<float>(h) * fundamentalPhase);
        const float coeffMag = 0.5f * static_cast<float>(kTableSize) * amplitude;
        const std::complex<float> c = std::polar(coeffMag, phase);
        tableSpectrum_[static_cast<std::size_t>(h)] = c;
        tableSpectrum_[kTableSize - static_cast<std::size_t>(h)] = std::conj(c);
        tableEnergyEstimate += 0.5 * static_cast<double>(amplitude) * amplitude;
    }

    tableFft_.inverse(tableSpectrum_);
    auto& next = tableNext_[voice];
    for (std::size_t n = 0; n < kTableSize; ++n) next[n] = tableSpectrum_[n].real();

    // Keep perceived level close to the analysed voiced signal without frame
    // pumping. This is a slow correction; the plug-in's voice LEVEL remains
    // the actual user gain control.
    const float tableRms = static_cast<float>(std::sqrt(std::max(1.0e-12, tableEnergyEstimate)));
    const float desired = analysedRms_ > 1.0e-5f
        ? std::clamp(analysedRms_ / std::max(tableRms, 1.0e-5f), 0.55f, 1.65f)
        : 1.0f;
    for (float& v : next) v *= desired;
}

void MultiVoicePsola::analyseFrame() noexcept {
    if (spectrum_.size() != analysisSize_ || inputRing_.empty()) return;

    double energy = 0.0;
    for (std::size_t n = 0; n < analysisSize_; ++n) {
        const std::size_t idx = (inputWrite_ + n) % analysisSize_;
        const float x = inputRing_[idx] * window_[n];
        spectrum_[n] = {x, 0.0f};
        energy += static_cast<double>(inputRing_[idx]) * inputRing_[idx];
    }
    analysedRms_ = static_cast<float>(std::sqrt(energy / static_cast<double>(analysisSize_)));
    if (analysedRms_ < 1.0e-6f) return;

    fft_.forward(spectrum_);
    prefixLog_[0] = 0.0;
    for (std::size_t k = 0; k <= halfSize_; ++k) {
        magnitude_[k] = std::abs(spectrum_[k]);
        prefixLog_[k + 1U] = prefixLog_[k] + std::log(std::max(1.0e-8f, magnitude_[k]));
    }

    // Smooth in log magnitude so the envelope follows vocal formants rather
    // than individual harmonics. Radius scales with FFT length (~450-550 Hz).
    const std::size_t radius = std::max<std::size_t>(5U, analysisSize_ / 96U);
    for (std::size_t k = 0; k <= halfSize_; ++k) {
        const std::size_t lo = k > radius ? k - radius : 0U;
        const std::size_t hi = std::min(halfSize_, k + radius);
        const double avg = (prefixLog_[hi + 1U] - prefixLog_[lo]) /
                           static_cast<double>(hi - lo + 1U);
        envelope_[k] = static_cast<float>(std::exp(avg));
    }

    const float f0 = std::clamp(pitchHzSmooth_, 65.0f, 1200.0f);
    const float fundamentalBin = f0 * static_cast<float>(analysisSize_ / sampleRate_);
    const float fundamentalPhase = phaseAt(fundamentalBin);

    // Consolidate an in-progress crossfade before installing the next set of
    // cycle shapes. This keeps timbre updates continuous at every analysis hop.
    const float b = clamp01(tableBlend_);
    for (std::size_t v = 0; v < kVoices; ++v) {
        if (tableValid_[v] && b < 1.0f) {
            for (std::size_t n = 0; n < kTableSize; ++n)
                tableCurrent_[v][n] = tableCurrent_[v][n] * (1.0f - b) + tableNext_[v][n] * b;
        } else if (tableValid_[v]) {
            tableCurrent_[v] = tableNext_[v];
        }
        buildVoiceTable(v, f0, fundamentalPhase);
        if (!tableValid_[v]) {
            tableCurrent_[v] = tableNext_[v];
            tableValid_[v] = true;
        }
    }
    tableBlend_ = 0.0f;
}

std::array<float, MultiVoicePsola::kVoices> MultiVoicePsola::processSample(float x) noexcept {
    std::array<float, kVoices> out{};
    if (inputRing_.empty()) return out;

    inputRing_[inputWrite_] = x;
    inputWrite_ = (inputWrite_ + 1U) % inputRing_.size();

    const float pitchCoeff = std::exp(-1.0f / static_cast<float>(sampleRate_ * 0.008));
    pitchHzSmooth_ = pitchCoeff * pitchHzSmooth_ + (1.0f - pitchCoeff) * pitchHzTarget_;
    const float confCoeff = std::exp(-1.0f / static_cast<float>(sampleRate_ * 0.015));
    confidenceSmooth_ = confCoeff * confidenceSmooth_ + (1.0f - confCoeff) * pitchConfidenceTarget_;
    const float voicedTarget = (voicedTarget_ && confidenceSmooth_ > 0.30f)
        ? clamp01((confidenceSmooth_ - 0.25f) / 0.42f) : 0.0f;
    const float voicedTime = voicedTarget > voicedMix_ ? 0.010f : 0.004f;
    const float voicedCoeff = std::exp(-1.0f / static_cast<float>(sampleRate_ * voicedTime));
    voicedMix_ = voicedCoeff * voicedMix_ + (1.0f - voicedCoeff) * voicedTarget;

    const float e = x * x;
    const float fastCoeff = std::exp(-1.0f / static_cast<float>(sampleRate_ * 0.0015));
    const float slowCoeff = std::exp(-1.0f / static_cast<float>(sampleRate_ * 0.032));
    fastEnergy_ = fastCoeff * fastEnergy_ + (1.0f - fastCoeff) * e;
    slowEnergy_ = slowCoeff * slowEnergy_ + (1.0f - slowCoeff) * e;
    const float transient = clamp01((fastEnergy_ - slowEnergy_) / std::max(1.0e-7f, slowEnergy_ * 2.5f));

    ++hopCounter_;
    if (hopCounter_ >= analysisHop_) {
        hopCounter_ = 0;
        if (voicedMix_ > 0.05f || confidenceSmooth_ > 0.2f) analyseFrame();
    }
    tableBlend_ = std::min(1.0f, tableBlend_ + tableBlendStep_);

    // A cheap high-pass residual carries breath/sibilance only when needed.
    // It does not create a second full-band delayed copy of the lead voice.
    const float hpCoeff = std::exp(-kTwoPi * 4200.0f / static_cast<float>(sampleRate_));
    highPassState_ = hpCoeff * (highPassState_ + x - previousInput_);
    previousInput_ = x;

    const float unvoicedAmount = unvoicedPreserve_ * (1.0f - voicedMix_);
    const float transientAmount = transientProtection_ * transient;
    const float residualMix = clamp01(std::max(unvoicedAmount, transientAmount));

    for (std::size_t v = 0; v < kVoices; ++v) {
        const float activeTarget = (voiceActive_[v] && tableValid_[v]) ? 1.0f : 0.0f;
        const float gCoeff = std::exp(-1.0f / static_cast<float>(sampleRate_ * 0.004));
        gainSmooth_[v] = gCoeff * gainSmooth_[v] + (1.0f - gCoeff) * activeTarget;
        if (gainSmooth_[v] < 1.0e-5f) { out[v] = 0.0f; continue; }

        const float targetFreq = std::clamp(pitchHzSmooth_ * pitchRatio_[v],
                                            32.0f, static_cast<float>(sampleRate_ * 0.42));
        const float fCoeff = std::exp(-1.0f / static_cast<float>(sampleRate_ * 0.006));
        frequencySmooth_[v] = fCoeff * frequencySmooth_[v] + (1.0f - fCoeff) * targetFreq;
        phase_[v] += frequencySmooth_[v] / static_cast<float>(sampleRate_);
        phase_[v] -= std::floor(phase_[v]);

        const float a = tableRead(tableCurrent_[v], phase_[v]);
        const float b = tableRead(tableNext_[v], phase_[v]);
        const float periodic = a * (1.0f - tableBlend_) + b * tableBlend_;

        // On strong voiced material use only the new pitch-synchronous voice.
        // On consonants/transients preserve only the high-frequency residual,
        // not the complete lead signal, so no audible doubler is introduced.
        out[v] = (periodic * (1.0f - 0.30f * residualMix) +
                  highPassState_ * (0.42f * residualMix)) * gainSmooth_[v];
    }
    return out;
}

} // namespace harmony
