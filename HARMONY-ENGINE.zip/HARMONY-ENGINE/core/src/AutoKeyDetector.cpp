#include "harmony/AutoKeyDetector.h"
#include <algorithm>
#include <array>
#include <cmath>

namespace harmony {
namespace {
constexpr std::array<float, 12> kMajorTemplate {
    6.35f, 2.23f, 3.48f, 2.33f, 4.38f, 4.09f,
    2.52f, 5.19f, 2.39f, 3.66f, 2.29f, 2.88f
};
constexpr std::array<float, 12> kMinorTemplate {
    6.33f, 2.68f, 3.52f, 5.38f, 2.60f, 3.53f,
    2.54f, 4.75f, 3.98f, 2.69f, 3.34f, 3.17f
};

float correlation(const std::array<float, 12>& hist,
                  const std::array<float, 12>& templ,
                  int root) noexcept {
    float hMean = 0.0f;
    float tMean = 0.0f;
    for (int i = 0; i < 12; ++i) {
        hMean += hist[static_cast<std::size_t>(i)];
        tMean += templ[static_cast<std::size_t>(i)];
    }
    hMean /= 12.0f;
    tMean /= 12.0f;

    float num = 0.0f;
    float dh = 0.0f;
    float dt = 0.0f;
    for (int i = 0; i < 12; ++i) {
        const float h = hist[static_cast<std::size_t>((i + root) % 12)] - hMean;
        const float t = templ[static_cast<std::size_t>(i)] - tMean;
        num += h * t;
        dh += h * h;
        dt += t * t;
    }
    const float den = std::sqrt(std::max(dh * dt, 1.0e-12f));
    return num / den;
}
}

void AutoKeyDetector::prepare(double sampleRate) noexcept {
    sampleRate_ = std::max(8000.0, sampleRate);
    reset();
}

void AutoKeyDetector::reset() noexcept {
    histogram_.fill(0.0f);
    totalWeight_ = 0.0f;
    observations_ = 0;
    estimate_ = {};
}

void AutoKeyDetector::observe(float midiNote, float pitchConfidence) noexcept {
    const float c = std::clamp(pitchConfidence, 0.0f, 1.0f);
    if (c < 0.58f || !std::isfinite(midiNote)) return;

    // Very slow decay: enough memory to infer a musical key while still
    // adapting when the song modulates.
    constexpr float decay = 0.9985f;
    for (auto& v : histogram_) v *= decay;
    totalWeight_ *= decay;

    const int nearest = static_cast<int>(std::lround(midiNote));
    const int pc = ((nearest % 12) + 12) % 12;
    const float cents = (midiNote - static_cast<float>(nearest)) * 100.0f;
    const float inTuneWeight = std::exp(-0.5f * (cents / 38.0f) * (cents / 38.0f));
    const float w = c * (0.55f + 0.45f * inTuneWeight);
    histogram_[static_cast<std::size_t>(pc)] += w;
    totalWeight_ += w;

    ++observations_;
    if ((observations_ & 7U) == 0U) updateEstimate();
}

void AutoKeyDetector::updateEstimate() noexcept {
    if (totalWeight_ < 5.0f) {
        estimate_.confidence = 0.0f;
        return;
    }

    float best = -2.0f;
    float second = -2.0f;
    int bestRoot = 0;
    bool bestMinor = false;
    for (int root = 0; root < 12; ++root) {
        const float maj = correlation(histogram_, kMajorTemplate, root);
        const float min = correlation(histogram_, kMinorTemplate, root);
        const std::array<std::pair<float, bool>, 2> scores {{{maj, false}, {min, true}}};
        for (const auto& s : scores) {
            if (s.first > best) {
                second = best;
                best = s.first;
                bestRoot = root;
                bestMinor = s.second;
            } else if (s.first > second) {
                second = s.first;
            }
        }
    }

    estimate_.root = bestRoot;
    estimate_.scale = bestMinor ? ScaleType::NaturalMinor : ScaleType::Major;
    const float separation = std::clamp((best - second) * 2.4f, 0.0f, 1.0f);
    const float absolute = std::clamp((best + 0.1f) / 0.8f, 0.0f, 1.0f);
    estimate_.confidence = separation * absolute;
}
}
