#include "harmony/HarmonyProcessor.h"
#include "harmony/AudioMath.h"
#include <algorithm>
#include <cmath>

namespace harmony {
void HarmonyProcessor::prepare(double sampleRate) {
    sampleRate_ = std::max(8000.0, sampleRate);
    tracker_.prepare(sampleRate_, 65.0f, 1200.0f);
    keyDetector_.prepare(sampleRate_);

    // Low-latency window sizing while keeping roughly the same time span
    // across common sample rates.  This cuts the 44.1/48 kHz algorithmic
    // latency in half versus the previous 2048-sample default and also lowers
    // CPU load on older Intel Macs.
    const std::size_t fftSize = sampleRate_ <= 56000.0 ? 1024U
                               : sampleRate_ <= 112000.0 ? 2048U
                                                        : 4096U;
    vocoder_.prepare(sampleRate_, fftSize, fftSize / 4U);

    const std::size_t drySamples = static_cast<std::size_t>(std::max(1, vocoder_.latencySamples()));
    dryDelay_.assign(drySamples, 0.0f);

    const std::size_t maxVoiceDelay = static_cast<std::size_t>(std::ceil(sampleRate_ * 0.250)) + 4U;
    for (auto& d : voiceDelay_) d.assign(maxVoiceDelay, 0.0f);

    // ~12 dB/second release in the displayed peak meter.
    meterDecay_ = std::pow(10.0f, -12.0f / (20.0f * static_cast<float>(sampleRate_)));
    reset();
}

void HarmonyProcessor::reset() {
    tracker_.reset();
    keyDetector_.reset();
    vocoder_.reset();
    previousTargets_.fill(-1);
    plannedTargets_.fill(-1);
    ratioSmooth_.fill(1.0f);
    driftPhase_ = {{0.0f, 1.1f, 2.3f, 4.1f}};
    vibratoPhase_ = {{0.4f, 1.8f, 3.2f, 5.0f}};
    for (std::size_t v = 0; v < kVoices; ++v) {
        for (std::size_t sidx = 0; sidx < 8U; ++sidx)
            choirPhase_[v][sidx] = 0.37f * static_cast<float>(sidx + 1U) + 0.71f * static_cast<float>(v);
    }
    std::fill(dryDelay_.begin(), dryDelay_.end(), 0.0f);
    dryWrite_ = 0;
    for (std::size_t v = 0; v < kVoices; ++v) {
        std::fill(voiceDelay_[v].begin(), voiceDelay_[v].end(), 0.0f);
        voiceDelayWrite_[v] = 0;
    }
    lastPitchSerial_ = 0;
    lastLeadCentre_ = -999;
    plannedChordRevision_ = ~std::uint64_t{0};
    lastPlannerRoot_ = -1;
    lastPlannerScale_ = ScaleType::Major;
    lastMode_ = params_.mode;
    lastChordRoot_ = -1;
    lastChordType_ = ChordType::Major;
    meters_ = {};
    smoothedInputGain_ = dbToGain(params_.inputDb);
    smoothedOutputGain_ = dbToGain(params_.outputDb);
    smoothedDryGain_ = dbToGain(params_.dryDb);
    smoothedWetGain_ = dbToGain(params_.wetDb);
    for (std::size_t v = 0; v < kVoices; ++v) {
        smoothedVoiceGain_[v] = dbToGain(params_.voices[v].levelDb);
        smoothedPan_[v] = params_.voices[v].pan;
    }
}

int HarmonyProcessor::latencySamples() const noexcept { return vocoder_.latencySamples(); }

void HarmonyProcessor::setChordNotes(const int* notes, std::size_t count) noexcept {
    std::array<int, 16> incoming{};
    const std::size_t newCount = std::min<std::size_t>(count, incoming.size());
    for (std::size_t i = 0; i < newCount; ++i) incoming[i] = std::clamp(notes[i], 0, 127);
    std::sort(incoming.begin(), incoming.begin() + static_cast<std::ptrdiff_t>(newCount));

    bool changed = newCount != chordCount_;
    if (!changed) {
        for (std::size_t i = 0; i < newCount; ++i) {
            if (incoming[i] != chordNotes_[i]) { changed = true; break; }
        }
    }
    if (!changed) return;

    chordCount_ = newCount;
    for (std::size_t i = 0; i < newCount; ++i) chordNotes_[i] = incoming[i];
    ++chordRevision_;
}

float HarmonyProcessor::processDryDelay(float x) noexcept {
    if (dryDelay_.empty()) return x;
    const float y = dryDelay_[dryWrite_];
    dryDelay_[dryWrite_] = x;
    dryWrite_ = (dryWrite_ + 1U) % dryDelay_.size();
    return y;
}

float HarmonyProcessor::readVoiceDelay(std::size_t voice, float delayMs) const noexcept {
    if (voice >= kVoices || voiceDelay_[voice].empty()) return 0.0f;
    const auto& ring = voiceDelay_[voice];
    const std::size_t write = voiceDelayWrite_[voice];
    const float maxDelaySamples = static_cast<float>(ring.size() - 3U);
    const float delaySamples = std::clamp(delayMs * 0.001f * static_cast<float>(sampleRate_), 0.0f, maxDelaySamples);
    float readPos = static_cast<float>(write) - delaySamples;
    while (readPos < 0.0f) readPos += static_cast<float>(ring.size());
    while (readPos >= static_cast<float>(ring.size())) readPos -= static_cast<float>(ring.size());
    const std::size_t i0 = static_cast<std::size_t>(std::floor(readPos)) % ring.size();
    const std::size_t i1 = (i0 + 1U) % ring.size();
    const float frac = readPos - std::floor(readPos);
    return ring[i0] * (1.0f - frac) + ring[i1] * frac;
}

std::array<float, 2> HarmonyProcessor::processVoiceBank(std::size_t voice, float x, const VoiceParams& params) noexcept {
    std::array<float, 2> out{};
    if (voice >= kVoices || voiceDelay_[voice].empty()) return out;

    auto& ring = voiceDelay_[voice];
    auto& write = voiceDelayWrite_[voice];
    ring[write] = x;

    int count = params.choirVoices;
    if (count <= 1) count = 1;
    else if (count <= 2) count = 2;
    else if (count <= 4) count = 4;
    else count = 8;

    const float baseDelay = std::clamp(params.delayMs, 0.0f, 200.0f);
    const float spread = clamp01(params.choirSpread);
    const float depth = clamp01(params.choirDepth);
    const float gainNorm = std::pow(static_cast<float>(count), -0.62f);

    for (int sidx = 0; sidx < count; ++sidx) {
        float delay = baseDelay;
        if (count > 1) {
            const float staticOffset = 1.6f * static_cast<float>(sidx);
            const float modDepthMs = depth * (0.35f + 0.08f * static_cast<float>(sidx));
            delay += staticOffset + modDepthMs * std::sin(choirPhase_[voice][static_cast<std::size_t>(sidx)]);
        }
        delay = std::clamp(delay, 0.0f, 230.0f);
        const float y = readVoiceDelay(voice, delay);

        float subPan = smoothedPan_[voice];
        if (count > 1) {
            const float u = (2.0f * static_cast<float>(sidx) / static_cast<float>(count - 1)) - 1.0f;
            subPan = std::clamp(subPan + u * spread * 0.92f, -1.0f, 1.0f);
        }
        out[0] += y * gainNorm * equalPowerPanL(subPan);
        out[1] += y * gainNorm * equalPowerPanR(subPan);

        const float rate = 0.085f + 0.021f * static_cast<float>(sidx) + 0.013f * static_cast<float>(voice);
        choirPhase_[voice][static_cast<std::size_t>(sidx)] += kTwoPi * rate / static_cast<float>(sampleRate_);
        if (choirPhase_[voice][static_cast<std::size_t>(sidx)] > kTwoPi)
            choirPhase_[voice][static_cast<std::size_t>(sidx)] -= kTwoPi;
    }

    write = (write + 1U) % ring.size();
    return out;
}

void HarmonyProcessor::replan(float inputMidi) noexcept {
    int plannerRoot = params_.keyRoot;
    ScaleType plannerScale = params_.scale;
    if (params_.mode == HarmonyMode::AutoKey) {
        const auto k = keyDetector_.estimate();
        if (k.confidence >= std::clamp(params_.autoKeyThreshold, 0.0f, 1.0f)) {
            plannerRoot = k.root;
            plannerScale = k.scale;
        }
    }

    planner_.setKey(plannerRoot, plannerScale);
    if (params_.mode == HarmonyMode::ManualChord) {
        std::array<int, 8> manualNotes{};
        const std::size_t manualCount = HarmonyPlanner::buildChordNotes(params_.chordRoot, params_.chordType, manualNotes);
        planner_.setChordNotes(manualNotes.data(), manualCount);
    } else if (params_.mode == HarmonyMode::MidiChord && chordCount_ > 0U) {
        planner_.setChordNotes(chordNotes_.data(), chordCount_);
    } else {
        planner_.setChordNotes(nullptr, 0U);
    }

    std::array<HarmonyVoiceRule, kVoices> rules{};
    std::array<VoiceRange, kVoices> ranges{};
    for (std::size_t v = 0; v < kVoices; ++v) {
        rules[v] = HarmonyPlanner::ruleForPreset(params_.voices[v].preset, params_.voices[v].rule);
        ranges[v] = {params_.voices[v].minMidi, params_.voices[v].maxMidi};
    }
    plannedTargets_ = planner_.planTargets(inputMidi, rules, previousTargets_, ranges);
    lastPlannedRules_ = rules;
    lastPlannedRanges_ = ranges;
    havePlannedVoiceConfig_ = true;
    for (std::size_t v = 0; v < kVoices; ++v)
        if (plannedTargets_[v] >= 0) previousTargets_[v] = plannedTargets_[v];

    lastLeadCentre_ = planner_.quantizeLeadMidi(inputMidi);
    plannedChordRevision_ = chordRevision_;
    lastPlannerRoot_ = plannerRoot;
    lastPlannerScale_ = plannerScale;
    lastMode_ = params_.mode;
    lastChordRoot_ = params_.chordRoot;
    lastChordType_ = params_.chordType;
}

void HarmonyProcessor::updatePeak(float sample, float& meter) noexcept {
    const float a = std::abs(sample);
    meter = std::max(a, meter * meterDecay_);
}

void HarmonyProcessor::processBlock(const float* input, float* outL, float* outR, std::size_t numSamples) noexcept {
    if (input == nullptr || outL == nullptr || outR == nullptr) return;

    const float inputGain = dbToGain(params_.inputDb);
    const float outputGain = dbToGain(params_.outputDb);
    const float dryGain = dbToGain(params_.dryDb);
    const float wetGain = dbToGain(params_.wetDb);
    const float gainCoeff = std::exp(-1.0f / static_cast<float>(sampleRate_ * 0.012));
    const float tightness = clamp01(params_.tightness);
    const float harmonyWidth = std::clamp(params_.harmonyWidth, 0.0f, 2.0f);
    tracker_.setReferenceA4(params_.tuningHz);
    const bool anySolo = std::any_of(params_.voices.begin(), params_.voices.end(), [](const VoiceParams& v) { return v.rule.enabled && v.solo && !v.mute; });
    const float humanize = clamp01(params_.humanize);
    const float smoothingMs = std::clamp(params_.pitchSmoothingMs, 1.0f, 120.0f);
    const float ratioCoeff = std::exp(-1.0f / static_cast<float>(sampleRate_ * smoothingMs * 0.001));

    vocoder_.setFormantPreserve(params_.formantPreserve);
    vocoder_.setTransientProtection(params_.transientProtection);
    vocoder_.setUnvoicedPreserve(params_.unvoicedPreserve);
    for (std::size_t v = 0; v < kVoices; ++v) {
        const auto& vp = params_.voices[v];
        const bool audible = vp.rule.enabled && !vp.mute && (!anySolo || vp.solo);
        vocoder_.setVoiceActive(v, audible);
    }

    for (std::size_t n = 0; n < numSamples; ++n) {
        smoothedInputGain_ = gainCoeff * smoothedInputGain_ + (1.0f - gainCoeff) * inputGain;
        smoothedOutputGain_ = gainCoeff * smoothedOutputGain_ + (1.0f - gainCoeff) * outputGain;
        smoothedDryGain_ = gainCoeff * smoothedDryGain_ + (1.0f - gainCoeff) * dryGain;
        smoothedWetGain_ = gainCoeff * smoothedWetGain_ + (1.0f - gainCoeff) * wetGain;
        for (std::size_t v = 0; v < kVoices; ++v) {
            smoothedVoiceGain_[v] = gainCoeff * smoothedVoiceGain_[v] + (1.0f - gainCoeff) * dbToGain(params_.voices[v].levelDb);
            smoothedPan_[v] = gainCoeff * smoothedPan_[v] + (1.0f - gainCoeff) * std::clamp(params_.voices[v].pan, -1.0f, 1.0f);
        }

        const float x = input[n] * smoothedInputGain_;
        updatePeak(x, meters_.inputPeak);
        const PitchEstimate est = tracker_.processSample(x);

        if (est.analysisSerial != lastPitchSerial_) {
            lastPitchSerial_ = est.analysisSerial;
            if (est.voiced) keyDetector_.observe(est.midiNote, est.confidence);

            const KeyEstimate k = keyDetector_.estimate();
            meters_.pitchMidi = est.midiNote;
            meters_.pitchConfidence = est.confidence;
            meters_.detectedKeyRoot = k.root;
            meters_.detectedScale = k.scale;
            meters_.keyConfidence = k.confidence;
        }

        if (est.voiced) {
            int plannerRoot = params_.keyRoot;
            ScaleType plannerScale = params_.scale;
            if (params_.mode == HarmonyMode::AutoKey) {
                const auto k = keyDetector_.estimate();
                if (k.confidence >= std::clamp(params_.autoKeyThreshold, 0.0f, 1.0f)) { plannerRoot = k.root; plannerScale = k.scale; }
            }
            planner_.setKey(plannerRoot, plannerScale);
            const int leadCentre = planner_.quantizeLeadMidi(est.midiNote);
            bool voiceConfigChanged = !havePlannedVoiceConfig_;
            for (std::size_t v = 0; v < kVoices && !voiceConfigChanged; ++v) {
                const auto currentRule = HarmonyPlanner::ruleForPreset(params_.voices[v].preset, params_.voices[v].rule);
                const VoiceRange currentRange{params_.voices[v].minMidi, params_.voices[v].maxMidi};
                const auto& previousRule = lastPlannedRules_[v];
                const auto& previousRange = lastPlannedRanges_[v];
                voiceConfigChanged = currentRule.enabled != previousRule.enabled ||
                                     currentRule.mode != previousRule.mode ||
                                     currentRule.interval != previousRule.interval ||
                                     currentRule.octave != previousRule.octave ||
                                     currentRange.minMidi != previousRange.minMidi ||
                                     currentRange.maxMidi != previousRange.maxMidi;
            }

            const bool needPlan = leadCentre != lastLeadCentre_ ||
                                  plannedChordRevision_ != chordRevision_ ||
                                  lastPlannerRoot_ != plannerRoot ||
                                  lastPlannerScale_ != plannerScale ||
                                  lastMode_ != params_.mode ||
                                  voiceConfigChanged ||
                                  (params_.mode == HarmonyMode::ManualChord &&
                                   (lastChordRoot_ != params_.chordRoot || lastChordType_ != params_.chordType));
            if (needPlan) replan(est.midiNote);

            const float deviation = est.midiNote - static_cast<float>(leadCentre);
            for (std::size_t v = 0; v < kVoices; ++v) {
                const auto& vp = params_.voices[v];
                if (!vp.rule.enabled || plannedTargets_[v] < 0) continue;

                // Preserve the singer's micro-pitch/vibrato unless Tightness
                // deliberately asks for stronger locking.
                const float preservedDeviation = deviation * (1.0f - tightness);
                const float lfo = 0.67f * std::sin(driftPhase_[v]) +
                                  0.33f * std::sin(driftPhase_[v] * 0.43f + 1.7f);
                const float humanCents = lfo * vp.humanizeCents * humanize;
                const float vibratoCents = std::sin(vibratoPhase_[v]) * std::clamp(vp.vibratoCents, 0.0f, 100.0f);
                const float cents = vp.detuneCents + humanCents + vibratoCents;
                const float targetMidi = static_cast<float>(plannedTargets_[v]) + preservedDeviation + cents / 100.0f;
                const float targetRatio = std::pow(2.0f, (targetMidi - est.midiNote) / 12.0f);
                ratioSmooth_[v] = ratioCoeff * ratioSmooth_[v] + (1.0f - ratioCoeff) * targetRatio;
            }
        }

        for (std::size_t v = 0; v < kVoices; ++v) {
            driftPhase_[v] += kTwoPi * driftRateHz_[v] / static_cast<float>(sampleRate_);
            if (driftPhase_[v] > kTwoPi) driftPhase_[v] -= kTwoPi;
            const float vibRate = std::clamp(params_.voices[v].vibratoRateHz, 0.1f, 12.0f);
            vibratoPhase_[v] += kTwoPi * vibRate / static_cast<float>(sampleRate_);
            if (vibratoPhase_[v] > kTwoPi) vibratoPhase_[v] -= kTwoPi;
            vocoder_.setVoicePitchRatio(v, ratioSmooth_[v]);
            vocoder_.setVoiceFormantSemitones(v, params_.voices[v].formantSemitones);
        }

        const auto shifted = vocoder_.processSample(x);
        const float dry = processDryDelay(x);
        float l = dry * smoothedDryGain_ * 0.70710678f;
        float r = dry * smoothedDryGain_ * 0.70710678f;
        for (std::size_t v = 0; v < kVoices; ++v) {
            const auto& vp = params_.voices[v];
            if (!vp.rule.enabled) {
                meters_.voicePeak[v] *= meterDecay_;
                continue;
            }

            const auto bank = processVoiceBank(v, shifted[v], vp);
            const bool audible = !vp.mute && (!anySolo || vp.solo);
            if (!audible) {
                meters_.voicePeak[v] *= meterDecay_;
                continue;
            }

            const float mid = 0.5f * (bank[0] + bank[1]);
            const float side = 0.5f * (bank[0] - bank[1]) * harmonyWidth;
            const float wideL = mid + side;
            const float wideR = mid - side;
            const float voiceMeterSample = std::max(std::abs(wideL), std::abs(wideR));
            updatePeak(voiceMeterSample, meters_.voicePeak[v]);
            const float g = smoothedWetGain_ * smoothedVoiceGain_[v];
            l += wideL * g;
            r += wideR * g;
        }
        l *= smoothedOutputGain_;
        r *= smoothedOutputGain_;
        outL[n] = l;
        outR[n] = r;
        updatePeak(l, meters_.outputPeakL);
        updatePeak(r, meters_.outputPeakR);
    }
}
}
