#include "harmony/MultiVoiceVocoder.h"
#include "harmony/AudioMath.h"
#include <algorithm>
#include <cmath>
#include <numeric>

namespace harmony {
void MultiVoiceVocoder::prepare(double sampleRate, std::size_t fftSize, std::size_t hopSize) {
    sampleRate_ = std::max(8000.0, sampleRate);
    fftSize_ = fftSize;
    hopSize_ = hopSize;
    if (fftSize_ < 512U || (fftSize_ & (fftSize_ - 1U)) != 0U) fftSize_ = 2048U;
    if (hopSize_ == 0U || hopSize_ > fftSize_ / 2U) hopSize_ = fftSize_ / 4U;
    halfSize_ = fftSize_ / 2U;
    fft_.setSize(fftSize_);

    window_.resize(fftSize_);
    for (std::size_t n = 0; n < fftSize_; ++n) {
        window_[n] = 0.5f - 0.5f * std::cos(kTwoPi * static_cast<float>(n) / static_cast<float>(fftSize_));
    }
    inputRing_.assign(fftSize_, 0.0f);
    const std::size_t outSize = fftSize_ * 4U;
    for (auto& r : outputRing_) r.assign(outSize, 0.0f);
    spectrum_.assign(fftSize_, {});
    magnitude_.assign(halfSize_ + 1U, 0.0f);
    previousMagnitude_.assign(halfSize_ + 1U, 0.0f);
    phase_.assign(halfSize_ + 1U, 0.0f);
    previousPhase_.assign(halfSize_ + 1U, 0.0f);
    trueBin_.assign(halfSize_ + 1U, 0.0f);
    envelope_.assign(halfSize_ + 1U, 1.0e-6f);
    highFrequencyWeight_.assign(halfSize_ + 1U, 0.0f);
    const float hzPerBin = static_cast<float>(sampleRate_) / static_cast<float>(fftSize_);
    for (std::size_t k = 0; k <= halfSize_; ++k) {
        const float hz = static_cast<float>(k) * hzPerBin;
        highFrequencyWeight_[k] = clamp01((hz - 1800.0f) / 4200.0f);
    }
    prefixLog_.assign(halfSize_ + 2U, 0.0);
    for (std::size_t v = 0; v < kVoices; ++v) {
        synthesisSpectrum_[v].assign(fftSize_, {});
        synthPhase_[v].assign(halfSize_ + 1U, 0.0f);
        mappedMagnitude_[v].assign(halfSize_ + 1U, 0.0f);
        mappedFrequency_[v].assign(halfSize_ + 1U, 0.0f);
        mappedWeight_[v].assign(halfSize_ + 1U, 0.0f);
        dominantSource_[v].assign(halfSize_ + 1U, 0U);
        dominantContribution_[v].assign(halfSize_ + 1U, 0.0f);
        spectralPeak_[v].assign(halfSize_ + 1U, 0U);
        nearestPeak_[v].assign(halfSize_ + 1U, 0U);
    }
    reset();
}

void MultiVoiceVocoder::reset() {
    std::fill(inputRing_.begin(), inputRing_.end(), 0.0f);
    for (auto& r : outputRing_) std::fill(r.begin(), r.end(), 0.0f);
    std::fill(previousMagnitude_.begin(), previousMagnitude_.end(), 0.0f);
    std::fill(previousPhase_.begin(), previousPhase_.end(), 0.0f);
    for (auto& p : synthPhase_) std::fill(p.begin(), p.end(), 0.0f);
    inputWrite_ = 0;
    outputRead_ = 0;
    hopCounter_ = 0;
}


void MultiVoiceVocoder::setVoiceActive(std::size_t voice, bool active) noexcept {
    if (voice >= kVoices || voiceActive_[voice] == active) return;
    voiceActive_[voice] = active;
    if (!active && voice < outputRing_.size())
        std::fill(outputRing_[voice].begin(), outputRing_[voice].end(), 0.0f);
    anyVoiceActive_ = std::any_of(voiceActive_.begin(), voiceActive_.end(), [](bool value) { return value; });
}

void MultiVoiceVocoder::setVoicePitchRatio(std::size_t voice, float ratio) noexcept {
    if (voice >= kVoices) return;
    pitchRatio_[voice] = std::clamp(ratio, 0.0625f, 16.0f);
}

void MultiVoiceVocoder::setVoiceFormantSemitones(std::size_t voice, float semitones) noexcept {
    if (voice >= kVoices) return;
    formantRatio_[voice] = std::pow(2.0f, std::clamp(semitones, -12.0f, 12.0f) / 12.0f);
}

void MultiVoiceVocoder::setFormantPreserve(float amount) noexcept {
    formantPreserve_ = clamp01(amount);
}

void MultiVoiceVocoder::setTransientProtection(float amount) noexcept {
    transientProtection_ = clamp01(amount);
}

void MultiVoiceVocoder::setUnvoicedPreserve(float amount) noexcept {
    unvoicedPreserve_ = clamp01(amount);
}

std::array<float, MultiVoiceVocoder::kVoices> MultiVoiceVocoder::processSample(float x) noexcept {
    std::array<float, kVoices> out{};
    if (inputRing_.empty() || outputRing_[0].empty()) {
        out.fill(x);
        return out;
    }
    if (!anyVoiceActive_) {
        out.fill(0.0f);
        return out;
    }

    inputRing_[inputWrite_] = x;
    inputWrite_ = (inputWrite_ + 1U) % inputRing_.size();

    for (std::size_t v = 0; v < kVoices; ++v) {
        out[v] = voiceActive_[v] ? outputRing_[v][outputRead_] : 0.0f;
        outputRing_[v][outputRead_] = 0.0f;
    }
    outputRead_ = (outputRead_ + 1U) % outputRing_[0].size();

    ++hopCounter_;
    if (hopCounter_ >= hopSize_) {
        hopCounter_ = 0;
        processFrame();
    }
    return out;
}

float MultiVoiceVocoder::envelopeAt(float bin) const noexcept {
    if (envelope_.empty()) return 1.0f;
    bin = std::clamp(bin, 0.0f, static_cast<float>(halfSize_));
    const std::size_t i0 = static_cast<std::size_t>(std::floor(bin));
    const std::size_t i1 = std::min(i0 + 1U, halfSize_);
    const float f = bin - static_cast<float>(i0);
    return envelope_[i0] * (1.0f - f) + envelope_[i1] * f;
}

void MultiVoiceVocoder::processFrame() noexcept {
    if (spectrum_.size() != fftSize_ || !anyVoiceActive_) return;
    double frameEnergy = 0.0;
    for (std::size_t n = 0; n < fftSize_; ++n) {
        const std::size_t idx = (inputWrite_ + n) % fftSize_;
        const float sample = inputRing_[idx] * window_[n];
        spectrum_[n] = std::complex<float>(sample, 0.0f);
        frameEnergy += static_cast<double>(sample) * sample;
    }
    // Host scanners and stopped transports feed long stretches of silence.
    // Do not burn four inverse FFTs on frames that are effectively zero.
    if (frameEnergy / static_cast<double>(fftSize_) < 1.0e-14) {
        std::fill(previousMagnitude_.begin(), previousMagnitude_.end(), 0.0f);
        return;
    }
    fft_.forward(spectrum_);

    double arithmetic = 0.0;
    double logSum = 0.0;
    double fluxNum = 0.0;
    double fluxDen = 1.0e-12;
    const float phaseScale = static_cast<float>(fftSize_) / (kTwoPi * static_cast<float>(hopSize_));
    for (std::size_t k = 0; k <= halfSize_; ++k) {
        const float mag = std::abs(spectrum_[k]);
        const float ph = std::arg(spectrum_[k]);
        magnitude_[k] = mag;
        phase_[k] = ph;
        const float expected = kTwoPi * static_cast<float>(k) * static_cast<float>(hopSize_) / static_cast<float>(fftSize_);
        const float delta = wrapPhase(ph - previousPhase_[k] - expected);
        trueBin_[k] = static_cast<float>(k) + delta * phaseScale;
        previousPhase_[k] = ph;
        if (k > 1U && k < halfSize_) {
            arithmetic += static_cast<double>(mag);
            logSum += std::log(std::max(1.0e-12f, mag));
            const double positive = std::max(0.0, static_cast<double>(mag - previousMagnitude_[k]));
            fluxNum += positive * positive;
            fluxDen += static_cast<double>(previousMagnitude_[k]) * previousMagnitude_[k];
        }
    }

    const std::size_t spectralBins = halfSize_ > 2U ? halfSize_ - 2U : 1U;
    const double mean = arithmetic / static_cast<double>(spectralBins);
    const double geometric = std::exp(logSum / static_cast<double>(spectralBins));
    const float flatness = static_cast<float>(geometric / std::max(mean, 1.0e-12));
    const float flux = static_cast<float>(std::sqrt(fluxNum / fluxDen));
    const bool transient = flux > (0.70f - 0.42f * transientProtection_);

    const std::size_t envelopeRadius = std::max<std::size_t>(4U, (12U * fftSize_) / 2048U);
    prefixLog_[0] = 0.0;
    for (std::size_t k = 0; k <= halfSize_; ++k) {
        prefixLog_[k + 1U] = prefixLog_[k] + std::log(std::max(1.0e-8f, magnitude_[k]));
    }
    for (std::size_t k = 0; k <= halfSize_; ++k) {
        const std::size_t lo = k > envelopeRadius ? k - envelopeRadius : 0U;
        const std::size_t hi = std::min(halfSize_, k + envelopeRadius);
        const double avg = (prefixLog_[hi + 1U] - prefixLog_[lo]) / static_cast<double>(hi - lo + 1U);
        envelope_[k] = static_cast<float>(std::exp(avg));
    }

    double sourceEnergy = 1.0e-18;
    for (std::size_t k = 1; k < halfSize_; ++k)
        sourceEnergy += static_cast<double>(magnitude_[k]) * magnitude_[k];
    const float noiseAmount = clamp01((flatness - 0.12f) / 0.48f);

    for (std::size_t v = 0; v < kVoices; ++v) {
        if (!voiceActive_[v]) continue;
        std::fill(mappedMagnitude_[v].begin(), mappedMagnitude_[v].end(), 0.0f);
        std::fill(mappedFrequency_[v].begin(), mappedFrequency_[v].end(), 0.0f);
        std::fill(mappedWeight_[v].begin(), mappedWeight_[v].end(), 0.0f);
        std::fill(dominantSource_[v].begin(), dominantSource_[v].end(), 0U);
        std::fill(dominantContribution_[v].begin(), dominantContribution_[v].end(), 0.0f);
        std::fill(spectralPeak_[v].begin(), spectralPeak_[v].end(), 0U);
        std::fill(nearestPeak_[v].begin(), nearestPeak_[v].end(), 0U);
        std::fill(synthesisSpectrum_[v].begin(), synthesisSpectrum_[v].end(), std::complex<float>{});

        const float ratio = pitchRatio_[v];
        const float formant = formantRatio_[v];

        for (std::size_t k = 1; k < halfSize_; ++k) {
            const float noise = noiseAmount * highFrequencyWeight_[k];
            const float localRatio = ratio + (1.0f - ratio) * unvoicedPreserve_ * noise;
            const float target = static_cast<float>(k) * localRatio;
            if (target < 1.0f || target >= static_cast<float>(halfSize_ - 1U)) continue;

            const float sourceEnvelope = std::max(envelope_[k], 1.0e-7f);
            const float residual = magnitude_[k] / sourceEnvelope;
            const bool preserveNone = formantPreserve_ <= 1.0e-5f;
            const bool preserveFull = formantPreserve_ >= 0.99999f;
            const float logShifted = (!preserveNone && !preserveFull)
                ? std::log(std::max(sourceEnvelope, 1.0e-8f))
                : 0.0f;
            const std::size_t d0 = static_cast<std::size_t>(std::floor(target));
            const std::size_t d1 = d0 + 1U;
            const float frac = target - static_cast<float>(d0);
            const float weights[2] = {1.0f - frac, frac};
            const std::size_t bins[2] = {d0, d1};
            for (int q = 0; q < 2; ++q) {
                const std::size_t d = bins[q];
                const float w = weights[q];
                const float preservedEnvelope = envelopeAt(static_cast<float>(d) / std::max(formant, 0.25f));
                float env = sourceEnvelope;
                if (preserveFull) {
                    env = preservedEnvelope;
                } else if (!preserveNone) {
                    const float logPreserved = std::log(std::max(preservedEnvelope, 1.0e-8f));
                    env = std::exp(logShifted + formantPreserve_ * (logPreserved - logShifted));
                }
                const float magOut = residual * env * w;
                const float trueOut = trueBin_[k] * localRatio;
                mappedMagnitude_[v][d] += magOut;
                mappedFrequency_[v][d] += trueOut * magOut;
                mappedWeight_[v][d] += magOut;
                if (magOut > dominantContribution_[v][d]) {
                    dominantContribution_[v][d] = magOut;
                    dominantSource_[v][d] = k;
                }
            }
        }

        // Pitch remapping changes spectral-bin density. Normalize mapped
        // spectral energy so shifted harmonies do not become thin or boomy
        // purely because bins spread out or converge.
        double mappedEnergy = 1.0e-18;
        for (std::size_t k = 1; k < halfSize_; ++k)
            mappedEnergy += static_cast<double>(mappedMagnitude_[v][k]) * mappedMagnitude_[v][k];
        const float energyGain = std::clamp(
            static_cast<float>(std::sqrt(sourceEnergy / mappedEnergy)), 0.78f, 1.28f);
        for (std::size_t k = 1; k < halfSize_; ++k)
            mappedMagnitude_[v][k] *= energyGain;

        float maxMapped = 0.0f;
        for (std::size_t k = 1; k < halfSize_; ++k) maxMapped = std::max(maxMapped, mappedMagnitude_[v][k]);
        const float peakFloor = maxMapped * 0.0025f;
        for (std::size_t k = 2; k + 2U < halfSize_; ++k) {
            const float m = mappedMagnitude_[v][k];
            if (m > peakFloor && m >= mappedMagnitude_[v][k - 1U] && m > mappedMagnitude_[v][k + 1U])
                spectralPeak_[v][k] = 1U;
        }

        // First propagate independent peak/bin phases.
        for (std::size_t k = 1; k < halfSize_; ++k) {
            const float mag = mappedMagnitude_[v][k];
            if (mag <= 1.0e-12f) continue;
            const float trueOut = mappedWeight_[v][k] > 1.0e-12f
                ? mappedFrequency_[v][k] / mappedWeight_[v][k]
                : static_cast<float>(k);
            if (transient && transientProtection_ > 0.05f) {
                const std::size_t srcBin = std::min<std::size_t>(halfSize_, dominantSource_[v][k]);
                synthPhase_[v][k] = phase_[srcBin];
            } else {
                synthPhase_[v][k] += kTwoPi * trueOut * static_cast<float>(hopSize_) / static_cast<float>(fftSize_);
                synthPhase_[v][k] = wrapPhase(synthPhase_[v][k]);
            }
        }

        // Identity-style phase locking: bins surrounding a spectral peak keep
        // the input phase relationship to that peak. This substantially reduces
        // the watery/phasier quality of a plain independent-bin vocoder.
        std::size_t lastPeak = 0U;
        for (std::size_t k = 1; k < halfSize_; ++k) {
            if (spectralPeak_[v][k] != 0U) lastPeak = k;
            nearestPeak_[v][k] = lastPeak;
        }
        std::size_t nextPeak = 0U;
        for (std::size_t k = halfSize_ - 1U; k > 0U; --k) {
            if (spectralPeak_[v][k] != 0U) nextPeak = k;
            const std::size_t left = nearestPeak_[v][k];
            if (nextPeak != 0U && (left == 0U || nextPeak - k < k - left)) nearestPeak_[v][k] = nextPeak;
        }

        constexpr float phaseLockStrength = 0.92f;
        const std::size_t maxLockDistance = std::max<std::size_t>(4U, (14U * fftSize_) / 2048U);
        for (std::size_t k = 1; k < halfSize_; ++k) {
            if (mappedMagnitude_[v][k] <= 1.0e-12f) continue;
            const std::size_t peak = nearestPeak_[v][k];
            if (peak == 0U || peak == k ||
                (k > peak ? k - peak : peak - k) > maxLockDistance ||
                mappedMagnitude_[v][peak] <= 1.0e-12f) continue;
            const std::size_t src = std::min<std::size_t>(halfSize_, dominantSource_[v][k]);
            const std::size_t srcPeak = std::min<std::size_t>(halfSize_, dominantSource_[v][peak]);
            const float relative = wrapPhase(phase_[src] - phase_[srcPeak]);
            const float locked = wrapPhase(synthPhase_[v][peak] + relative);
            const float delta = wrapPhase(locked - synthPhase_[v][k]);
            synthPhase_[v][k] = wrapPhase(synthPhase_[v][k] + phaseLockStrength * delta);
        }

        for (std::size_t k = 1; k < halfSize_; ++k) {
            const float mag = mappedMagnitude_[v][k];
            if (mag <= 1.0e-12f) continue;
            synthesisSpectrum_[v][k] = std::polar(mag, synthPhase_[v][k]);
            synthesisSpectrum_[v][fftSize_ - k] = std::conj(synthesisSpectrum_[v][k]);
        }
        synthesisSpectrum_[v][0] = std::complex<float>(mappedMagnitude_[v][0], 0.0f);
        synthesisSpectrum_[v][halfSize_] = std::complex<float>(mappedMagnitude_[v][halfSize_], 0.0f);
        fft_.inverse(synthesisSpectrum_[v]);

        const float olaNorm = hopSize_ == fftSize_ / 4U ? (2.0f / 3.0f) : static_cast<float>(hopSize_) / static_cast<float>(fftSize_);
        const std::size_t outSize = outputRing_[v].size();
        for (std::size_t n = 0; n < fftSize_; ++n) {
            const std::size_t idx = (outputRead_ + n) % outSize;
            outputRing_[v][idx] += synthesisSpectrum_[v][n].real() * window_[n] * olaNorm;
        }
    }
    previousMagnitude_ = magnitude_;
}
}
