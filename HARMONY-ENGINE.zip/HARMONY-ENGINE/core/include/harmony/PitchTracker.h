#pragma once
#include "harmony/FFT.h"
#include <algorithm>
#include <complex>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace harmony {
struct PitchEstimate {
    float frequencyHz = 0.0f;
    float midiNote = 0.0f;
    float confidence = 0.0f;
    float rms = 0.0f;
    bool voiced = false;
    std::uint64_t analysisSerial = 0;
};

class PitchTracker {
public:
    void prepare(double sampleRate, float minHz = 65.0f, float maxHz = 1200.0f);
    void reset();
    void setReferenceA4(float hz) noexcept { referenceA4Hz_ = std::clamp(hz, 400.0f, 480.0f); }
    PitchEstimate processSample(float x);
    PitchEstimate latest() const noexcept { return latest_; }

private:
    PitchEstimate analyse();

    double sampleRate_ = 48000.0;
    float minHz_ = 65.0f;
    float maxHz_ = 1200.0f;
    std::vector<float> ring_;
    std::vector<float> frame_;
    std::vector<double> prefixEnergy_;
    std::vector<float> difference_;
    std::vector<float> cmnd_;
    std::vector<std::complex<float>> fftBuffer_;
    std::size_t writePos_ = 0;
    std::size_t samplesSinceAnalysis_ = 0;
    std::size_t analysisHop_ = 256;
    std::size_t windowSize_ = 2048;
    std::size_t fftSize_ = 4096;
    FFT fft_{4096};
    PitchEstimate latest_{};
    float smoothedMidi_ = 69.0f;
    float previousRawMidi_ = 69.0f;
    bool haveSmoothed_ = false;
    std::uint64_t serial_ = 0;
    float referenceA4Hz_ = 440.0f;
};
}
