#pragma once
#include <array>
#include <cstddef>

namespace harmony {
enum class ScaleType {
    Major = 0,
    NaturalMinor,
    HarmonicMinor,
    MelodicMinor,
    Dorian,
    Phrygian,
    Lydian,
    Mixolydian,
    Locrian
};

enum class ChordType {
    Major = 0,
    Minor,
    Diminished,
    Augmented,
    Sus2,
    Sus4,
    Major7,
    Minor7,
    Dominant7,
    HalfDiminished7,
    Diminished7,
    Add9,
    MinorAdd9,
    Major6,
    Minor6
};

enum class VoiceMode {
    ScaleDegree = 0,
    ChromaticSemitone,
    ChordTone
};

enum class HarmonyIntervalPreset {
    Custom = 0,
    ScaleThirdUp,
    ScaleThirdDown,
    MinorThirdUp,
    MinorThirdDown,
    MajorThirdUp,
    MajorThirdDown,
    ScaleFourthUp,
    ScaleFourthDown,
    PerfectFourthUp,
    PerfectFourthDown,
    ScaleFifthUp,
    ScaleFifthDown,
    PerfectFifthUp,
    PerfectFifthDown,
    OctaveUp,
    OctaveDown
};

struct HarmonyVoiceRule {
    bool enabled = false;
    VoiceMode mode = VoiceMode::ScaleDegree;
    int interval = 2; // scale degrees or semitones depending on mode
    int octave = 0;
};

struct VoiceRange {
    int minMidi = 36;
    int maxMidi = 96;
};

class HarmonyPlanner {
public:
    static constexpr std::size_t kVoices = 4;

    void setKey(int rootPitchClass, ScaleType scale) noexcept;
    static std::size_t buildChordNotes(int rootPitchClass, ChordType type, std::array<int, 8>& notes) noexcept;
    static HarmonyVoiceRule ruleForPreset(HarmonyIntervalPreset preset, const HarmonyVoiceRule& custom) noexcept;
    void setChordNotes(const int* notes, std::size_t count) noexcept;
    int quantizeLeadMidi(float inputMidi) const noexcept;
    int targetMidi(float inputMidi,
                   const HarmonyVoiceRule& rule,
                   int previousTarget,
                   VoiceRange range = {}) const noexcept;

    std::array<int, kVoices> planTargets(
        float inputMidi,
        const std::array<HarmonyVoiceRule, kVoices>& rules,
        const std::array<int, kVoices>& previousTargets,
        const std::array<VoiceRange, kVoices>& ranges) const noexcept;

private:
    std::array<int, 7> scale_ {0, 2, 4, 5, 7, 9, 11};
    int root_ = 0;
    std::array<int, 16> chordNotes_{};
    std::array<int, 12> chordPitchClasses_{};
    std::size_t chordCount_ = 0;
    std::size_t chordPitchClassCount_ = 0;

    static std::array<int, 7> intervalsFor(ScaleType type) noexcept;
    int degreeIndexForMidi(int midi) const noexcept;
    int midiForScaleIndex(int scaleIndex) const noexcept;
    int desiredTarget(float inputMidi, const HarmonyVoiceRule& rule) const noexcept;
    int clampToRangeByOctave(int target, VoiceRange range, int reference) const noexcept;
};
}
