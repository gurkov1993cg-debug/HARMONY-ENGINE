#pragma once
#include "harmony/HarmonyPlanner.h"
#include <array>

namespace harmony {
struct KeyEstimate {
    int root = 0;
    ScaleType scale = ScaleType::Major;
    float confidence = 0.0f;
};

class AutoKeyDetector {
public:
    void prepare(double sampleRate) noexcept;
    void reset() noexcept;
    void observe(float midiNote, float pitchConfidence) noexcept;
    KeyEstimate estimate() const noexcept { return estimate_; }

private:
    void updateEstimate() noexcept;

    double sampleRate_ = 48000.0;
    std::array<float, 12> histogram_{};
    float totalWeight_ = 0.0f;
    unsigned observations_ = 0;
    KeyEstimate estimate_{};
};
}
