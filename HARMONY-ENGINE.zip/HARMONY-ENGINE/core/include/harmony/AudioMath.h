#pragma once
#include <algorithm>
#include <cmath>

namespace harmony {
constexpr float kPi = 3.14159265358979323846f;
constexpr float kTwoPi = 6.28318530717958647692f;
inline float clamp01(float x) noexcept { return std::clamp(x, 0.0f, 1.0f); }
inline float dbToGain(float db) noexcept { return std::pow(10.0f, db / 20.0f); }
inline float harmonyExpressionFollow(float independence) noexcept {
    const float t = clamp01(independence);
    return 0.16f + 0.28f * (1.0f - t);
}
inline float harmonyExpressionTimeMs(float independence) noexcept {
    const float t = clamp01(independence);
    return 62.0f + 58.0f * t;
}
inline float gainToDb(float gain) noexcept { return 20.0f * std::log10(std::max(gain, 1.0e-9f)); }
inline float equalPowerPanL(float pan) noexcept {
    const float p = std::clamp(pan, -1.0f, 1.0f);
    return std::cos((p + 1.0f) * 0.25f * kPi);
}
inline float equalPowerPanR(float pan) noexcept {
    const float p = std::clamp(pan, -1.0f, 1.0f);
    return std::sin((p + 1.0f) * 0.25f * kPi);
}
inline float midiToHz(float note) noexcept { return 440.0f * std::pow(2.0f, (note - 69.0f) / 12.0f); }
inline float hzToMidi(float hz) noexcept { return 69.0f + 12.0f * std::log2(std::max(hz, 1.0e-6f) / 440.0f); }
inline float wrapPhase(float p) noexcept {
    while (p > kPi) p -= kTwoPi;
    while (p < -kPi) p += kTwoPi;
    return p;
}
}
