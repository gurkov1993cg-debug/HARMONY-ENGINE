#pragma once
#include "harmony/AutoKeyDetector.h"
#include "harmony/HarmonyPlanner.h"
#include "harmony/MultiVoiceVocoder.h"
#include "harmony/PitchTracker.h"
#include <array>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace harmony {
enum class HarmonyMode {
    KeyScale = 0,
    ManualChord,
    MidiChord,
    AutoKey
};

struct VoiceParams {
    HarmonyVoiceRule rule{};
    HarmonyIntervalPreset preset = HarmonyIntervalPreset::Custom;
    bool mute = false;
    bool solo = false;
    float levelDb = -9.0f;
    float pan = 0.0f;
    float formantSemitones = 0.0f;
    float detuneCents = 0.0f;
    float humanizeCents = 3.0f;
    float delayMs = 0.0f;
    float vibratoCents = 0.0f;
    float vibratoRateHz = 5.2f;
    int choirVoices = 1;
    float choirSpread = 0.0f;
    float choirDepth = 0.0f;
    int minMidi = 36;
    int maxMidi = 96;
};

struct ProcessorParams {
    float inputDb = 0.0f;
    float outputDb = 0.0f;
    float dryDb = 0.0f;
    float wetDb = 0.0f;
    float harmonyWidth = 1.0f;
    float tuningHz = 440.0f;
    float tightness = 0.55f;
    float pitchSmoothingMs = 28.0f;
    float humanize = 0.45f;
    float formantPreserve = 1.0f;
    float transientProtection = 0.92f;
    float unvoicedPreserve = 0.96f;
    float autoKeyThreshold = 0.12f;
    HarmonyMode mode = HarmonyMode::KeyScale;
    int keyRoot = 0;
    ScaleType scale = ScaleType::Major;
    int chordRoot = 0;
    ChordType chordType = ChordType::Major;
    std::array<VoiceParams, 4> voices{};
};

struct MeterState {
    float inputPeak = 0.0f;
    float outputPeakL = 0.0f;
    float outputPeakR = 0.0f;
    std::array<float, 4> voicePeak{};
    float pitchMidi = 0.0f;
    float pitchConfidence = 0.0f;
    int detectedKeyRoot = 0;
    ScaleType detectedScale = ScaleType::Major;
    float keyConfidence = 0.0f;
};

class HarmonyProcessor {
public:
    static constexpr std::size_t kVoices = 4;

    void prepare(double sampleRate);
    void reset();
    void setParams(const ProcessorParams& p) noexcept { params_ = p; }
    const ProcessorParams& params() const noexcept { return params_; }
    PitchEstimate pitchEstimate() const noexcept { return tracker_.latest(); }
    KeyEstimate keyEstimate() const noexcept { return keyDetector_.estimate(); }
    MeterState meters() const noexcept { return meters_; }
    std::array<int, kVoices> targetNotes() const noexcept { return plannedTargets_; }
    int latencySamples() const noexcept;
    void setChordNotes(const int* notes, std::size_t count) noexcept;
    void processBlock(const float* input, float* outL, float* outR, std::size_t numSamples) noexcept;

private:
    float processDryDelay(float x) noexcept;
    float readVoiceDelay(std::size_t voice, float delayMs) const noexcept;
    std::array<float, 2> processVoiceBank(std::size_t voice, float x, const VoiceParams& params) noexcept;
    void replan(float inputMidi) noexcept;
    void updatePeak(float sample, float& meter) noexcept;

    double sampleRate_ = 48000.0;
    ProcessorParams params_{};
    PitchTracker tracker_;
    AutoKeyDetector keyDetector_;
    HarmonyPlanner planner_;
    MultiVoiceVocoder vocoder_;
    std::array<int, kVoices> previousTargets_{{-1,-1,-1,-1}};
    std::array<HarmonyVoiceRule, kVoices> lastPlannedRules_{};
    std::array<VoiceRange, kVoices> lastPlannedRanges_{};
    bool havePlannedVoiceConfig_ = false;
    std::array<int, kVoices> plannedTargets_{{-1,-1,-1,-1}};
    std::array<float, kVoices> ratioSmooth_{{1.0f,1.0f,1.0f,1.0f}};
    std::array<float, kVoices> expressionDeviationSmooth_{{0.0f,0.0f,0.0f,0.0f}};
    std::array<float, kVoices> driftPhase_{{0.0f,1.1f,2.3f,4.1f}};
    std::array<float, kVoices> driftRateHz_{{0.17f,0.23f,0.31f,0.19f}};
    std::array<float, kVoices> vibratoPhase_{{0.4f,1.8f,3.2f,5.0f}};
    std::array<std::array<float, 8>, kVoices> choirPhase_{};
    std::array<int, 16> chordNotes_{};
    std::size_t chordCount_ = 0;
    std::uint64_t chordRevision_ = 0;
    std::uint64_t plannedChordRevision_ = ~std::uint64_t{0};
    std::uint64_t lastPitchSerial_ = 0;
    int lastLeadCentre_ = -999;
    int lastPlannerRoot_ = -1;
    ScaleType lastPlannerScale_ = ScaleType::Major;
    HarmonyMode lastMode_ = HarmonyMode::KeyScale;
    int lastChordRoot_ = -1;
    ChordType lastChordType_ = ChordType::Major;
    std::vector<float> dryDelay_;
    std::size_t dryWrite_ = 0;
    std::array<std::vector<float>, kVoices> voiceDelay_;
    std::array<std::size_t, kVoices> voiceDelayWrite_{};
    MeterState meters_{};
    float meterDecay_ = 0.999f;
    float smoothedInputGain_ = 1.0f;
    float smoothedOutputGain_ = 1.0f;
    float smoothedDryGain_ = 1.0f;
    float smoothedWetGain_ = 1.0f;
    std::array<float, kVoices> smoothedVoiceGain_{{1.0f,1.0f,1.0f,1.0f}};
    std::array<float, kVoices> smoothedPan_{{0.0f,0.0f,0.0f,0.0f}};
};
}
