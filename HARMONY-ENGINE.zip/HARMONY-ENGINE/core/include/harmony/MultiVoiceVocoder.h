#pragma once
#include "harmony/FFT.h"
#include <array>
#include <complex>
#include <cstddef>
#include <vector>

namespace harmony {
class MultiVoiceVocoder {
public:
    static constexpr std::size_t kVoices = 4;

    void prepare(double sampleRate, std::size_t fftSize = 2048, std::size_t hopSize = 512);
    void reset();
    void setVoiceActive(std::size_t voice, bool active) noexcept;
    void setVoicePitchRatio(std::size_t voice, float ratio) noexcept;
    void setVoiceFormantSemitones(std::size_t voice, float semitones) noexcept;
    void setFormantPreserve(float amount) noexcept;
    void setTransientProtection(float amount) noexcept;
    void setUnvoicedPreserve(float amount) noexcept;
    std::array<float, kVoices> processSample(float x) noexcept;
    int latencySamples() const noexcept { return static_cast<int>(fftSize_); }

private:
    void processFrame() noexcept;
    float envelopeAt(float bin) const noexcept;

    double sampleRate_ = 48000.0;
    std::size_t fftSize_ = 2048;
    std::size_t hopSize_ = 512;
    std::size_t halfSize_ = 1024;
    std::size_t inputWrite_ = 0;
    std::size_t outputRead_ = 0;
    std::size_t hopCounter_ = 0;
    FFT fft_{2048};

    std::vector<float> window_;
    std::vector<float> inputRing_;
    std::array<std::vector<float>, kVoices> outputRing_;
    std::vector<std::complex<float>> spectrum_;
    std::array<std::vector<std::complex<float>>, kVoices> synthesisSpectrum_;
    std::vector<float> magnitude_;
    std::vector<float> previousMagnitude_;
    std::vector<float> phase_;
    std::vector<float> previousPhase_;
    std::vector<float> trueBin_;
    std::vector<float> envelope_;
    std::vector<double> prefixLog_;
    std::array<std::vector<float>, kVoices> synthPhase_;
    std::array<std::vector<float>, kVoices> mappedMagnitude_;
    std::array<std::vector<float>, kVoices> mappedFrequency_;
    std::array<std::vector<float>, kVoices> mappedWeight_;
    std::array<std::vector<std::size_t>, kVoices> dominantSource_;
    std::array<std::vector<float>, kVoices> dominantContribution_;
    std::array<std::vector<unsigned char>, kVoices> spectralPeak_;
    std::array<std::vector<std::size_t>, kVoices> nearestPeak_;

    std::array<bool, kVoices> voiceActive_{{true, true, true, true}};
    bool anyVoiceActive_ = true;
    std::array<float, kVoices> pitchRatio_{{1.0f,1.0f,1.0f,1.0f}};
    std::array<float, kVoices> formantRatio_{{1.0f,1.0f,1.0f,1.0f}};
    float formantPreserve_ = 1.0f;
    float transientProtection_ = 0.85f;
    float unvoicedPreserve_ = 0.92f;
};
}
