#pragma once
#include <complex>
#include <cstddef>
#include <vector>

namespace harmony {
class FFT {
public:
    explicit FFT(std::size_t size = 2048);
    void setSize(std::size_t size);
    std::size_t size() const noexcept { return size_; }
    void forward(std::vector<std::complex<float>>& data) const;
    void inverse(std::vector<std::complex<float>>& data) const;

private:
    void transform(std::vector<std::complex<float>>& data, bool inverse) const;
    std::size_t size_ = 0;
    std::vector<std::size_t> bitReverse_;
};
}
