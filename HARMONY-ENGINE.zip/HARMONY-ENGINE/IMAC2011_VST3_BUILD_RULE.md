# HARMONY ENGINE — LOCKED PROVEN VST3 BUILD REALIZATION

Reference implementation: Cecko2 Apollo Twin X direct-Steinberg VST3 project supplied by the user.
This is the required HARMONY ENGINE build architecture unless the user explicitly changes it.

## Target
- iMac 2011
- Intel x86_64 only
- Cubase 10.5
- macOS deployment target 10.13
- Release
- C++17
- VST3 only
- ZERO JUCE
- native Cocoa/AppKit HARMONY GUI

## Steinberg integration
Use the VST3 SDK as a recursive checkout and integrate it exactly in this order:
1. add_subdirectory(VST3_SDK_DIR ...)
2. smtg_enable_vst3_sdk()
3. smtg_add_vst3plugin(HarmonyEngine ...)

Do NOT manually add macmain.cpp.
After smtg_add_vst3plugin(), configure must inspect the target SOURCES and FAIL unless:
${public_sdk_SOURCE_DIR}/source/main/macmain.cpp
is already attached by Steinberg.

## SDK helper switches
- SMTG_ENABLE_VST3_PLUGIN_EXAMPLES=OFF
- SMTG_ENABLE_VST3_HOSTING_EXAMPLES=OFF
- SMTG_ENABLE_VSTGUI_SUPPORT=OFF for HARMONY (Apollo used VSTGUI; HARMONY uses Cocoa)
- SMTG_RUN_VST_VALIDATOR=OFF in the build path
- SMTG_CREATE_MODULE_INFO=OFF in the build path
- SMTG_BUILD_UNIVERSAL_BINARY=OFF
- SMTG_CREATE_PLUGIN_LINK=OFF

## Factory
Use public.sdk/source/main/pluginfactory_constexpr.h.
Use BEGIN_FACTORY_DEF(..., 2) and DEF_CLASS(...), matching the proven Apollo project.
Processor class:
- kVstAudioEffectClass
- PClassInfo::kManyInstances
- Steinberg::Vst::kDistributable
- subcategory Fx
Controller class:
- kVstComponentControllerClass
- class flags 0
- empty subcategory
FUIDs are permanent and must not change between builds.

## GitHub Actions
- runner: macos-15-intel
- checkout HARMONY source ZIP
- build/test core first
- checkout steinbergmedia/vst3sdk with submodules: recursive
- configure with Xcode
- CMAKE_OSX_ARCHITECTURES=x86_64
- CMAKE_OSX_DEPLOYMENT_TARGET=10.13
- build target HarmonyEngine in Release
- verify x86_64 and required exports bundleEntry, bundleExit, GetPluginFactory
- package the real .vst3 bundle with ditto --sequesterRsrc --keepParent

## Product QA
No visible control may be dead.
No meter may display invented values.
GUI -> parameter -> state -> DSP -> audible result must remain wired.
A green CI build proves build/package structure only; final host proof is scan/load/open/process in Cubase 10.5 on the target iMac.
