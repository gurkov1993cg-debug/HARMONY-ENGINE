# HARMONY ENGINE — LOCKED iMac 2011 / Cubase 10.5 VST3 BUILD RULE

This profile is mandatory unless the user explicitly approves a different target.

1. Target machine/host
   - iMac 2011
   - Intel x86_64 only
   - Cubase 10.5
   - VST3 only

2. Build
   - GitHub Actions runner: macos-15-intel
   - Generator: Xcode
   - Configuration: Release
   - C++17
   - CMAKE_OSX_ARCHITECTURES=x86_64
   - CMAKE_OSX_DEPLOYMENT_TARGET=10.13
   - No universal/arm64 build

3. VST3 SDK
- Factory source must use the SDK 3.7.8-compatible legacy macro from `public.sdk/source/main/pluginfactory.h`:
  `BEGIN_FACTORY(vendor, url, email, PFactoryInfo::kNoFlags)`
- Do NOT use the newer/constexpr-style `BEGIN_FACTORY_DEF(...)` with `pluginfactory.h`; that breaks the SDK 3.7.8 build.
   - Steinberg VST3 SDK 3.7.8
   - Exact SDK commit: 0041ef2c879c3c54c03d33cdc11a97eaebfb5752
   - HARMONY ENGINE remains ZERO JUCE
   - For this exact external-SDK CMake integration, add `${HARMONY_VST3_SDK_ROOT}/public.sdk/source/main/macmain.cpp` explicitly to the plug-in target.
   - Reason: with SDK 3.7.8 added via external `add_subdirectory`, the helper called from the parent project does not see the SDK-local `public_sdk_SOURCE_DIR`; run 29 produced a bundle without `bundleEntry` when macmain.cpp was omitted.
   - macmain.cpp must be present exactly once, never duplicated.

4. Host-facing VST3 metadata
   - Category: Fx
   - Processor Class Flags: 0
   - Controller Class Flags: 0
   - CFBundlePackageType: BNDL
   - LSMinimumSystemVersion: 10.13
   - Proper bundleEntry / bundleExit / GetPluginFactory exports
   - moduleinfo.json must identify VST 3.7.8

5. Packaging
   - Build a real .vst3 macOS bundle
   - Ad-hoc codesign
   - Package using: ditto -c -k --sequesterRsrc --keepParent
   - Never distribute Contents/MacOS/Resources separately

6. Build must FAIL if any of these are wrong
   - architecture is not exactly x86_64
   - deployment target is not 10.13
   - bundle type is not BNDL
   - required VST3 entry exports are missing
   - moduleinfo SDK version is not VST 3.7.8
   - processor/controller class flags are not 0
   - Steinberg validator fails
   - package round-trip verification fails

7. Global product rule
   - No visible control may be nonfunctional
   - No meter may show invented values
   - GUI changes must not break working parameter/DSP wiring

8. Mach-O deployment verification
   - Verify the minimum OS with `xcrun vtool -show-build` and require minos 10.13.
   - Do NOT require a specific Mach-O load-command spelling (`LC_VERSION_MIN_MACOSX` vs `LC_BUILD_VERSION`); Xcode/linker version may choose either while preserving the same minos.
