# HARMONY ENGINE 0.9.6


## 0.9.5 sound-baseline restore / stability milestone

- fixes Cubase crash when removing the plug-in: the native editor meter timer no longer retains a stale view/controller and is explicitly stopped before VST3 editor teardown
- low-latency vocal STFT: 512 samples at 44.1/48 kHz, 1024 at 88.2/96 kHz, 2048 at 176.4/192 kHz
- keeps 4x overlap, the independent high-resolution pitch tracker, musical harmony planning and v0.9.1 expression independence
- no change to the proven Steinberg VST3 build architecture

## 0.9.1 audio-quality / musical-harmony milestone
- New instances are true unity dry by default: Dry 0 dB, Input 0 dB, Output 0 dB, all harmony voices OFF.
- VST3 wrapper preserves the original stereo dry vocal directly and latency-matches it; the source voice no longer passes through the mono pitch-shift path.
- Harmony DSP is wet-only inside the wrapper, so enabling a third/fourth/fifth cannot degrade the original dry voice.
- Harmony micro-pitch is intentionally independent: bends/vibrato are low-pass filtered and reduced instead of copied 1:1 from the lead.
- Default Harmony Independence 55%, Pitch Glide 28 ms, Humanize 45%, Transient Protect 92%, Consonant Protect 96%.
- Vocal pitch-shift analysis upgraded to a 2048-sample quality window at 44.1/48 kHz with stronger phase locking and spectral-energy normalization.
- Main input/output meters now measure the actual final host I/O; voice meters remain real generated harmony levels.
- Added a unity-dry regression test and updated quality-window latency tests.
Professional four-voice harmony processor built directly on the Steinberg VST3 SDK framework for Intel Mac.

## Proven VST3 baseline

- GitHub Actions: `macos-15-intel`
- Xcode 16.4 / Release / C++17
- Intel `x86_64` only
- macOS deployment target `10.13`
- Steinberg VST3 SDK commit `3cdf9ca5d1f5b1b21e0a86832aa4abe55607bd96`
- `smtg_enable_vst3_sdk()` + `smtg_add_vst3plugin()`
- Steinberg `macmain.cpp` supplies `bundleEntry` / `bundleExit`
- `pluginfactory_constexpr.h` / `BEGIN_FACTORY_DEF` supplies `GetPluginFactory`
- Native macOS Cocoa/AppKit editor in Objective-C++
- Own C++ DSP core

## 0.9.0 musical control milestone

The main page now exposes the musical controls directly instead of forcing the user to step through values one click at a time.

### Tonality and mode

The KEY / TONALITY selector exposes all 12 pitch classes directly:
`C, C#, D, D#, E, F, F#, G, G#, A, A#, B`.

The SCALE / MODE selector exposes:
Major, Natural Minor, Harmonic Minor, Melodic Minor, Dorian, Phrygian, Lydian, Mixolydian and Locrian.

Clicking any choice control opens the complete menu, so for example G can be selected immediately.

### Per-voice harmony interval

Every voice has a real automatable HARMONY INTERVAL parameter with these DSP-backed choices:

- Custom
- Scale 3rd Up / Down
- Minor 3rd Up / Down
- Major 3rd Up / Down
- Scale 4th Up / Down
- Perfect 4th Up / Down
- Scale 5th Up / Down
- Perfect 5th Up / Down
- Octave Up / Down

Scale intervals follow the selected KEY + SCALE / MODE. Fixed m3/M3/P4/P5 remain exact chromatic intervals.

The MAIN page also provides direct quick buttons for Scale 3rd, m3, M3, 4th, 5th, octave up and octave down. Each button writes the real HARMONY INTERVAL VST3 parameter; it is not a decorative shortcut.

## DSP and parameter wiring

The signal path remains:
GUI -> VST3 parameter -> processor state/automation -> own C++ DSP -> real audio change.

The harmony planner now replans immediately when a voice interval preset, custom voice rule or voice range changes, so interval controls do not wait for the singer to move to a new note before taking effect.

## Real DSP functions

Four independent harmony voices with Key/Scale, Manual Chord, MIDI Chord and Auto Key modes; scale-degree/chromatic/chord-tone rules; voice leading/ranges; interval/octave, level/pan, formant shift, detune, pitch humanization, timing, vibrato, choir 1/2/4/8, choir spread/depth; global tightness, pitch glide, humanize, formant preservation, transient protection, consonant/unvoiced preservation, input/dry/harmony/output gain, stereo width and A4 tuning.

Input/output/voice meters, detected pitch/key/confidence and voice targets are read-only values produced by the DSP/processor path.

## GUI

- Fixed 1280x800 professional dark layout with cold-blue accent.
- MAIN: musical key/mode selection, four voice cards, interval presets, quick harmony buttons, real target notes and real meters.
- ADVANCED: custom voice mode/interval/octave, vibrato, choir, detune and ranges.
- Click a selector to open its complete option list.
- Drag knobs vertically. Hold Shift for fine adjustment.
- Click a numeric value or Option-click a parameter for numeric entry.
- Double-click restores the real default value.
- GUI refresh is 20 Hz for real meters/status only; DSP never runs on the GUI thread.

## Tests

Automated tests verify all 12 keys including G, all supported modes, all interval-preset parameter choices, scale-aware G-major thirds, fixed minor/major thirds, fourth, fifth, high/low octaves, and immediate DSP replanning after a preset change.

## Latency

The live STFT window is 1024 samples at 44.1/48 kHz, 2048 at 88.2/96 kHz, and 4096 at higher sample rates. The VST3 processor reports the real algorithmic latency to the host for PDC.

## v0.9.5 listening-test correction

The user confirmed that v0.9.3 was stable but sounded worse than v0.9.2.
For v0.9.5 the active harmony audio path is restored byte-for-byte to the
v0.9.2 DSP implementation:

- HarmonyProcessor DSP restored to v0.9.2.
- MultiVoiceVocoder DSP restored to v0.9.2.
- Original v0.9.2 humanize/vibrato/choir modulation behavior restored.
- Original v0.9.2 formant/transient/unvoiced spectral processing restored.
- Original v0.9.2 pan/choir gain behavior restored.
- v0.9.2 low-latency window sizes are preserved.
- v0.9.2 native-editor teardown/timer crash fix remains preserved.
- The safe host-side optimization from v0.9.3 remains: when no harmony voice is audible,
  the expensive harmony analysis/synthesis engine is not run. Once a harmony voice is active,
  the sound-producing DSP is the exact v0.9.2 path.

Rule: never trade audible quality for CPU savings. Any future optimization must pass a
listening comparison against this v0.9.2 sound baseline before it is accepted.

## v0.9.5 quality / audition correction

- Restores the user-approved v0.9.1 2048-sample quality window at 44.1/48 kHz (4096 at 88.2/96 kHz).
- Rejects the 512-sample vocal STFT because real-vocal listening exposed metallic/warbling artifacts.
- Direct lead and bypass are zero-latency; Cubase is no longer asked to delay the lead by the harmony analysis window.
- New LEAD MUTE control isolates generated harmonies.
- SOLO now isolates selected harmony voices and automatically removes the original lead from the output.
- SOLO auditions a voice even if ON was previously off, and the GUI turns that voice ON for consistent state.
- MUTE removes the corresponding generated harmony voice.
- Quick interval buttons enable the selected voice immediately.
- Default extra per-voice Timing delay is 0 ms to avoid stacking artificial delay on top of the high-quality synthesis look-back.
- Existing editor teardown/crash fix and safe idle-DSP skip are preserved.


## v0.9.6 vocal stability correction

- Removed the visible ADVANCED page entirely; the plug-in now has one main working page.
- Added temporal formant-envelope stabilization so a sustained harmony cannot suddenly turn thin/nasal after a consonant or a few frames.
- Bounded per-bin formant correction to prevent extreme spectral holes/boosts.
- Smoothed frame-to-frame energy normalization.
- Replaced hard transient phase resets with continuous phase evolution plus a gentle transient anchor.
- Added octave-slip protection for an unchanged harmony rule, so a one-frame pitch-analysis octave error cannot throw the harmony into another register.
- Existing hidden state/automation IDs are retained for project compatibility.
