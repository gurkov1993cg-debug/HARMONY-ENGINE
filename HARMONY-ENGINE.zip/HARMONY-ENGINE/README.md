# HARMONY ENGINE 0.6.2

Native Steinberg VST3 harmony processor for Intel Mac / macOS 10.15+.

## Architecture

- Direct Steinberg VST3 SDK 3.8.1 wrapper.
- Own C++ DSP core.
- Native macOS Cocoa editor implemented in Objective-C++.
- No JUCE and no VSTGUI in the product.
- Intel x86_64 target, deployment target macOS 10.15.
- Steinberg VST3 Validator is run automatically after the plug-in build.

## Real DSP functions

Four independent harmony voices with Key/Scale, Manual Chord, MIDI Chord and Auto Key modes; scale-degree/chromatic/chord-tone voice rules; voice leading/ranges; interval/octave, level/pan, formant shift, detune, pitch humanization, timing, vibrato, choir 1/2/4/8, choir spread/depth; global tightness, pitch glide, humanize, formant preservation, transient protection, consonant/unvoiced preservation, input/dry/harmony/output gain, stereo width and A4 tuning.

The editor only exposes functions that are wired to real parameters. Input/output/voice meters, detected pitch/key/confidence and voice targets are read-only values produced by the DSP/processor path, not decorative animation.

## GUI rules

- Main page: fast everyday controls and four voice strips.
- Advanced page: every implemented DSP parameter.
- Drag knobs vertically. Hold Shift for fine adjustment.
- Click the numeric value or Option-click a control for direct numeric entry.
- Double-click any parameter control to restore its real default value.
- GUI refresh is 20 Hz and is only used for real meters/status; DSP never runs on the GUI thread.

## Latency

The live STFT window is 1024 samples at 44.1/48 kHz, 2048 at 88.2/96 kHz, and 4096 at higher sample rates. The VST3 processor reports the real algorithmic latency to the host for PDC.
