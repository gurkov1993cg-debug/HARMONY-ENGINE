# HARMONY ENGINE 0.9.0

Professional four-voice harmony processor built directly on the Steinberg VST3 SDK framework for Intel Mac.

## Proven VST3 baseline

- GitHub Actions: `macos-15-intel`
- Xcode 16.4 / Release / C++17
- Intel `x86_64` only
- macOS deployment target `10.13`
- Steinberg VST3 SDK commit `3cdf9ca5d1f5b1b21e0a86832aa4abe55607bd96`
- `smtg_enable_vst3_sdk()` + `smtg_add_vst3plugin()`
- Steinberg `macmain.cpp` supplies `bundleEntry` / `bundleExit`
- `pluginfactory_constexpr.h` / `BEGIN_FACTORY_DEF` supplies `GetPluginFactory`
- Native macOS Cocoa/AppKit editor in Objective-C++
- Own C++ DSP core

## 0.9.0 musical control milestone

The main page now exposes the musical controls directly instead of forcing the user to step through values one click at a time.

### Tonality and mode

The KEY / TONALITY selector exposes all 12 pitch classes directly:
`C, C#, D, D#, E, F, F#, G, G#, A, A#, B`.

The SCALE / MODE selector exposes:
Major, Natural Minor, Harmonic Minor, Melodic Minor, Dorian, Phrygian, Lydian, Mixolydian and Locrian.

Clicking any choice control opens the complete menu, so for example G can be selected immediately.

### Per-voice harmony interval

Every voice has a real automatable HARMONY INTERVAL parameter with these DSP-backed choices:

- Custom
- Scale 3rd Up / Down
- Minor 3rd Up / Down
- Major 3rd Up / Down
- Scale 4th Up / Down
- Perfect 4th Up / Down
- Scale 5th Up / Down
- Perfect 5th Up / Down
- Octave Up / Down

Scale intervals follow the selected KEY + SCALE / MODE. Fixed m3/M3/P4/P5 remain exact chromatic intervals.

The MAIN page also provides direct quick buttons for Scale 3rd, m3, M3, 4th, 5th, octave up and octave down. Each button writes the real HARMONY INTERVAL VST3 parameter; it is not a decorative shortcut.

## DSP and parameter wiring

The signal path remains:
GUI -> VST3 parameter -> processor state/automation -> own C++ DSP -> real audio change.

The harmony planner now replans immediately when a voice interval preset, custom voice rule or voice range changes, so interval controls do not wait for the singer to move to a new note before taking effect.

## Real DSP functions

Four independent harmony voices with Key/Scale, Manual Chord, MIDI Chord and Auto Key modes; scale-degree/chromatic/chord-tone rules; voice leading/ranges; interval/octave, level/pan, formant shift, detune, pitch humanization, timing, vibrato, choir 1/2/4/8, choir spread/depth; global tightness, pitch glide, humanize, formant preservation, transient protection, consonant/unvoiced preservation, input/dry/harmony/output gain, stereo width and A4 tuning.

Input/output/voice meters, detected pitch/key/confidence and voice targets are read-only values produced by the DSP/processor path.

## GUI

- Fixed 1280x800 professional dark layout with cold-blue accent.
- MAIN: musical key/mode selection, four voice cards, interval presets, quick harmony buttons, real target notes and real meters.
- ADVANCED: custom voice mode/interval/octave, vibrato, choir, detune and ranges.
- Click a selector to open its complete option list.
- Drag knobs vertically. Hold Shift for fine adjustment.
- Click a numeric value or Option-click a parameter for numeric entry.
- Double-click restores the real default value.
- GUI refresh is 20 Hz for real meters/status only; DSP never runs on the GUI thread.

## Tests

Automated tests verify all 12 keys including G, all supported modes, all interval-preset parameter choices, scale-aware G-major thirds, fixed minor/major thirds, fourth, fifth, high/low octaves, and immediate DSP replanning after a preset change.

## Latency

The live STFT window is 1024 samples at 44.1/48 kHz, 2048 at 88.2/96 kHz, and 4096 at higher sample rates. The VST3 processor reports the real algorithmic latency to the host for PDC.
