# HARMONY ENGINE

Target: VST3, Intel x86_64, macOS 10.15 Catalina minimum, C++17.

Architecture:
- JUCE is used only for the VST3 wrapper, host parameters/state and lightweight GUI.
- Harmony DSP is custom C++ in `core/`.
- No JUCE DSP module is used.

## v0.5.0 goals

- Low-latency shared 4-voice phase-vocoder engine.
- 1024-sample STFT at 44.1/48 kHz, 2048 at 88.2/96 kHz, 4096 at 176.4/192 kHz.
- Fixed preallocated plugin scratch buffers: no vector resize/allocation in `processBlock()`.
- Cached APVTS raw parameter pointers: no repeated String parameter lookup on the audio thread.
- Defensive host processing for unexpected buffer/state conditions.
- Lightweight 20 Hz GUI metering; no spectrum/waveform animation, blur or continuous decorative effects.
- MAIN view exposes daily controls; ADVANCED exposes the complete already-wired DSP control set.
- Every exposed audio parameter is wired APVTS -> processor -> custom DSP.

## Implemented harmony functions

- Key/Scale harmony
- Manual Chord harmony
- MIDI Chord harmony with Omni/1-16 channel filtering and Hold
- Auto Key estimation
- Four independent harmony voices
- Scale-degree / chromatic / chord-tone voice modes
- Voice interval, octave, level, pan, formant offset, detune
- Per-voice pitch humanize, timing offset and vibrato
- 1/2/4/8 choir subvoices per main voice with spread/depth
- Per-voice low/high MIDI range
- Global Input, Dry, Harmony, Output and Width
- A4 tuning, Tightness, Pitch Glide and Humanize
- Formant preservation, transient protection and consonant/unvoiced protection
- Real input/output/voice meters and real target-note readouts
- Host state save/restore, automation-ready parameters, numeric slider entry, double-click defaults

## DSP verification

Configure core only:

```bash
cmake -S . -B build -DHARMONY_BUILD_PLUGIN=OFF -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel 4
ctest --test-dir build --output-on-failure
```

The tests cover the custom FFT, pitch tracker, A4 reference tuning, harmony planner, chord construction, auto-key detector, vocoder output, harmony processor output/meters, mute behavior, and low-latency window selection.

## Plugin build

```bash
cmake -S . -B build \
  -DHARMONY_BUILD_PLUGIN=ON \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_OSX_ARCHITECTURES=x86_64 \
  -DCMAKE_OSX_DEPLOYMENT_TARGET=10.15
cmake --build build --parallel 2
```

A build is not considered final until the produced VST3 loads and processes audio in the target Cubase/macOS host without blacklist/crash and every visible control is runtime-verified.
