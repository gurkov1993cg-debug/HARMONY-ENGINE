# HARMONY ENGINE

Professional four-voice vocal harmony processor with custom C++ DSP.

## Target

- VST3
- Intel x86_64
- macOS 10.15 Catalina minimum
- intended to run on 2011 Intel iMac hardware
- C++17
- JUCE used for the VST3/GUI/parameter wrapper; harmony DSP is custom C++

## Current implemented engine

- FFT-accelerated YIN-style monophonic pitch tracking
- adjustable A4 reference tuning (400–480 Hz)
- Key/Scale, Manual Chord, MIDI Chord and Auto Key modes
- Major, Natural Minor, Harmonic Minor, Melodic Minor, Dorian, Phrygian, Lydian, Mixolydian and Locrian scales
- 15 manual chord types
- chord-aware multi-voice planning and voice-leading
- four independent harmony voices
- per-voice Enable / Mute / Solo
- per-voice interval, octave, level, pan, formant, detune, pitch-humanize and timing
- per-voice vibrato depth/rate
- per-voice choir 1/2/4/8 with width/depth
- per-voice low/high range limits
- global Tightness, Pitch Glide, Humanize, Formant Preserve, Transient Protect and Consonant Protect
- global harmony stereo width
- MIDI channel filter and MIDI chord hold
- latency-compensated internal bypass
- real input/output/voice meters with peak hold and dB scale
- live pitch, cents, confidence, detected key and target-note readouts
- host automation and APVTS state recall
- GUI A/B comparison, A→B/B→A copy and Reset to defaults
- numeric entry and double-click default on slider parameters

No visible control is intentionally decorative. Parameters exposed by the GUI are connected through APVTS to the processor/DSP path.

## Build DSP tests

```bash
cmake -S . -B build-core -DHARMONY_BUILD_PLUGIN=OFF -DCMAKE_BUILD_TYPE=Release
cmake --build build-core --parallel 4
ctest --test-dir build-core --output-on-failure
```

## Build VST3

```bash
cmake -S . -B build -DHARMONY_BUILD_PLUGIN=ON -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_OSX_ARCHITECTURES=x86_64 \
  -DCMAKE_OSX_DEPLOYMENT_TARGET=10.15
cmake --build build --config Release --parallel 4
```

The GitHub Actions workflow builds and packages the Intel macOS VST3 artifact.
