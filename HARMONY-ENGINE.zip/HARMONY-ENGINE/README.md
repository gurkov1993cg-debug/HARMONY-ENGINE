# HARMONY ENGINE 0.10.0

Direct Steinberg VST3 SDK plug-in for Intel macOS. No JUCE and no VSTGUI. DSP is custom C++ and the macOS editor is native Cocoa/AppKit.

## Target

- VST3
- Intel x86_64
- deployment target macOS 10.13
- target machine: iMac 2011 / Cubase 10.5
- proven Steinberg VST3 SDK revision: `3cdf9ca5d1f5b1b21e0a86832aa4abe55607bd96`

## Current musical controls

- all 12 keys: C, C#, D, D#, E, F, F#, G, G#, A, A#, B
- Major, Natural Minor, Harmonic Minor, Melodic Minor, Dorian, Phrygian, Lydian, Mixolydian, Locrian
- Scale 3rd up/down
- Minor 3rd up/down
- Major 3rd up/down
- Scale 4th up/down
- Perfect 4th up/down
- Scale 5th up/down
- Perfect 5th up/down
- Octave up/down
- four harmony voices
- real MUTE and SOLO audition logic
- LEAD MUTE for harmony-only audition
- direct quick interval buttons

Fixed chromatic presets are literal intervals. In particular `-8` is always exactly -12 semitones and cannot be octave-folded by voice-leading/range logic.

## v0.10.0 vocal synthesis change

The old long-window phase-vocoder production path has been removed from `HarmonyCore`.

The new active harmony engine is `MultiVoicePsola`, a low-latency pitch-synchronous harmonic resynthesis path:

- one shared causal spectrum analysis for all harmony voices;
- the lead singer's real harmonic residual and vocal spectral envelope are measured from the input;
- each harmony voice receives its own pitch-synchronous one-cycle waveform;
- target pitch is generated directly at the requested F0 rather than by outputting a delayed STFT copy;
- formant preservation remaps the measured vocal envelope in absolute frequency;
- the explicit per-voice formant control remains DSP-active;
- unvoiced/consonant and transient preservation uses only a high-frequency residual, not a delayed full-band copy of the lead;
- no synthesis delay line: `HarmonyProcessor::latencySamples()` is 0;
- the VST3 direct lead/bypass path remains zero latency;
- the heavy harmony engine still sleeps completely when no harmony voice is audible.

This version is a new audible synthesis milestone and is not considered the final sound baseline until it passes the user's real-vocal Cubase listening test.

## Mono-safe defaults

For a fresh instance:

- Harmony Width = 0%
- all harmony PAN values = center
- Choir Voices = 1
- Choir Spread = 0%
- Choir Depth = 0%

A mono vocal with one harmony therefore stays mono until PAN/WIDTH/CHOIR are deliberately changed.

## GUI

The visible ADVANCED page has been removed. The plug-in uses one main working page. Every visible control must remain wired GUI -> VST3 parameter -> state -> DSP -> audible result. Numeric entry and double-click default reset remain required.

## Stability

The native Cocoa meter timer/editor teardown fix remains in place so removing the plug-in does not leave a timer calling a released VST controller.

## Tests

Core tests cover:

- FFT and pitch tracker
- key/scale/chord planning
- all fixed interval mappings including octave down
- pitch-synchronous unity, major-third and octave-down pitch accuracy
- end-to-end HarmonyProcessor major-third output near 277 Hz from a 220 Hz lead (not a delayed 220 Hz copy)
- long-running harmony energy stability
- MUTE/SOLO/LEAD MUTE behavior
- inactive-harmony unity dry path
- mono-center L/R identity when WIDTH=0 and PAN=0
- parameter defaults and stable IDs

A build is not considered ready if any test fails.
